package com.matrixx.billing.entity;

import com.matrixx.billing.enums.CustomerAccount;
import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Data
@Entity
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    private CustomerAccount customerAccount;

    private String name;
    private String billingAccountNumber;

    @OneToMany(mappedBy = "customer")
    private List<Subscription> subscriptions;

}
