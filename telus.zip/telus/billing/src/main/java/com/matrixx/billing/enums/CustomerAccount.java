package com.matrixx.billing.enums;

public enum CustomerAccount {
    INDIVIDUAL, CORPORATE;
}
