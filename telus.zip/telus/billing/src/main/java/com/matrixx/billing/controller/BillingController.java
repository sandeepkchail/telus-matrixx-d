package com.matrixx.billing.controller;

import com.matrixx.billing.entity.Customer;
import com.matrixx.billing.entity.Subscription;
import com.matrixx.billing.service.BillingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/billing")
public class BillingController {

    @Autowired
    private BillingService billingService;

    @PostMapping("/customers")
    public Customer createCustomer(@RequestBody Customer customer) {
        return billingService.createCustomer(customer);
    }

    @PostMapping("/subscriptions")
    public Subscription createSubscription(@RequestBody Subscription subscription) {
        return billingService.createSubscription(subscription);
    }

    @GetMapping("/customers")
    public List<Customer> getAllCustomers() {
        return billingService.getAllCustomers();
    }
}

