package com.matrixx.billing.service;

import com.matrixx.billing.entity.Customer;
import com.matrixx.billing.entity.Subscription;
import com.matrixx.billing.repository.CustomerRepository;
import com.matrixx.billing.repository.SubscriptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BillingService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private SubscriptionRepository subscriptionRepository;

    public Customer createCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    public Subscription createSubscription(Subscription subscription) {
        return subscriptionRepository.save(subscription);
    }

    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

}

