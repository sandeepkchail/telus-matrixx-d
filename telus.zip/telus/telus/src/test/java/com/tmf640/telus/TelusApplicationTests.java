package com.tmf640.telus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TelusApplicationTests {

	@Test
	void contextLoads() {
	}

}
