package com.tmf640.telus.controller;

import com.tmf640.telus.model.RelatedParty;
import com.tmf640.telus.model.ServiceActivation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;

@Slf4j
@RestController
public class ActivationController {

    @GetMapping("/tmf640/serviceactivation/v3/service")
    public ServiceActivation getServiceActivation() {
        // Creating sample data
        RelatedParty party1 = new RelatedParty();
        party1.setRelatedPartyId(9);
        party1.setId(12345678);
        party1.setRole("user2");
        party1.setReferredType("Individual2");

        RelatedParty party2 = new RelatedParty();
        party2.setRelatedPartyId(10);
        party2.setId(87654321);
        party2.setRole("user3");
        party2.setReferredType("Vendor3");

        ServiceActivation serviceActivation = new ServiceActivation();
        serviceActivation.setId(17);
        serviceActivation.setCategory("MobileService4");
        serviceActivation.setDescription("New Service Activation3");
        serviceActivation.setServiceType("POS-WLS4");
        serviceActivation.setState("active4");
        serviceActivation.setRelatedParties(Arrays.asList(party1, party2));

        // Printing the JSON response to the console
        log.info("Response: {}", serviceActivation);

        return serviceActivation;
    }
}

