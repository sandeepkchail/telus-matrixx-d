package com.tmf640.telus.model;


import lombok.Data;

@Data
public class RelatedParty {
    private int relatedPartyId;
    private long id;
    private String role;
    private String referredType;

}

