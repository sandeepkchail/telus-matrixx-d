package com.tmf640.telus.model;

import lombok.Data;

import java.util.List;

@Data
public class ServiceActivation {
    private int id;
    private String category;
    private String description;
    private String serviceType;
    private String state;
    private List<RelatedParty> relatedParties;
    private Object serviceCharacteristics;
    private Object featuresRequests;


}
