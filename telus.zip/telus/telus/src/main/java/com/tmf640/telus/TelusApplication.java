package com.tmf640.telus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TelusApplication {

	public static void main(String[] args) {
		SpringApplication.run(TelusApplication.class, args);
	}

}
