package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MtxRequestSubscriberAddDevice extends RequestItem implements IRequestManager {
    @JsonProperty("SubscriberSearchData")
    private MtxSubscriberSearchData subscriberSearchData;

    @JsonProperty("DeviceSearchData")
    private MtxDeviceSearchData deviceSearchData;
}
