package com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MtxRequestSubscriptionCreate extends RequestItem {
    @JsonProperty("TenantId")
    private String tenantId;

    @JsonProperty("ExternalId")
    private String externalId;

    @JsonProperty("TimeZone")
    private String timeZone;

    @JsonProperty("Attr")
    private TelusSubscriberExtension attr;

    @JsonProperty("BillingCycle")
    private MtxBillingCycleData billingCycle;
}

