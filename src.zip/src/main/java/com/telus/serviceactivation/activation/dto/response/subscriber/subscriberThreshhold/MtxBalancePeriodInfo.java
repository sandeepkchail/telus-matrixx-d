package com.telus.serviceactivation.activation.dto.response.subscriber.subscriberThreshhold;

public class MtxBalancePeriodInfo {
    private double amount;
    private String endTime;
    private int intervalId;
    private boolean isCurrentPeriod;
    private boolean isPeriodClosed;
    private boolean isTentative;
    private double reservedAmount;
    private String startTime;
    private String thresholdLimit;
}
