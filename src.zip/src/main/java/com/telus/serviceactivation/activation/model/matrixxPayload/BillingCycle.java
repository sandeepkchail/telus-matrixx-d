package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class BillingCycle {
    @JsonProperty("$")
    private String dollarSign;
    private String billingCycleId;
    private String dateOffset;

}