package com.telus.serviceactivation.activation.config.data;

import lombok.Data;

@Data
public class MtxRequestMulti {
    private ApiEventData apiEventData;
    private RequestList requestList;
}

