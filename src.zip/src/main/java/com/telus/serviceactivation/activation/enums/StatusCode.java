package com.telus.serviceactivation.activation.enums;

public enum StatusCode {
    PENDING, SUCCESS, ERROR, IGNORE, RECYCLE, BLOCKED, ARCHIVED;
}
