package com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MtxDeviceSearchData {
    @JsonProperty("$")
    private String type;

    @JsonProperty("MultiRequestIndex")
    private String multiRequestIndex;
}
