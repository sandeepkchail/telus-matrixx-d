package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MtxRequestMulti {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("ApiEventData")
    private ApiEventData apiEventData;

    @JsonProperty("RequestList")
    private List<RequestListItem> requestList;
}





















