package com.telus.serviceactivation.activation.util;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;

public enum ResponseCode {
    SUCCESS(HttpStatus.OK, "Request is processed successfully"),
    POL400(HttpStatus.BAD_REQUEST, "Policy Violation"),
    POL404(HttpStatus.NOT_FOUND, "Resource Not Found"),
    SVC500(HttpStatus.INTERNAL_SERVER_ERROR, "Service Internal Error"),
    SVC503(HttpStatus.SERVICE_UNAVAILABLE, "Service Not Available")
    ;

    ResponseCode(HttpStatus status, String reason) {
        this.status = status;
        this.reason = reason;
    }

    @Getter
    private final HttpStatus status;

    @Getter
    private final String reason;
}
