package com.telus.serviceactivation.activation.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class MtxRequestMulti {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("ApiEventData")
    private ApiEventData apiEventData;

    @JsonProperty("RequestList")
    private List<RequestListItem> requestList;
}
