package com.telus.serviceactivation.activation.dto.request.catalogueItem;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.telus.serviceactivation.activation.dto.request.BaseMtxRequestMulti;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@RequiredArgsConstructor
public class MtxRequestPricingQueryCatalogItem extends BaseMtxRequestMulti {

    @JsonProperty("CatalogItemSearchData")
    private MtxPricingCatalogItemSearchData catalogItemSearchData;
}
