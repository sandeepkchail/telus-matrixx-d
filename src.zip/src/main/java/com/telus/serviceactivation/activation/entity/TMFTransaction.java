package com.telus.serviceactivation.activation.entity;

import jakarta.persistence.*;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;
import org.hibernate.annotations.Type;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Entity
@Table(name = "tmf640_api_transaction")
//@ToString
public class TMFTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "trxn_id")
    private Long transactionId;

    @Column(name = "external_id")
    private Integer externalId;

    @Column(name = "activity_code", length = 512)
    private String activityCode;

    @Column(name = "billing_account_num", length = 512)
    private String ban;

    @Column(name = "phone_num", length = 512)
    private String phoneNumber;

    @Column(name = "api_endpoint", length = 512)
    private String apiEndpoint;

    @Column(name = "request_payload", columnDefinition = "TEXT")
    private String tmfRequestPayload;

    @Column(name = "response_payload", columnDefinition = "TEXT")
    private String tmfResponsePayload;

    @Column(name = "status", length = 512)
    private String status = new String("PENDING");

    @Column(name = "retry_count", length = 512)
    private Integer retryCount = 0;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "processed_at")
    private LocalDateTime processedAt;

    @Column(name = "last_retry_at")
    private LocalDateTime lastRetryAt;

    @Column(name = "mtx_request_time")
    private LocalDateTime mtxRequestTime;

    @Column(name = "mtx_response_time")
    private LocalDateTime mtxResponseTime;

    @Column(name = "mtx_request", columnDefinition = "TEXT")
    private String mtxRequest;

    @Column(name = "mtx_response", columnDefinition = "TEXT")
    private String mtxResponse;

    @Column(name = "last_modified")
    private LocalDateTime lastModified;

    @Column(name = "error_message", length = 512)
    private String errorMessage;

    //@OneToOne(mappedBy = "transaction", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    // private RetryTransaction retryTransaction;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return "TMFTransaction{" +
                /*"transactionId=" + transactionId +*/
                ", externalId=" + externalId +
                ", activityCode='" + activityCode + '\'' +
                ", ban='" + ban + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", apiEndpoint='" + apiEndpoint + '\'' +
                ", tmfRequestPayload='" + tmfRequestPayload + '\'' +
                ", tmfResponsePayload='" + tmfResponsePayload + '\'' +
                ", status='" + status + '\'' +
                ", retryCount='" + retryCount + '\'' +
                ", createdAt='" + createdAt + '\'' +
                ", updatedAt='" + updatedAt + '\'' +
                ", processedAt='" + processedAt + '\'' +
                ", lastRetryAt='" + lastRetryAt + '\'' +
                ", mtxRequestTime='" + mtxRequestTime + '\'' +
                ", mtxResponseTime='" + mtxResponseTime + '\'' +
                ", mtxRequest='" + mtxRequest + '\'' +
                ", mtxResponse='" + mtxResponse + '\'' +
                ", retryStatus='" + lastModified + '\'' +
                ", errorMessage=" + errorMessage +
                '}';
    }

/*   @OneToOne(mappedBy = "transaction", cascade = CascadeType.MERGE, fetch = FetchType.LAZY)
    private ApiJobs jobs;*/
}