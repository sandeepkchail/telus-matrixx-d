package com.telus.serviceactivation.activation.dto;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.telus.serviceactivation.activation.constants.JsonConstants.*;

@Component
@Getter
public class CommonRequestDto {

    @Autowired
    @Getter
    ServiceRequestDto serviceRequestDto;

    private String ban;
    private String extId;
    private String activityCode;
    private String transactionSequenceNumber;
    private String transactionEffectiveDate;
    private String phoneNumber;

    public CommonRequestDto setRequestParameter(ServiceRequestDto serviceRequestDto) {
        ban = serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> BILLING_ACCOUNT_NUMBER.equals(sc.getName()))
                //.map(ServiceCharacteristicRequestDto::getValueContent)
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null);

        extId = serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> EXTERNAL_ID.equals(sc.getName()))
                .map(sc -> {
//                    String valueContent = sc.getValueContent();
                    String value = sc.getValue();
                    // Parsing the valueContent to Integer
                    return value != null ? value : null;
                })
                .findFirst()
                .orElse(null);

        activityCode = serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> ACITVITY_CODE.equals(sc.getName()))
//                .map(ServiceCharacteristicRequestDto::getValueContent)
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse("NAC");

        transactionSequenceNumber = serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> TRANSACTION_SEQUENCE_NUMBER.equals(sc.getName()))
//                .map(ServiceCharacteristicRequestDto::getValueContent)
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null);

        transactionEffectiveDate = serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> TRANSACTION_EFFECTIVE_DATE.equals(sc.getName()))
//                .map(ServiceCharacteristicRequestDto::getValueContent)
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null);

        phoneNumber = serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> PHONE_NUMBER.equals(sc.getName()))
//                .map(ServiceCharacteristicRequestDto::getValueContent)
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null);

        return this;
    }
}
