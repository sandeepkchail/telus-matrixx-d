package com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.util.List;

@Data
public class MtxRequestSubscriberPurchaseOffer extends RequestItem {
    @JsonProperty("SubscriberSearchData")
    private MtxSubscriberSearchData subscriberSearchData;

    @JsonProperty("OfferRequestArray")
    private List<MtxPurchasedOfferData> offerRequestArray;

    @JsonProperty("PurchasePackageData")
    private MtxPurchasePackageData purchasePackageData;
}
