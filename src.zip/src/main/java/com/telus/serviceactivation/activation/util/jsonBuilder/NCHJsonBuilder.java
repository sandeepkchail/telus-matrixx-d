package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.telus.serviceactivation.activation.constants.JsonConstants;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.model.matrixxPayload.*;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Objects;

@Component("NCH")
public class NCHJsonBuilder implements JsonBuilder{
    public String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {
        ApiEventData apiEventData=populateAPIEventData(serviceRequestDto,activityCd);
        RequestListItem request = new RequestListItem();
        request.setDollarSign(JsonConstants.MTX_REQUEST_SUBSCRIPTION_MODIFY);
        MtxSubscriptionSearchData mtxSubscriptionSearchData = populateSubscriptioSeachData(serviceRequestDto);
        request.setMtxSubscriptionSearchData((!Objects.equals(mtxSubscriptionSearchData, null)) ? mtxSubscriptionSearchData : null);
        Attr attr=populateAttr(serviceRequestDto);
        request.setAttr((!Objects.equals(attr, null)) ? attr : null);
        MtxRequestMulti requestMulti=populateMtxRequestMulti(apiEventData, Collections.singletonList(request));
        return returnJsonString(requestMulti);
//        return "";
    }
}
