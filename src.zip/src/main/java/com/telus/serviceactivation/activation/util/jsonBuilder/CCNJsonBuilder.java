package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.telus.serviceactivation.activation.constants.JsonConstants;
import com.telus.serviceactivation.activation.dto.ServiceCharacteristicRequestDto;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.model.matrixxPayload.*;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

import static com.telus.serviceactivation.activation.constants.JsonConstants.*;

@Component("CCN")

public class CCNJsonBuilder implements JsonBuilder {

    public String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {
        ApiEventData apiEventData=populateAPIEventData(serviceRequestDto,activityCd);
        List<IRequestManager> request = new java.util.ArrayList<>(List.of());
        RequestListItem subRequest = new RequestListItem();
        //MtxMtxDeviceSearchDatamtxMtxDeviceSearchData= null;
        subRequest.setDollarSign(MTX_REQUEST_DEVICE_MODIFY);
        subRequest.setStatus("2");
        MtxDeviceSearchData deviceSearchData = new MtxDeviceSearchData();
        deviceSearchData.setDollarSign(MTX_DEVICE_SEARCH_DATA);
        deviceSearchData.setAccessNumber(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> PREVIOUS_SUBSCRIBER_NUMBER.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        subRequest.setDeviceSearchData((!Objects.equals(deviceSearchData, null))? deviceSearchData: null);

        request.add(subRequest);
        RequestListItem subRequest2 = new RequestListItem();
        subRequest2.setDollarSign(JsonConstants.MTX_REQUEST_DEVICE_DELETE);
        subRequest2.setDeleteSession("1");
        MtxDeviceSearchData device_SearchData = new MtxDeviceSearchData();
        device_SearchData.setDollarSign(MTX_DEVICE_SEARCH_DATA);
        device_SearchData.setAccessNumber(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> PREVIOUS_SUBSCRIBER_NUMBER.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));
        subRequest2.setDeviceSearchData((!Objects.equals(device_SearchData, null))? device_SearchData: null);

        request.add(subRequest2);
        MtxRequestDeviceCreate deviceCreate = new MtxRequestDeviceCreate();
        deviceCreate.setDollarSign(MTX_REQUEST_DEVICE_CREATE);
        deviceCreate.setTenantId("Telus");
        MtxMobileDeviceExtension deviceExtension = new MtxMobileDeviceExtension();
        deviceExtension.setDollarSign(MTX_MOBILE_DEVICE_EXTENSION);
        deviceExtension.setAccessNumberArray(List.of(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> PHONE_NUMBER.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null)));
        deviceExtension.setImsi(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> PHONE_NUMBER.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));
        deviceCreate.setAttr(deviceExtension);
        deviceCreate.setRelatedMsgId("New-Device");
        request.add(deviceCreate);

        RequestListItem subRequest3 = new RequestListItem();
        subRequest3.setDollarSign(MTX_REQUEST_SUBSCRIBER_ADD_DEVICE);
        MtxDeviceSearchData deviceSearchData2 = new MtxDeviceSearchData();
        deviceSearchData2.setDollarSign(MTX_DEVICE_SEARCH_DATA);
        deviceSearchData2.setMultiRequestIndex("2");
//        deviceSearchData2.setAccessNumber(serviceRequestDto.getServiceCharacteristic().stream()
//                .filter(sc -> PREVIOUS_SUBSCRIBER_NUMBER.equals(sc.getName()))
//                .map(ServiceCharacteristicRequestDto::getValue)
//                .findFirst().orElse(null));
        subRequest3.setDeviceSearchData(deviceSearchData2);

        MtxSubscriberSearchData subscriberSearchData = new MtxSubscriberSearchData();
        subscriberSearchData.setDollarSign(MTX_SUBSCRIBER_SEARCH_DATA);
        subscriberSearchData.setExternalId(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> "externalId".equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        subRequest3.setSubscriberSearchData(subscriberSearchData);
        request.add(subRequest3);

        MtxRequestMulti requestMulti=populateMtxRequestMulti(apiEventData,request);
        return returnJsonString(requestMulti);
    }
}