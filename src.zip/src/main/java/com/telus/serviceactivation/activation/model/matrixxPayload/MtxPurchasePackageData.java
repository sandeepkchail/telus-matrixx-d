package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MtxPurchasePackageData {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("Attr")
    private TelusPurchasePackage attr;

    @JsonProperty("CycleOffsetType")
    private Integer cycleOffsetType;

    @JsonProperty("Name")
    private String name;

    @JsonProperty("PeriodInterval")
    private Integer periodInterval;

    @JsonProperty("PeriodType")
    private Integer periodType;
}

