package com.telus.serviceactivation.activation.model.matrixxPayload.suspend;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation.Attr;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestListItem {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("Status")
    private String status;

    @JsonProperty("SubscriptionSearchData")
    private SubscriptionSearchData subscriptionSearchData;

    @JsonProperty("RelatedMsgId")
    private String relatedMsgId;

    @JsonProperty("Attr")
    private Attr attr;

}
