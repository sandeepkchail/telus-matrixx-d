package com.telus.serviceactivation.activation.dto.response.subscriber.subscriberInfo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.telus.serviceactivation.activation.dto.response.BaseMtxResponseMulti;
import com.telus.serviceactivation.activation.dto.response.IMtxResponseMulti;
import com.telus.serviceactivation.activation.dto.response.subscriber.MtxResponseSubscriber;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@RequiredArgsConstructor
public class MtxResponseMulti extends BaseMtxResponseMulti implements IMtxResponseMulti {
    @JsonProperty("ResponseList")
    private List<MtxResponseSubscriber> responseList;
}

