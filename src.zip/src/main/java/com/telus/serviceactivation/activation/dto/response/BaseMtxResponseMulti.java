package com.telus.serviceactivation.activation.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;


@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@RequiredArgsConstructor
public class BaseMtxResponseMulti extends BaseDollarSignDto implements IMtxResponseMulti{
    @JsonProperty("Result")
    private int result;

    @JsonProperty("ResultText")
    private String resultText;

    @JsonProperty("RouteId")
    private int routeId;

    @JsonProperty("_resultCode")
    private int _resultCode;

    @JsonProperty("_resultText")
    private String _resultText;

    @JsonProperty("_resultType")
    private String _resultType;
}

