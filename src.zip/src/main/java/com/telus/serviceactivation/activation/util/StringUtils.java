package com.telus.serviceactivation.activation.util;

public class StringUtils {

    // Check if two strings are equal
    public static boolean areEqual(String str1, String str2) {
        return str1 != null && str1.equals(str2);
    }

    // Check if a string is null
    public static boolean isNull(String str) {
        return str == null;
    }

    // Check if a string is blank (null or empty or only whitespace)
    public static boolean isBlank(String str) {
        return str == null || str.trim().isEmpty();
    }

    // Check if a string is not blank
    public static boolean isNotBlank(String str) {
        return !isBlank(str);
    }

    // Get length of a string, returning 0 if null
    public static int length(String str) {
        return str != null ? str.length() : 0;
    }

    // Main method for testing purposes
    public static void main(String[] args) {
        // Test cases
        System.out.println(areEqual("test", "test")); // true
        System.out.println(areEqual("test", null));   // false
        System.out.println(isNull(null));              // true
        System.out.println(isBlank("   "));            // true
        System.out.println(isNotBlank("hello"));       // true
        System.out.println(length(null));               // 0
        System.out.println(length("hello"));            // 5
    }
}

