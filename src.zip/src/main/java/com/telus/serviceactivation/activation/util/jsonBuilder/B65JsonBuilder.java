package com.telus.serviceactivation.activation.util.jsonBuilder;

import org.springframework.stereotype.Component;


@Component("065")
public class B65JsonBuilder implements JsonBuilder {
}
