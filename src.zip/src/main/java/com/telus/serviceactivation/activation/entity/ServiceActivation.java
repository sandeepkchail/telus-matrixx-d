package com.telus.serviceactivation.activation.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.telus.serviceactivation.activation.dto.Feature;
import com.telus.serviceactivation.activation.dto.RelatedParty;
import lombok.*;

import java.util.List;


@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ServiceActivation {

    private Long id;

    private String category;
    private String description;
    private String serviceType;
    private String state;


    @JsonManagedReference
    private List<RelatedParty> relatedParties;


   /* @OneToMany(mappedBy = "serviceActivation", cascade = CascadeType.MERGE, orphanRemoval = true)
    @JsonManagedReference
    private List<RelatedParty> relatedParties = new ArrayList<>();*/

  /*  public void addRelatedParty(RelatedParty relatedParty) {
        relatedParties.add(relatedParty);
        relatedParty.setServiceActivation(this);
    }*/

   /* public void removeRelatedParty(RelatedParty relatedParty) {
        relatedParties.remove(relatedParty);
        relatedParty.setServiceActivation(null);
    }*/

    // Adding a ServiceCharacteristic
    public void addServiceCharacteristic(ServiceCharacteristic serviceCharacteristic) {
        serviceCharacteristics.add(serviceCharacteristic);
        serviceCharacteristic.setServiceActivation(this);
    }

    // Removing a ServiceCharacteristic
    public void removeServiceCharacteristic(ServiceCharacteristic serviceCharacteristic) {
        serviceCharacteristics.remove(serviceCharacteristic);
        serviceCharacteristic.setServiceActivation(null);
    }

    private List<ServiceCharacteristic> serviceCharacteristics;

    private List<Feature> features;

}

