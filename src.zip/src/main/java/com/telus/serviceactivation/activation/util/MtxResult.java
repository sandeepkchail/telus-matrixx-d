package com.telus.serviceactivation.activation.util;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

public enum MtxResult {
    SUCCESS(200),
    ILLEGAL_VALUE(10),
    NOT_FOUND(11),
    // Duplicate indexed field value
    CONFLICT(19),
    LOGIC_ERROR(28),
    TRANSITION_ERROR(33)
    ;

    MtxResult(int code) {
        this.code = code;
    }

    @Getter
    private final int code;

    public int getCode() {
        return code;
    }
}
