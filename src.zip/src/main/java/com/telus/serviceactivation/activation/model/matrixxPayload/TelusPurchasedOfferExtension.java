package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.util.List;

@Data
public class TelusPurchasedOfferExtension {
    @JsonProperty("RatingSpecInstanceId")
    private String ratingSpecInstanceId;

    @JsonProperty("RatingSpecType")
    private String ratingSpecType;

    @JsonProperty("RateSpecSubType")
    private String rateSpecSubType;

    @JsonProperty("Priority")
    private Integer priority;

    @JsonProperty("AllowanceGrant")
    private Double allowanceGrant;

    @JsonProperty("GrantUOM")
    private String grantUOM;

    @JsonProperty("IsRollOver")
    private Integer isRollOver;

    @JsonProperty("ServiceFilterGroup")
    private List<String> serviceFilterGroup;

    @JsonProperty("ZoneFilterGroup")
    private List<String> zoneFilterGroup;

    @JsonProperty("NotificationStatus")
    private String notificationStatus;
}
