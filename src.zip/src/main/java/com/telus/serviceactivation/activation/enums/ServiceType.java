package com.telus.serviceactivation.activation.enums;

public enum ServiceType {
    POS_WLN, POS_WLS, PRE_WLS;
}
