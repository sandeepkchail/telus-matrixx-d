package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class TelusPurchasePackage {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("OfferId")
    private String offerId;

    @JsonProperty("OfferInstanceId")
    private String offerInstanceId;

    @JsonProperty("RatingSpecRecurrenceCd")
    private String ratingSpecRecurrenceCd;

    @JsonProperty("OfferTypeCd")
    private String offerTypeCd;

    @JsonProperty("OfferEffectiveDate")
    private String offerEffectiveDate;
}
