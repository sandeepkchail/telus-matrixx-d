package com.telus.serviceactivation.activation.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@RequiredArgsConstructor
public class MtxPurchasedOfferInfo {
    @JsonProperty("$")
    private String dollarSign;
    private String catalogItemExternalId;
    private int catalogItemId;
    private MtxPurchasedItemCycleInfo cycleInfo;
    private int recurringSuccessCycleCount;


    @JsonProperty("ActivationTime")
    private String activationTime;

    @JsonProperty("CurrentStatusTransitionTime")
    private String currentStatusTransitionTime;

    @JsonProperty("OfferLifecycleProfileId")
    private int offerLifecycleProfileId;

    @JsonProperty("OfferLifecycleProfileName")
    private String offerLifecycleProfileName;

    @JsonProperty("OfferStatusClass")
    private String offerStatusClass;

    @JsonProperty("OfferStatusDescription")
    private String offerStatusDescription;

    @JsonProperty("OfferStatusValue")
    private int offerStatusValue;

    @JsonProperty("OfferType")
    private int offerType;

    @JsonProperty("ParentResourceId")
    private int parentResourceId;

    @JsonProperty("PrimaryBalanceResourceId")
    private int primaryBalanceResourceId;

    @JsonProperty("ProductOfferExternalId")
    private String productOfferExternalId;

    @JsonProperty("ProductOfferId")
    private int productOfferId;

    @JsonProperty("ProductOfferVersion")
    private int productOfferVersion;

    @JsonProperty("PurchaseTime")
    private String purchaseTime;

    @JsonProperty("RequiredBalanceArray")
    private List<MtxRequiredBalanceInfo> requiredBalanceArray;

    @JsonProperty("ResourceId")
    private int resourceId;

    @JsonProperty("StartTime")
    private String startTime;

    @JsonProperty("Status")
    private String status;
}
