package com.telus.serviceactivation.activation.model.matrixxPayload.RCL;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.telus.serviceactivation.activation.model.matrixxPayload.TelusPurchasedOfferExtension;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
class OfferRequest {
    @JsonProperty("$")
    private String dollarSign;
    private String externalId;
    private TelusPurchasedOfferExtension attr;
}
