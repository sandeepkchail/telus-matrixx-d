package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MtxBillingCycleData {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("BillingCycleId")
    private String billingCycleId;

    @JsonProperty("DateOffset")
    private String dateOffset;

    @JsonProperty("NextBillingCycleCd")
    private String nextBillingCycleCd;

    @JsonProperty("NextBillingCycleEffectiveDate")
    private String nextBillingCycleEffectiveDate;

}

