package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.util.List;

@Data
public class MtxMobileDeviceExtension {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("AccessNumberArray")
    private List<String> accessNumberArray;

    @JsonProperty("Imsi")
    private String imsi;
}

