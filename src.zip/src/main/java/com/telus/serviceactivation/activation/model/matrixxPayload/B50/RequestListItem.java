package com.telus.serviceactivation.activation.model.matrixxPayload.B50;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class RequestListItem {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("Status")
    private String status;

    @JsonProperty("SubscriptionSearchData")
    private SubscriptionSearchData subscriptionSearchData;

    @JsonProperty("RelatedMsgId")
    private String relatedMsgId;
}
