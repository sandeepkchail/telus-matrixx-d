package com.telus.serviceactivation.activation.exception;

import com.telus.serviceactivation.activation.handler.MtxRespMulti;
import com.telus.serviceactivation.activation.util.StringFuncs;
import lombok.Getter;
import org.springframework.http.HttpStatus;
import com.telus.serviceactivation.activation.handler.MtxResponse;
//import tl.bil.utils.StringFuncs;

public class MtxErrorResponseException extends SystemException {

    @Getter
    private final MtxRespMulti response;

    public MtxRespMulti getResponse() {
        return response;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    @Getter
    private final HttpStatus httpStatus;

    public MtxErrorResponseException(HttpStatus status, MtxRespMulti mtxResponse, String responseBody) {
        super(StringFuncs.extend("Received error MtxResponse statusCode={} reasonPhrase={} mtxResponse.resultText={} responseBody={}",
                status.value(),
                status.getReasonPhrase(),
                mtxResponse.getResultText(),
                responseBody));
        this.httpStatus = status;
        this.response = mtxResponse;
    }

    public MtxErrorResponseException(HttpStatus status, MtxRespMulti mtxResponse) {
        super(StringFuncs.extend("Received error MtxResponse statusCode={} reasonPhrase={} mtxResponse.resultText={}",
                status.value(),
                status.getReasonPhrase(),
                mtxResponse.getResultText()
                )
        );
        this.httpStatus = status;
        this.response = mtxResponse;
    }
}
