package com.telus.serviceactivation.activation.util.jsonBuilder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class JsonBuilderFactory {

    private final Map<String, JsonBuilder> jsonBuilders;

    @Autowired
    public JsonBuilderFactory(Map<String, JsonBuilder> jsonBuilders) {
        this.jsonBuilders = jsonBuilders;
    }

    public JsonBuilder getJsonBuilder(String type) {
        return jsonBuilders.get(type);
    }
}
