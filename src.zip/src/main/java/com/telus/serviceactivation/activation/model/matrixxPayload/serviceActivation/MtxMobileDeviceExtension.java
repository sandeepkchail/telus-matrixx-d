package com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.util.List;

@Data
public class MtxMobileDeviceExtension {
    @JsonProperty("$")
    private String type;

    @JsonProperty("AccessNumberArray")
    private List<String> accessNumberArray;

    @JsonProperty("Imsi")
    private String imsi;
}

