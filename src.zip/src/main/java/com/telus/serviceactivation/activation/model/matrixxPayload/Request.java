package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation.*;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Request {
    @JsonProperty("$")
    private String dollarSign;
    private String status;
    private UserSearchData userSearchData;
    private String relatedMsgId;
    private String tenantId;
    private String externalId;
    private String contactPhoneNumber;
    private String language;
    private String notificationPreference;
    private Attr attr;
    private BillingCycle billingCycle;
    private List<RoleData> roleArray;

    private SubscriptionSearchData subscriptionSearchData;
    private List<OfferRequestData> offerRequestArray;
    private PurchasePackageData purchasePackageData;
    private List<SubscriberData> subscriberArray;
}
