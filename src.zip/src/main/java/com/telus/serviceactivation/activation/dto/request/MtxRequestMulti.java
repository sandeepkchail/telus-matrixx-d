package com.telus.serviceactivation.activation.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Data
@RequiredArgsConstructor
public class MtxRequestMulti {
    @JsonProperty("$")
    private String dollarSign;

    private List<MtxRequestSubscriberQuery> requestList;
}
