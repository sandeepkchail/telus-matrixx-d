package com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.telus.serviceactivation.activation.model.matrixxPayload.TelusPurchasedOfferExtension;
import lombok.Data;

@Data
public class MtxPurchasedOfferData {
    @JsonProperty("$")
    private String type;

    @JsonProperty("ExternalId")
    private String externalId;

    @JsonProperty("EndTimeRelativeOffset")
    private Integer endTimeRelativeOffset;

    @JsonProperty("EndTimeRelativeOffsetUnit")
    private Integer endTimeRelativeOffsetUnit;

    @JsonProperty("Attr")
    private TelusPurchasedOfferExtension attr;
}
