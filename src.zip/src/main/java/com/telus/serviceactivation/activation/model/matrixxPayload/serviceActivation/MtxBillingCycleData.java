package com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MtxBillingCycleData {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("BillingCycleId")
    private String billingCycleId;

    @JsonProperty("DateOffset")
    private String dateOffset;
}

