package com.telus.serviceactivation.activation.config.data;

import lombok.Data;

@Data
public class RequestList {
    private String relatedMsgId;
    private String tenantId;
    private String externalId;
}

