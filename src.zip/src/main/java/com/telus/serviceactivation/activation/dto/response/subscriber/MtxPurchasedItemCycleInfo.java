package com.telus.serviceactivation.activation.dto.response.subscriber;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.telus.serviceactivation.activation.dto.response.BaseDollarSignDto;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data@RequiredArgsConstructor
public class MtxPurchasedItemCycleInfo extends BaseDollarSignDto {
    @JsonProperty("CycleAlignmentType")
    private String cycleAlignmentType;

    @JsonProperty("CycleEndTime")
    private String cycleEndTime;

    @JsonProperty("CycleOffset")
    private int cycleOffset;

    @JsonProperty("CycleStartTime")
    private String cycleStartTime;

    @JsonProperty("CycleTimeOfDay")
    private String cycleTimeOfDay;

    @JsonProperty("IntervalId")
    private int intervalId;

    @JsonProperty("Period")
    private int period;

    @JsonProperty("PeriodInterval")
    private int periodInterval;

    @JsonProperty("ModifyAllowed")
    private boolean modifyAllowed;

}

