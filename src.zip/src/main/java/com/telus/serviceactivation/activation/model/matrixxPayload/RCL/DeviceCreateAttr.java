package com.telus.serviceactivation.activation.model.matrixxPayload.RCL;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.List;


@Data
@Builder
class DeviceCreateAttr {
    @JsonProperty("$")
    private String dollarSign;
    private List<String> accessNumberArray;
    private String imsi;
}
