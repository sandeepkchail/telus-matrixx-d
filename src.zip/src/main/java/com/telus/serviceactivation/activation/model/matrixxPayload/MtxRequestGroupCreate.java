package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MtxRequestGroupCreate extends RequestItem implements IRequestManager {
    @JsonProperty("TenantId")
    private String tenantId;

    @JsonProperty("ExternalId")
    private String externalId;

}
