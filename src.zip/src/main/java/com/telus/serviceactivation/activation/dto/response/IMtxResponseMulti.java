package com.telus.serviceactivation.activation.dto.response;

public interface IMtxResponseMulti {
}
