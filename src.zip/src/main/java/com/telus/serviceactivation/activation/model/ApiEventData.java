package com.telus.serviceactivation.activation.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ApiEventData {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("TransactionSequenceNumber")
    private String transactionSequenceNumber;

    @JsonProperty("TransactionEffectiveDate")
    private String transactionEffectiveDate;

    @JsonProperty("ActivityCd")
    private String activityCd;

    @JsonProperty("InitiatingApplicationCd")
    private String initiatingApplicationCd;
}
