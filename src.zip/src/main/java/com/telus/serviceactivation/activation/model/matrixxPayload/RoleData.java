package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;


@Data
public class RoleData  {
    @JsonProperty("$")
    private String dollarSign;
    private String pricingId;

}