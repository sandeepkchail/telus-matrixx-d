package com.telus.serviceactivation.activation.util;

import lombok.Getter;

import java.util.regex.Pattern;

public enum ReasonCode {

	S001_DEDUCT_MORE_THAN_AVAILABLE("ERR PROV_PKGS_SHARED : Trying to deduct more than available in total"),
	S007_NO_ENOUGH_SLOTS("ALLOW_21030: PO-reconfigureDailyRecurringPackageAdd : Not enough slots for Offer"),
	S10_SOC_SEQ_NOT_FOUND("BLOCK_21050: SocSequenceNumber not found in Subscriber Offer Table -- check entries in table, including Start / End dates"),
	// previous transaction is unprocessed in other node
	S020_CROSS_NODE_BLOCKING("CROSS_NODE_BLOCKING"),
	S021_INVALID_TRANSACTION("transaction is invalid"),
	S022_INVALID_REQUEST("request is invalid"),
	S023_NO_CONTRACT_FOUND("No Contract found"),
	S025_ALREADY_ASSIGNED("cannot be created because it is already assigned between"),
	S026_OLDER_THAN_3MONTH("Transaction effective timestamp is older than 3months"),
	S032_PHONE_NOT_UNDER_BAN("^phoneNumber [0-9]{10} is not under BAN [0-9]*$"),
	S033_NO_CHANGE_ON_CANCELED_SUB("No more changes allowed on a canceled subscriber except RCL"),
	S035_NOT_ALL_TASKS_SUCCEEDED("not all tasks succeeded"),
	S201_REUSED_OFFER_INSTANCE_ID("new offerInstanceId should be used to re-activate the offer"),
	S205_OFFER_ALREADY_EXPIRED("Not authorized - Message for NoAccess is : ALLOW_21081: The offer has already been expired"),
	S208_EXTERNAL_OFFER_SEQ_NUM_ALREADY_ADDED("ALLOW_210??: External Offer Sequence Number already added previously"),
	S218_OFFER_NOT_VALID("the entries in PO_BAU_OFFER_PACKAGE_DEFINITION are not valid for this OFFER-ID", true),
	S219_OFFER_NOT_FOUND("Offer/Package mapping not found in translation table"),
	S400_CLIENT_ERROR("client error"),
	S500_SYSTEM_ERROR("system error")
	;
	
	@Getter
	private String messagePattern;
	
	@Getter
	private boolean ignorable = false;
	
	private Pattern pattern;
	
	ReasonCode(String messagePattern) {
		this(messagePattern, false);
	}
	
	ReasonCode(String messagePattern, boolean ignorable) {
		this.messagePattern = messagePattern;
		pattern = Pattern.compile(messagePattern);
		this.ignorable = ignorable;
	}
	
	public boolean match(String message) {
		if (message == null) return false;
		if (message.indexOf(messagePattern) >= 0) return true;
		
		return pattern.matcher(message).find();
	}
}
