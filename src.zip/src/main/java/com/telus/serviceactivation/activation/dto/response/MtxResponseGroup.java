package com.telus.serviceactivation.activation.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class MtxResponseGroup extends BaseMtxResponseMulti implements IMtxResponseMulti {

    @JsonProperty("$")
    private String dollar;

    @JsonProperty("AdminCount")
    private int adminCount;

    @JsonProperty("AdminCursor")
    private int adminCursor;

    @JsonProperty("CurrentStatusTransitionTime")
    private String currentStatusTransitionTime;

    @JsonProperty("DeviceCount")
    private int deviceCount;

    @JsonProperty("ExternalId")
    private String externalId;

    @JsonProperty("GroupMemberCount")
    private int groupMemberCount;

    @JsonProperty("GroupMemberCursor")
    private int groupMemberCursor;

    @JsonProperty("LastActivityTime")
    private String lastActivityTime;

    @JsonProperty("MaxSubscriberCount")
    private long maxSubscriberCount;

    @JsonProperty("MaxUserCount")
    private long maxUserCount;

    @JsonProperty("NotificationPreference")
    private int notificationPreference;

    @JsonProperty("ObjectId")
    private String objectId;

    @JsonProperty("RelatedUserCursor")
    private int relatedUserCursor;

    @JsonProperty("Result")
    private int result;

    @JsonProperty("ResultText")
    private String resultText;

    @JsonProperty("RouteId")
    private int routeId;

    @JsonProperty("Status")
    private int status;

    @JsonProperty("StatusDescription")
    private String statusDescription;

    @JsonProperty("SubscriberCount")
    private int subscriberCount;

    @JsonProperty("SubscriberMemberCount")
    private int subscriberMemberCount;

    @JsonProperty("SubscriberMemberCursor")
    private int subscriberMemberCursor;

    @JsonProperty("SubscriberMemberIdArray")
    private List<String> subscriberMemberIdArray;

    @JsonProperty("TenantId")
    private String tenantId;

    @JsonProperty("UserCount")
    private int userCount;

    @JsonProperty("_resultCode")
    private int _resultCode;

    @JsonProperty("_resultText")
    private String _resultText;

    @JsonProperty("_resultType")
    private String _resultType;

}

