package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.telus.serviceactivation.activation.dto.ServiceCharacteristicRequestDto;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import org.springframework.stereotype.Component;

import static com.telus.serviceactivation.activation.constants.JsonConstants.OVERRIDE_ACITVITY_CODE;
import static com.telus.serviceactivation.activation.constants.JsonConstants.TRANSACTION_SEQUENCE_NUMBER;

@Component("MCN")
public class MCNJsonBuilder implements JsonBuilder{

    public String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {

        String overrideActivityCd = serviceRequestDto.getServiceCharacteristic().stream()
                    .filter(sc -> OVERRIDE_ACITVITY_CODE.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null);
        if ("NAC".equals(overrideActivityCd)) {
            NACJsonBuilder nacJsonBuilder = new NACJsonBuilder();
            return nacJsonBuilder.createJsonRequest(serviceRequestDto, activityCd);
        } else if ("CAN".equals(overrideActivityCd)) {
            CANJsonBuilder canJsonBuilder = new CANJsonBuilder();
            return canJsonBuilder.createJsonRequest(serviceRequestDto, activityCd);
        }
        return overrideActivityCd;
    }
}
