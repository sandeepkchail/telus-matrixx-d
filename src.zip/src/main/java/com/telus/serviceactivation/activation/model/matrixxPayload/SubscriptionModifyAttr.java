package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;


@Data
@Builder
class SubscriptionModifyAttr {
    @JsonProperty("$")
    private String dollarSign;
    private String geoTypeCd;
    private String pricePlanCd;
    private String pricePlanEffectiveDate;
    private String exceedAllowanceTypeCd;
    private String geoFenceStatus;
}
