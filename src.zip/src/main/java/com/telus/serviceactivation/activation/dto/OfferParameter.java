package com.telus.serviceactivation.activation.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.telus.serviceactivation.activation.deserializer.FeatureDeserializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class OfferParameter {
    private String parameterCd;
    private String parameterName;
   /* private LocalDateTime parameterEffectiveDate;
    private LocalDateTime parameterExpiryDate;*/
    private String parameterEffectiveDate;
    private String parameterExpiryDate;
    private String parameterValueTx;
}
