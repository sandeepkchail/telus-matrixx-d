package com.telus.serviceactivation.activation.dto.response.subscriber;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data@RequiredArgsConstructor
public class MtxPricingRoleInfo {

    @JsonProperty("ExternalId")
    private String externalId;

    @JsonProperty("Name")
    private String name;

    @JsonProperty("PricingId")
    private int pricingId;
}

