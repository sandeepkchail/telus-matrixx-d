package com.telus.serviceactivation.activation.dto.response.subscriber.subscriberThreshhold;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.telus.serviceactivation.activation.dto.response.subscriber.MtxBalanceInfo;
import com.telus.serviceactivation.activation.dto.response.subscriber.TelusSubscriberExtension;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@RequiredArgsConstructor
public class MtxResponseSubscriber {
    private int adminGroupCount;
    private int adminGroupCursor;
    private TelusSubscriberExtension attr;
    private List<MtxBalanceInfo> balanceArray;
}