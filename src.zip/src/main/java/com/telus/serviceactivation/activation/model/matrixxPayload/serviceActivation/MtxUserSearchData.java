package com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MtxUserSearchData {
    @JsonProperty("$")
    private String type;

    @JsonProperty("MultiRequestIndex")
    private String multiRequestIndex;
}

