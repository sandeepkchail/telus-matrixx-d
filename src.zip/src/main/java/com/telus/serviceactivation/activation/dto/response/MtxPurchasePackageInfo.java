package com.telus.serviceactivation.activation.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@RequiredArgsConstructor
public class MtxPurchasePackageInfo {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("Attr")
    private TelusPurchasePackage attr;

    @JsonProperty("CycleInfo")
    private MtxPurchasedItemCycleInfo cycleInfo;

    @JsonProperty("Name")
    private String name;

    @JsonProperty("PurchasedItemResourceIdArray")
    private List<Integer> purchasedItemResourceIdArray;

    @JsonProperty("ResourceId")
    private int resourceId;

}

