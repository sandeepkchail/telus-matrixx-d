package com.telus.serviceactivation.activation.model.matrixxPayload.RCL;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
class UserSearchData {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("UserSearchData")
    private String externalId;
}