package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MtxSubscriptionSearchData {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("MultiRequestIndex")
    private String multiRequestIndex;
}

