package com.telus.serviceactivation.activation.config.data;

import lombok.Data;

@Data
public class ApiEventData {
    private String initiatingApplicationCd;
}
