package com.telus.serviceactivation.activation.exception;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import com.telus.serviceactivation.activation.util.ReasonCode;
import com.telus.serviceactivation.activation.util.ResponseCode;

@Slf4j
@SuppressWarnings("serial")
public class SystemException extends ReasonedException {

	@Getter @Setter
	private ResponseCode responseCode = ResponseCode.SVC500;

	/**
	 * payload is used to carry more details about this exception
	 */
	@Getter
	private Object payload;

	public SystemException(String message, Object payload, Throwable t) {
		super(ReasonCode.S500_SYSTEM_ERROR, message, t);
		this.payload = payload;
//		log.error("SYSTEM_ERROR {}", message);
	}

	public SystemException(String message) {
		this(message, null, null);
	}

	public SystemException(String message, Throwable t) {
		this(message, null, t);
	}
	
	public SystemException(Throwable e) {
		this(null, null, e);
	}
}
