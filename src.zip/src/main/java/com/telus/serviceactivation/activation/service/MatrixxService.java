 package com.telus.serviceactivation.activation.service;

import com.telus.serviceactivation.activation.dto.CommonRequestDto;
import com.telus.serviceactivation.activation.entity.TMFTransaction;
import com.telus.serviceactivation.activation.exception.MtxErrorResponseException;
import com.telus.serviceactivation.activation.handler.MtxRespMulti;
import com.telus.serviceactivation.activation.handler.MtxResponseHandler;
import com.telus.serviceactivation.activation.handler.MtxResponseWrapper;
import com.telus.serviceactivation.activation.repository.TransactionRepository;
import com.telus.serviceactivation.activation.util.MtxResult;
import jakarta.transaction.SystemException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Service
public class MatrixxService {

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    MtxResponseWrapper mtxResponseWrapper;

    @Autowired
    private MtxResponseHandler mtxResponseHandler;

    @Autowired
    private TransactionRepository transactionRepository;

    private final ResourceLoader resourceLoader;

    public MatrixxService(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }

    String jsonStr = "";

    @Autowired
    private CommonRequestDto commonRequestDto;

    @Value("${matrixx.api.url}")
    private String url;


    public MtxRespMulti callMatrixx(String mtxJsonReq) throws SystemException {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> request = new HttpEntity<>(mtxJsonReq, headers);
        //MtxRespMulti mtxRespMulti;
        //mtxRespMulti =
        ResponseEntity<MtxRespMulti> resp = restTemplate.exchange(url, HttpMethod.POST,request, MtxRespMulti.class);;
        //try{
            //resp=restTemplate.exchange(url, HttpMethod.POST,request, MtxRespMulti.class);
            //String a=resp.getBody().getResultText();
        //}
        //catch(HttpClientErrorException e) {
            //e.printStackTrace();
            //MtxErrorResponseException mtxe=e.getResponseBodyAs(MtxErrorResponseException.class);
            //MtxRespMulti mtxres=mtxe.getResponse();
            //throw new MtxErrorResponseException(HttpStatus.OK, mtxres);
        //}

        //if (resp.getStatusCode().value() != MtxResult.SUCCESS.getCode()) {
        //    throw new MtxErrorResponseException(HttpStatus.OK, resp.getBody());
        //}

        return  resp.getBody();//mtxRespMulti;
    }

    public MtxResponseWrapper processRequest(String jsonString) throws Exception {
        log.info("jsonString:::: " + jsonString);
        MtxRespMulti mtxRespMulti = callMatrixx(jsonString);
        mtxResponseWrapper.setMtxResponseMulti(mtxRespMulti);
        mtxResponseWrapper.setErrorMessage(mtxResponseWrapper.getMtxResponseMulti().getResultText().equalsIgnoreCase("Ok")
                ? null : mtxResponseWrapper.getMtxResponseMulti().getResultText());
        return mtxResponseWrapper;
    }
}
