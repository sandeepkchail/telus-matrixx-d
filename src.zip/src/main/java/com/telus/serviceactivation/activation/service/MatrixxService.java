package com.telus.serviceactivation.activation.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.dto.CommonRequestDto;
import com.telus.serviceactivation.activation.dto.request.MtxRequestMulti;
import com.telus.serviceactivation.activation.dto.request.MtxRequestSubscriberQuery;
import com.telus.serviceactivation.activation.dto.request.MtxSubscriberSearchData;
import com.telus.serviceactivation.activation.dto.response.MtxResponseMulti;
import com.telus.serviceactivation.activation.entity.TMFTransaction;
import com.telus.serviceactivation.activation.handler.MtxRespMulti;
import com.telus.serviceactivation.activation.handler.MtxResponseHandler;
import com.telus.serviceactivation.activation.handler.MtxResponseWrapper;
import com.telus.serviceactivation.activation.repository.TransactionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;

@Slf4j
@Service
public class MatrixxService {

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    MtxResponseWrapper mtxResponseWrapper;

    @Autowired
    private MtxResponseHandler mtxResponseHandler;

    @Autowired
    private TransactionRepository transactionRepository;

    private final ResourceLoader resourceLoader;

    public MatrixxService(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }

    String jsonStr = "";

    @Autowired
    private CommonRequestDto commonRequestDto;

    @Value("${matrixx.api.url}")
    private String url;


    public MtxRespMulti callMatrixx(String mtxJsonReq) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> request = new HttpEntity<>(mtxJsonReq, headers);
        MtxRespMulti mtxRespMulti = restTemplate.postForObject(url, request, MtxRespMulti.class);
        return mtxRespMulti;
    }

    public MtxResponseWrapper processRequest(String jsonString) throws Exception {
        log.info("jsonString:::: " + jsonString);
        MtxRespMulti mtxRespMulti = callMatrixx(jsonString);
        mtxResponseWrapper.setMtxResponseMulti(mtxRespMulti);
        mtxResponseWrapper.setErrorMessage(mtxResponseWrapper.getMtxResponseMulti().getResultText().equalsIgnoreCase("Ok")
                ? null : mtxResponseWrapper.getMtxResponseMulti().getResultText());
        return mtxResponseWrapper;
    }

    public MtxResponseMulti getSubscriber(MtxRequestMulti mtxRequestMulti) throws Exception {
        String externalId = mtxRequestMulti.getRequestList().get(0).getSubscriberSearchData().getExternalId();
        log.info("externalId::::" + externalId);

        MtxRequestMulti request = new MtxRequestMulti();
        MtxRequestSubscriberQuery subscriberQuery = new MtxRequestSubscriberQuery();
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(externalId);
        subscriberQuery.setSubscriberSearchData(searchData);

        request.setRequestList(List.of(subscriberQuery));

        //restTemplate.postForObject(url, request, String.class);
        String fileName = "getSubscriber";
        MtxResponseMulti mtxResponseMulti = getMtxResponseMulti(fileName);
        log.info("mtxResponseMulti.getResponseList();::::" + mtxResponseMulti.getResponseList());

        return mtxResponseMulti;
    }


    public MtxResponseMulti getMtxResponseMulti(String fileName) {
        String jsonFilePath = "matrixx/json/response/" + fileName + ".json";

        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(jsonFilePath)) {
            log.info("inputStream::::" + inputStream);

            if (inputStream == null) {
                throw new FileNotFoundException("File not found: " + jsonFilePath);
            }
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.readValue(inputStream, MtxResponseMulti.class);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
