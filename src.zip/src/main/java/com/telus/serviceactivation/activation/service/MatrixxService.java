package com.telus.serviceactivation.activation.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Service
public class MatrixxService {

    @Autowired
    RestTemplate restTemplate;

    String jsonStr = "";

    @Value("${matrixx.api.url}")
    private String url;


    public String callMatrixx() {
        //String url = "http://10.17.174.143:8080/rsgateway/data/json";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> request = new HttpEntity<>(jsonStr, headers);
        String response = restTemplate.postForObject(url, request, String.class);
        log.info("Return  {}", response);

        return response;
    }

    public String processRequest(String jsonString) {
        jsonStr = jsonString;
        return callMatrixx();
    }
}
