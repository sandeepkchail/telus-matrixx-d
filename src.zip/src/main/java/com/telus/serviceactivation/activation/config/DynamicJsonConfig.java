package com.telus.serviceactivation.activation.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.Map;

//@Component
@Data
@Configuration
@ConfigurationProperties(prefix = "")
// @PropertySource("classpath:mtxJsonResponse/mtxJsonResponse.properties")//
public class DynamicJsonConfig {

    private Map<String, Map<String, Map<String, String>>> prefixes;
    public String getValue(String prefix, String propertyKey) {
        if (prefixes == null) {
            throw new IllegalStateException("Prefixes map is not initialized.");
        }
        return prefixes.getOrDefault(prefix, Map.of())
                .getOrDefault("MtxRequestMulti", Map.of())
                .get(propertyKey);
    }
}
