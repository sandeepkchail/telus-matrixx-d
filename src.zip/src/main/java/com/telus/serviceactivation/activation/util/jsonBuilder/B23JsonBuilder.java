package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.telus.serviceactivation.activation.constants.JsonConstants;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.model.matrixxPayload.*;
import org.springframework.stereotype.Component;

import java.util.Collections;

@Component("B23")
public class B23JsonBuilder implements JsonBuilder {

    @Override
    public String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {
        ApiEventData apiEventData=populateAPIEventData(serviceRequestDto,activityCd);
        RequestListItem request = new RequestListItem();
        request.setDollarSign(JsonConstants.MTX_REQUEST_SUBSCRIBER_MODIFY);

        MtxSubscriberSearchData subscriberSearchData = populateMtxSubscriberSearchData(serviceRequestDto);
        request.setSubscriberSearchData(subscriberSearchData);

        Attr attr = populateAttr(serviceRequestDto);
        request.setAttr(attr);

        MtxRequestMulti requestMulti=populateMtxRequestMulti(apiEventData, Collections.singletonList(request));
        return returnJsonString(requestMulti);
    }
}
