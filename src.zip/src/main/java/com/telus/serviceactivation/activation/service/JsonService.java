package com.telus.serviceactivation.activation.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.util.jsonBuilder.JsonBuilder;
import com.telus.serviceactivation.activation.util.jsonBuilder.JsonBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class JsonService {

    private final JsonBuilderFactory jsonBuilderFactory;

    @Autowired
    public JsonService(JsonBuilderFactory jsonBuilderFactory) {
        this.jsonBuilderFactory = jsonBuilderFactory;
    }

    public String createJson(String type, ServiceRequestDto serviceRequestDto) {
        JsonBuilder jsonBuilder = jsonBuilderFactory.getJsonBuilder(type);
        if (jsonBuilder != null) {
            try {
                return jsonBuilder.createJsonRequest(serviceRequestDto, type);
            } catch (JsonProcessingException e) {
                System.err.println("Error creating JSON: " + e.getMessage());
            }
        } else {
            System.err.println("JsonBuilder not found for type: " + type);
        }
        return null;
    }
}
