package com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class TelusSubscriberExtension {
    @JsonProperty("AccountSubTypeCd")
    private String accountSubTypeCd;

    @JsonProperty("AccountTypeCd")
    private String accountTypeCd;

    @JsonProperty("BillingAccountNumber")
    private String billingAccountNumber;

    @JsonProperty("BillingProvinceCd")
    private String billingProvinceCd;

    @JsonProperty("BillingCycleCd")
    private String billingCycleCd;

    @JsonProperty("BrandId")
    private String brandId;

    @JsonProperty("GeoTypeCd")
    private String geoTypeCd;

    @JsonProperty("PricePlanCd")
    private String pricePlanCd;

    @JsonProperty("PricePlanEffectiveDate")
    private String pricePlanEffectiveDate;

    @JsonProperty("ExceedAllowanceTypeCd")
    private String exceedAllowanceTypeCd;

    @JsonProperty("TelusTimeZone")
    private String telusTimeZone;

    @JsonProperty("MonthlyCapValue")
    private double monthlyCapValue;

    @JsonProperty("GeoFenceStatus")
    private String geoFenceStatus;
}

