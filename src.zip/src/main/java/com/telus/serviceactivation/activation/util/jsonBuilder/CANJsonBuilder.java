package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.telus.serviceactivation.activation.constants.JsonConstants;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.model.matrixxPayload.*;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Component("CAN")
public class CANJsonBuilder implements JsonBuilder{

    public String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {
        ApiEventData apiEventData=populateAPIEventData(serviceRequestDto,activityCd);
        List<IRequestManager> request = new java.util.ArrayList<>(List.of());
        RequestListItem subRequest = new RequestListItem();
        subRequest.setDollarSign(JsonConstants.MTX_REQUEST_SUBSCRIPTION_MODIFY);
        subRequest.setStatus("2");
        MtxSubscriptionSearchData mtxSubscriptionSearchData = populateSubscriptioSeachData(serviceRequestDto);
        subRequest.setMtxSubscriptionSearchData((!Objects.equals(mtxSubscriptionSearchData, null)) ? mtxSubscriptionSearchData : null);
        request.add(subRequest);

        RequestListItem devRequest = new RequestListItem();
        devRequest.setDollarSign(JsonConstants.MTX_REQUEST_DEVICE_MODIFY);
        devRequest.setStatus("2");
        MtxDeviceSearchData deviceSearchData=populateDeviceSeachData(serviceRequestDto);
        devRequest.setDeviceSearchData((!Objects.equals(deviceSearchData, null)) ? deviceSearchData : null);
        request.add(devRequest);
        MtxRequestMulti requestMulti=populateMtxRequestMulti(apiEventData,request);
        return returnJsonString(requestMulti);
    }

}
