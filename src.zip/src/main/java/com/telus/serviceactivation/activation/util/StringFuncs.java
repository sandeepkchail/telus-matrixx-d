package com.telus.serviceactivation.activation.util;

import org.springframework.util.Assert;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringFuncs {
	private StringFuncs() {}
	private static final Pattern NAMES_PATTERN = Pattern.compile("\\{[_a-zA-Z0-9]*\\}");

	/**
	 * Example:  extend("this is {} test", "a")
	 * 
	 * @param template 
	 * @param params
	 * @return
	 */
	public static String extend(String template, Object...params) 
	{
		Assert.notNull(template, "'template' must not be null");
		if (template.trim().length()==0 || params == null) {
			return template;
		}

		Matcher m = NAMES_PATTERN.matcher(template);
		StringBuilder sb = new StringBuilder();

		int end = 0;
		for (int i=0; i<params.length && m.find(); i++) {
			sb.append(template.substring(end, m.start()));
			sb.append(params[i]==null?"null":params[i]);
			end = m.end();
		}

		if (end > 0) {
			sb.append(template.substring(end));
		}
		else {
			return template;
		}

		return sb.toString();		
	}
	
	/**
	 * Example: extend("activity code is {code}", map("code"->"NAC"));
	 * 
	 * @param template
	 * @param params
	 * @return
	 */
	public static String extend(String template, Map<String, String> params) 
	{
		Assert.notNull(template, "'template' must not be null");
		if (template.trim().length()==0) {
			return "";
		}

		Matcher m = NAMES_PATTERN.matcher(template);
		StringBuilder sb = new StringBuilder();

		int end = 0;
		while (m.find()) {
			sb.append(template.substring(end, m.start()));
			String match = m.group(1);

			if (params != null && params.containsKey(match)) {
				sb.append(params.get(match));
			} else {
				throw new IllegalArgumentException("missing parameter " + match);
			}

			end = m.end();
		}

		if (end > 0) {
			sb.append(template.substring(end));
		}
		else {
			return template;
		}

		return sb.toString();
	}

	public static String extendSingle(String template, String placeholder, String value) {
		Map<String, String> params = new HashMap<>();
		params.put(placeholder, value);
		
		return extend(template, params);
	}
	
	public static String replaceLast(String string, String substring, String replacement)
	{
	  int index = string.lastIndexOf(substring);
	  if (index == -1) {
	    return string;
	  }
	  
	  return string.substring(0, index) + replacement
	          + string.substring(index+substring.length());
	}
	
	public static String adjustLength(String res, int maxSize) {
		return res.length() > maxSize ? res.substring(0, maxSize) : res;
	}
	
	public static String removeWhiteSpaces(String field) {
		return field==null?null:field.trim();
		
	}
	
}