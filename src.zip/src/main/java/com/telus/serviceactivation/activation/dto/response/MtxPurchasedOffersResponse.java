package com.telus.serviceactivation.activation.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;
@Data
@RequiredArgsConstructor
public class MtxPurchasedOffersResponse {

    @JsonProperty("Result")
    private int result;

    @JsonProperty("ResultText")
    private String resultText;

    @JsonProperty("RouteId")
    private int routeId;

    @JsonProperty("TenantId")
    private String tenantId;

    @JsonProperty("TimeZone")
    private String timeZone;

    @JsonProperty("UserCount")
    private int userCount;

    @JsonProperty("Offers")
    private List<MtxPurchasedOfferInfo> offers;

    @JsonProperty("RelatedUserArray")
    private List<MtxRelatedUserObject> relatedUserArray;
}
