package com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class BillingCycle {
    @JsonProperty("$")
    private String type;
    private String billingCycleId;
    private String dateOffset;

}