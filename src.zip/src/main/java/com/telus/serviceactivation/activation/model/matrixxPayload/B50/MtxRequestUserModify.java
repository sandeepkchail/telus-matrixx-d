package com.telus.serviceactivation.activation.model.matrixxPayload.B50;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MtxRequestUserModify implements Request {
    @JsonProperty("$")
    private String type;

    @JsonProperty("UserSearchData")
    private MtxUserSearchData userSearchData;

    @JsonProperty("RelatedMsgId")
    private String relatedMsgId;

    @JsonProperty("ContactEmail")
    private String contactEmail;

    @JsonProperty("ContactPhoneNumber")
    private String contactPhoneNumber;

    @JsonProperty("Language")
    private String language;
}

