package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.constants.JsonConstants;
import com.telus.serviceactivation.activation.dto.ServiceCharacteristicRequestDto;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.enums.ActivityCode;
import com.telus.serviceactivation.activation.model.matrixxPayload.ApiEventData;
import com.telus.serviceactivation.activation.model.matrixxPayload.MtxRequestMulti;
import com.telus.serviceactivation.activation.model.matrixxPayload.RequestListItem;
import com.telus.serviceactivation.activation.model.matrixxPayload.MtxSubscriptionSearchData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collections;


@Component("Suspend")
public class SuspendJsonBuilder implements JsonBuilder
{

    private final ObjectMapper objectMapper;

    @Autowired
    public SuspendJsonBuilder(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    public String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {

        MtxRequestMulti requestMulti = new MtxRequestMulti();
        requestMulti.setDollarSign(JsonConstants.MTX_REQUEST_MULTI);

        ApiEventData apiEventData = new ApiEventData();
        apiEventData.setDollarSign(JsonConstants.TELUS_API_EVENT_DATA_EXTENSION);
        apiEventData.setTransactionSequenceNumber(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> "transactionSequenceNumber".equals(sc.getName()))
//                .map(ServiceCharacteristicRequestDto::getValueContent)
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        apiEventData.setTransactionEffectiveDate(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> "transactionEffectiveDate".equals(sc.getName()))
//                .map(ServiceCharacteristicRequestDto::getValueContent)
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        apiEventData.setActivityCd(ActivityCode.SUS.getValue());
       // apiEventData.setInitiatingApplicationCd("FIFA PORTAL");

        requestMulti.setApiEventData(apiEventData);

        RequestListItem request = new RequestListItem();
        request.setDollarSign(JsonConstants.MTX_REQUEST_SUBSCRIPTION_MODIFY);
        request.setStatus("3");

        MtxSubscriptionSearchData mtxSubscriptionSearchData = new MtxSubscriptionSearchData();
        mtxSubscriptionSearchData.setDollarSign(JsonConstants.MTX_SUBSCRIPTION_SEARCH_DATA);
        mtxSubscriptionSearchData.setExternalId(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> "externalId".equals(sc.getName()))
//                .map(ServiceCharacteristicRequestDto::getValueContent)
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        request.setMtxSubscriptionSearchData(mtxSubscriptionSearchData);
        request.setRelatedMsgId("Suspending the account - Immediate Block");

        requestMulti.setRequestList(Collections.singletonList(request));

        // Converting to JSON string
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(requestMulti);

        // The JSON string
        System.out.println(jsonRequest);

        return jsonRequest;
    }





}

