package com.telus.serviceactivation.activation.dto.response.subscriber.subscriberThreshhold;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@RequiredArgsConstructor
public class TelusSubscriberExtension {
    private String accountSubTypeCd;
    private String accountTypeCd;
    private String billingAccountNumber;
    private String billingCycleCd;
    private String billingProvinceCd;
    private String brandId;
    private String exceedAllowanceTypeCd;
    private String geoFenceStatus;
    private String geoTypeCd;
    private double monthlyCapValue;
    private String pricePlanCd;
    private String pricePlanEffectiveDate;
    private String providerID;
    private String telusTimeZone;
}
