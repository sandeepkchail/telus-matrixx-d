package com.telus.serviceactivation.activation.dto.response.subscriber;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;


@JsonIgnoreProperties(ignoreUnknown = true)
@Data@RequiredArgsConstructor
public class MtxRequiredBalanceInfo {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("ClassId")
    private int classId;

    @JsonProperty("IsPrivate")
    private boolean isPrivate;

    @JsonProperty("ResourceId")
    private int resourceId;

    @JsonProperty("TemplateId")
    private int templateId;
}