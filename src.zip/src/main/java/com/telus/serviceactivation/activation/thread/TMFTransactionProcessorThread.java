package com.telus.serviceactivation.activation.thread;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.entity.TMFTransaction;
import com.telus.serviceactivation.activation.handler.MtxResponseWrapper;
import com.telus.serviceactivation.activation.repository.TransactionRepository;
import com.telus.serviceactivation.activation.service.MatrixxService;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


@Slf4j
@Component
public class TMFTransactionProcessorThread extends Thread {
    @Autowired
    private TransactionRepository tmftransactionRepository;

    @Autowired
    private MatrixxService matrixxService;

    private volatile boolean running = true;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @PostConstruct
    public void init() {
        start();
    }

    private final ScheduledExecutorService executorService;

    public TMFTransactionProcessorThread(@Value("${app.thread.pool-size}") int poolSize) {
        this.executorService = Executors.newScheduledThreadPool(poolSize);
    }

    @Value("${app.thread.pool-size}")
    int poolSize;

    @Value("${retry-count}")
    int retryCount;

    @Override
    public void run() {
        for (int i = 0; i < poolSize; i++) {
            int threadTaskId = i;
            executorService.scheduleAtFixedRate(() -> {
                try {
                    log.info("Current Thread Name: " + Thread.currentThread().getName() + " - Thread Task ID: " + threadTaskId);
                    processPendingTransactions();
                } catch (Exception e) {
                    log.error("Caught exception in task processPendingTransactions: " + e.getMessage());
                }
            }, 0, 1, TimeUnit.MINUTES);
        }
        // Running until 'running' is set to false
        while (running) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        shutdownExecutor();
    }

    @Transactional
    private void processPendingTransactions() {
        log.info("Checking for pending transactions...");

        List<TMFTransaction> pendingTMFTransactions = tmftransactionRepository.findFirstByStatusOrderByTransactionIdAsc("PENDING");

        if (!pendingTMFTransactions.isEmpty()) {
            for (TMFTransaction tmfTransaction : pendingTMFTransactions) {
                CompletableFuture.runAsync(() -> {
                    try {
                        processTMFTransaction(tmfTransaction);
                        log.info("Transaction processed and marked as completed for TRXN_ID: " + tmfTransaction.getTransactionId());
                    } catch (Exception e) {
                        log.error("Error processing transaction " + tmfTransaction.getTransactionId() + ": " + e.getMessage());
                        String errorForSaveInTrxnDB = e.getMessage().substring(e.getMessage().
                                lastIndexOf("_resultText") + 15, e.getMessage().
                                lastIndexOf("\",<EOL>    \"_resultType\""));
                        tmfTransaction.setErrorMessage(errorForSaveInTrxnDB);
                        tmfTransaction.setMtxResponse(e.getMessage());
                        if (tmfTransaction.getRetryCount() < retryCount)
                            tmfTransaction.setStatus("PENDING");
                        else
                            tmfTransaction.setStatus("FAILED");
                        tmfTransaction.setRetryCount(tmfTransaction.getRetryCount() + 1);
                        tmftransactionRepository.save(tmfTransaction);
                    }
                });
            }
        } else {
            log.info("No pending transactions found.");
        }
    }

    private void processTMFTransaction(TMFTransaction tmfTransaction) throws Exception {
        String jsonStr = tmfTransaction.getMtxRequest();
        MtxResponseWrapper mtxResponseWrapper = matrixxService.processRequest(jsonStr);
        String mtxResponse = objectMapper.writeValueAsString(mtxResponseWrapper.getMtxResponseMulti());

        tmfTransaction.setErrorMessage(mtxResponseWrapper.getErrorMessage());
        tmfTransaction.setMtxResponse(mtxResponse);
        tmfTransaction.setStatus("COMPLETE");
        tmftransactionRepository.save(tmfTransaction);
    }

    private void shutdownExecutor() {
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            executorService.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }

    @PreDestroy
    public void stopThread() {
        running = false;
    }
}