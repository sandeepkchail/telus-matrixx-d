package com.telus.serviceactivation.activation.thread;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.entity.TMFTransaction;
import com.telus.serviceactivation.activation.handler.MtxResponseWrapper;
import com.telus.serviceactivation.activation.repository.TransactionRepository;
import com.telus.serviceactivation.activation.service.MatrixxService;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Component
public class TMFTransactionProcessorThread extends Thread {
    @Autowired
    private TransactionRepository tmftransactionRepository;
    @Autowired
    private RestTemplate restTemplate;

    private volatile boolean running = true;

    @Autowired
    private MatrixxService matrixxService;

    @PostConstruct
    public void init() {
        start();
    }

    @Override
    public void run() {
        while (running) {
            // checkPendingTransactions();
            try {
                processPendingTransactions();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            try {
                Thread.sleep(1 * 60 * 1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    @Transactional
    private void processPendingTransactions() throws Exception {
        System.out.println("Checking for pending transactions...");

        List<TMFTransaction> pendingTMFTransactions = tmftransactionRepository.findFirstByStatusOrderByTransactionIdAsc("PENDING");

        if (!pendingTMFTransactions.isEmpty()) {
            TMFTransaction TMFTransaction = pendingTMFTransactions.get(0);
            System.out.println("Processing transaction with TRXN_ID: " + TMFTransaction.getTransactionId());
            processTMFTransaction(TMFTransaction);
            System.out.println("Transaction processed and marked as completed.");
        } else {
            System.out.println("No pending transactions found.");
        }
    }

    private void processTMFTransaction(TMFTransaction tmfTransaction) throws Exception {
        System.out.println("Processing transaction: " + tmfTransaction);
        String jsonStr = tmfTransaction.getMtxRequest();
        MtxResponseWrapper mtxResponseWrapper = matrixxService.processRequest(jsonStr);

        ObjectMapper objectMapper = new ObjectMapper();
        String mtxResponse = objectMapper.writeValueAsString(mtxResponseWrapper.getMtxResponseMulti());

        tmfTransaction.setErrorMessage(mtxResponseWrapper.getErrorMessage());
        tmfTransaction.setMtxResponse(mtxResponse);
        tmfTransaction.setStatus("COMPLETE");
        tmftransactionRepository.save(tmfTransaction);
    }

    @PreDestroy
    public void stopThread() {
        running = false;
    }
}
