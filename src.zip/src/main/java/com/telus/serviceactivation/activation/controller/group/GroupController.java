package com.telus.serviceactivation.activation.controller.group;

import com.telus.serviceactivation.activation.dto.request.subscriberInfo.MtxRequestMulti;
import com.telus.serviceactivation.activation.dto.request.subscriberInfo.MtxRequestSubscriberQuery;
import com.telus.serviceactivation.activation.dto.request.subscriberInfo.MtxSubscriberSearchData;
import com.telus.serviceactivation.activation.dto.response.BaseMtxResponseMulti;
import com.telus.serviceactivation.activation.dto.response.MtxResponseGroup;
import com.telus.serviceactivation.activation.service.GroupService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;

@RestController
public class GroupController {


    @Autowired
    private GroupService groupService;

    /*
        @GetMapping("/fetch-response")
        public MtxResponseGroup fetchResponse(@RequestParam String url) {
    */
    @GetMapping("/info/externalId/{externalId}")
    @Operation(summary = "GET Group Details ",
            description = "GET Group Details based on external ID")
    public ResponseEntity<MtxResponseGroup> getSubscriberByExternalId(@PathVariable String externalId) throws Exception {

        // Creating an instance of MtxSubscriberSearchData and set the externalId
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(externalId);

        // Creating an instance of MtxRequestSubscriberQuery and set the search data
        MtxRequestSubscriberQuery subscriberQuery = new MtxRequestSubscriberQuery();
        subscriberQuery.setDollarSign("$");
        subscriberQuery.setSubscriberSearchData(searchData);

        // Creating an instance of MtxRequestMulti and add the request query to the list
        MtxRequestMulti mtxRequestMulti = new MtxRequestMulti();
        mtxRequestMulti.setDollarSign("$");
        mtxRequestMulti.setRequestList(Collections.singletonList(subscriberQuery));

        MtxResponseGroup mtxResponseGroup = groupService.getGroupDetails(mtxRequestMulti);
        //return groupService.getGroupDetails(url);
        return ResponseEntity.ok(mtxResponseGroup);
    }
}
