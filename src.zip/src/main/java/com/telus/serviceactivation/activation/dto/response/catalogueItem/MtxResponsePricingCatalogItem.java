package com.telus.serviceactivation.activation.dto.response.catalogueItem;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.telus.serviceactivation.activation.dto.response.BaseDollarSignDto;
import lombok.Data;
import lombok.RequiredArgsConstructor;


@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@RequiredArgsConstructor
public class MtxResponsePricingCatalogItem extends BaseDollarSignDto {
    @JsonProperty("CatalogItemInfo")
    private MtxPricingCatalogItemDetailInfo catalogItemInfo;

    @JsonProperty("Result")
    private int result;

    @JsonProperty("ResultText")
    private String resultText;
}
