package com.telus.serviceactivation.activation.dto.response.subscriber.subscriberThreshhold;


import com.telus.serviceactivation.activation.dto.response.subscriber.MtxPricingRoleInfo;

import java.util.List;

public class MtxRelatedUserObject {
    private String externalId;
    private String objectId;
    private List<MtxPricingRoleInfo> roleInfoArray;
}

