package com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PurchasePackageData {
    @JsonProperty("$")
    private String dollarSign;
    private Attr attr;
    private int cycleOffsetType;
    private String name;
    private int periodInterval;
    private int periodType;
}