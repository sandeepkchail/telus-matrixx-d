package com.telus.serviceactivation.activation.dto.request.subscriberInfo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.telus.serviceactivation.activation.dto.request.BaseMtxRequestMulti;
import lombok.Data;
import lombok.RequiredArgsConstructor;


@Data
@RequiredArgsConstructor
public class MtxSubscriberSearchData extends BaseMtxRequestMulti {
    @JsonProperty("ExternalId")
    private String externalId;


}
