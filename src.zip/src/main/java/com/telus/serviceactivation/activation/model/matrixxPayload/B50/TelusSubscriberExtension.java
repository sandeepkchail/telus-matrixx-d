package com.telus.serviceactivation.activation.model.matrixxPayload.B50;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TelusSubscriberExtension {
    @JsonProperty("$")
    private String type;

    @JsonProperty("BillingProvinceCd")
    private String billingProvinceCd;
}

