package com.telus.serviceactivation.activation.handler;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
class MtxResponse {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("Result")
    private int result;

    @JsonProperty("ResultText")
    private String resultText;
}
