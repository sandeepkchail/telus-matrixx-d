package com.telus.serviceactivation.activation.dto.response.subscriber.subscriberThreshhold;

import java.util.List;

public class MtxResponseWallet {
    private List<MtxBalanceInfoSimple> balanceArray;
    private List<MtxBalanceInfoPeriodic> balanceInfoPeriodicArray;
    private List<MtxRelatedUserObject> relatedUserArray;
    private int relatedUserCursor;
    private int result;
    private String resultText;
    private int status;
    private String statusDescription;
    private String tenantId;
    private String timeZone;
    private int userCount;
}
