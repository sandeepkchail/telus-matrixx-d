package com.telus.serviceactivation.activation.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Feature {

    private Long id;

    private String name;
    private List<FeatureCharacteristic> featureCharacteristic;
    private ServiceActivation serviceActivation;
    @JsonProperty("@type")
    private String type;
}
