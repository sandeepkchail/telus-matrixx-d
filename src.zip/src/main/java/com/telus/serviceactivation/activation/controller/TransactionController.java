package com.telus.serviceactivation.activation.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.telus.serviceactivation.activation.dto.CommonRequestDto;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.enums.ActivityCode;
import com.telus.serviceactivation.activation.exception.DataAlreadyExistsException;
import com.telus.serviceactivation.activation.handler.TransactionHandler;
import com.telus.serviceactivation.activation.service.ProvisionService;
//import com.telus.serviceactivation.activation.service.TransactionService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/tmf640/transaction/v3")
@Validated
public class TransactionController {

    @Autowired
    private ProvisionService provisionService;

    @Autowired
    private TransactionHandler transactionHandler;

    @Autowired
    private CommonRequestDto commonRequestDto;

    @PostMapping("/service")
    @Operation(summary = "Create a new connection",
            description = "Activation of new user connection with the provided details")
    public ResponseEntity<String> createServiceActivation(@Valid @RequestBody ServiceRequestDto serviceRequestDto) {
        commonRequestDto.setRequestParameter(serviceRequestDto);
        try {
            String savedServiceActivation = provisionService.commonTransaction(serviceRequestDto, commonRequestDto.getActivityCode());
            return ResponseEntity.ok(savedServiceActivation);
        } catch (DataAlreadyExistsException e) {
            log.error("Exception occurred: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Data already exists");
        } catch (Exception e) {
            log.error("Error occurred: ", e);
            return ResponseEntity.badRequest().body("Bad Request");
        }
    }

    @PatchMapping("/service/{externalId}/activityCd/{activityCd}")
    @Operation(summary = "Common operation", description = "Common operation with the provided details")
    public String commonService(@Valid @RequestBody ServiceRequestDto serviceRequestDto,
                                @PathVariable("externalId") String externalId,
                                @PathVariable("activityCd") String activityCd
    ) {
        log.info("Inside Common Service Controller: {}");
        commonRequestDto.setRequestParameter(serviceRequestDto);

        try {
            return provisionService.commonTransaction(serviceRequestDto, activityCd);
        } catch (DataAlreadyExistsException e) {
            log.error("Exception occurred: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("Error occurred: ", e);
            return "Bad Request";
        }
    }


    @DeleteMapping("/service/{externalId}")
    @Operation(summary = "Common operation",
            description = "Common operation with the provided details")
    public String removeService(@Valid @RequestBody ServiceRequestDto serviceRequestDto,
                                 @PathVariable("externalId") String externalId) throws JsonProcessingException {
        log.info("Inside Common Service Controller: {}");
        commonRequestDto.setRequestParameter(serviceRequestDto);
        return provisionService.commonTransaction(serviceRequestDto, "CAN");
        /*if (commonRequestDto.getExtId().equals(externalId)) {
            try {

            } catch (DataAlreadyExistsException e) {
                log.error("Exception occurred: {}", e.getMessage());
                throw e;
            } catch (Exception e) {
                log.error("Error occurred: ", e);
                return Boolean.FALSE;
            }
        }else {
            return Boolean.FALSE;
        }*/

    }

}
