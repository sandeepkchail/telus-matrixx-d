package com.telus.serviceactivation.activation.controller;

import com.telus.serviceactivation.activation.dto.CommonRequestDto;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.exception.DataAlreadyExistsException;
import com.telus.serviceactivation.activation.handler.TransactionHandler;
import com.telus.serviceactivation.activation.service.ProvisionService;
//import com.telus.serviceactivation.activation.service.TransactionService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/tmf640/transaction/v3")
@Validated
public class TransactionController {

    @Autowired
    private ProvisionService serviceService;

    @Autowired
    private TransactionHandler transactionHandler;

    @Autowired
    private CommonRequestDto commonRequestDto;
  /*  @PostMapping("/service")
    public ResponseEntity<String> activateService(@Valid @RequestBody ServiceActivationRequest request) {
        TMFTransaction transaction = transactionHandler.processRequest(request);
        return ResponseEntity.ok("Transaction created with ID: " + transaction.getTransactionId());
    }*/


    @PostMapping("/service")
    @Operation(summary = "Create a new connection",
            description = "Activation of new user connection with the provided details")
    public String createServiceActivation(@Valid @RequestBody ServiceRequestDto serviceRequestDto) {
        //log.info("Received request: {}", serviceActivation);

        // Debugging related parties
       /* serviceActivation.getRelatedParties().forEach(p -> {
            log.info("Related Party: ID = {}, Role = {}, ReferredType = {}", p.getId(), p.getRole(), p.getReferredType());
        });*/
        commonRequestDto.setRequestParameter(serviceRequestDto);
        try {
            String savedServiceActivation = serviceService.commonTransaction(serviceRequestDto, commonRequestDto.getActivityCode());
            return savedServiceActivation;
        } catch (DataAlreadyExistsException e) {
            log.error("Exception occurred: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("Error occurred: ", e);
            return "Bad Request";
        }
    }

/*
    @PostMapping("/service/{externalId}/activityCd/{activityCd}")
    @Operation(summary = "Suspend a connection",
            description = "Suspending of new user connection with the provided details")
    public String suspendServiceActivation(@Valid @RequestBody ServiceRequestDto serviceActivation,
                                          @PathVariable("externalId") String externalId,
                                          @PathVariable("activityCd") String activityCd
    ) {
        log.info("Received request: {}", serviceActivation);

        try {
            return serviceService.savingTransaction(serviceActivation);
        } catch (DataAlreadyExistsException e) {
            log.error("Exception occurred: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("Error occurred: ", e);
            return "Bad Request";
        }
    }*/


    @PatchMapping("/service/{externalId}/activityCd/{activityCd}")
    @Operation(summary = "Common operation",
            description = "Common operation with the provided details")
    public String commonService(@Valid @RequestBody ServiceRequestDto serviceActivation,
                                @PathVariable("externalId") String externalId,
                                @PathVariable("activityCd") String activityCd
    ) {

        log.info("Received request: {}");

        try {
            return serviceService.commonTransaction(serviceActivation, activityCd);
        } catch (DataAlreadyExistsException e) {
            log.error("Exception occurred: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("Error occurred: ", e);
            return "Bad Request";
        }
    }

}
