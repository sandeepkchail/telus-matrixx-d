package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;
/*
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestListItem {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("Status")
    private String status;

    @JsonProperty("MtxSubscriptionSearchData")
    private MtxSubscriptionSearchData mtxSubscriptionSearchData;

    @JsonProperty("RelatedMsgId")
    private String relatedMsgId;

    @JsonProperty("Attr")
    private Attr attr;


}*/


@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestListItem implements IRequestManager{
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("Status")
    private String status;

    @JsonProperty("MtxSubscriptionSearchData")
    private MtxSubscriptionSearchData mtxSubscriptionSearchData;

    @JsonProperty("MtxDeviceSearchData")
    private MtxDeviceSearchData deviceSearchData;

    @JsonProperty("RelatedMsgId")
    private String relatedMsgId;

    @JsonProperty("Attr")
    private Attr attr;

    private List<MtxRequestGroupCreate> mtxRequestGroupCreate;

    @JsonProperty("SubscriberSearchData")
    private MtxSubscriberSearchData subscriberSearchData;

    @JsonProperty("UserSearchData")
    private MtxUserSearchData userSearchData;

    @JsonProperty("TenantId")
    private String tenantId;

    @JsonProperty("MtxMobileDeviceExtension")
    private MtxMobileDeviceExtension mtxMobileDeviceExtension;

    @JsonProperty("BillingCycle")
    private MtxBillingCycleData billingCycleData;

    @JsonProperty("Language")
    private String language;

    @JsonProperty("billingProvinceCd")
    private String billingProvinceCd;

    @JsonProperty("customerEmailAddress")
    private String customerEmailAddress;

    @JsonProperty("accountLanguageCd")
    private String accountLanguageCd;

    @JsonProperty("accountSegmentCd")
    private String accountSegmentCd;

    @JsonProperty("accountSubSegmentCd")
    private String accountSubSegmentCd;
}
