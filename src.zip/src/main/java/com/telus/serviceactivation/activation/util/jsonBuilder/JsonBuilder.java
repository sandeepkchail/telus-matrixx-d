package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.constants.JsonConstants;
import com.telus.serviceactivation.activation.dto.ServiceCharacteristicRequestDto;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.enums.ActivityCode;
import com.telus.serviceactivation.activation.model.matrixxPayload.ApiEventData;
import com.telus.serviceactivation.activation.model.matrixxPayload.MtxRequestMulti;
import com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation.Attr;
import com.telus.serviceactivation.activation.model.matrixxPayload.suspend.RequestListItem;
import com.telus.serviceactivation.activation.model.matrixxPayload.suspend.SubscriptionSearchData;

import java.util.Collections;
import java.util.Objects;

import static com.telus.serviceactivation.activation.constants.JsonConstants.*;


public interface JsonBuilder {

    default String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {

        String initiatingApplicationCd = null;
        if (!activityCd.equals(ActivityCode.B65.getValue())) {
            initiatingApplicationCd = "UPDATE_BAN";
        }
        MtxRequestMulti requestMulti = new MtxRequestMulti();
        requestMulti.setDollarSign(JsonConstants.MTX_REQUEST_MULTI);
        ApiEventData apiEventData = ApiEventData.builder()
                .dollarSign(JsonConstants.TELUS_API_EVENT_DATA_EXTENSION)
                .transactionSequenceNumber(serviceRequestDto.getServiceCharacteristic().stream()
                        .filter(sc -> TRANSACTION_SEQUENCE_NUMBER.equals(sc.getName()))
                        .map(ServiceCharacteristicRequestDto::getValueContent)
                        .findFirst().orElse(null))
                .activityCd(ActivityCode.B65.getValue() != null ? ActivityCode.B65.getValue() : null)
                .initiatingApplicationCd(initiatingApplicationCd)
                .build();

        requestMulti.setApiEventData((!Objects.equals(apiEventData, null)) ? apiEventData : null);

        RequestListItem request = new RequestListItem();
        request.setDollarSign(JsonConstants.MTX_REQUEST_SUBSCRIPTION_MODIFY);

        Attr attr = new Attr();
        attr.setDollarSign(JsonConstants.TELUS_SUBSCRIBER_EXTENSION);
        attr.setBillingCycleCd(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> BILLING_CYCLE_CODE.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValueContent)
                .findFirst().orElse(null));

        //request.setAttr(!StringUtils.isNull(attr));
        request.setAttr((!Objects.equals(attr, null)) ? attr : null);

        SubscriptionSearchData subscriptionSearchData = new SubscriptionSearchData();
        subscriptionSearchData.setDollarSign(JsonConstants.MTX_SUBSCRIPTION_SEARCH_DATA);
        subscriptionSearchData.setExternalId(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> EXTERNAL_ID.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValueContent)
                .findFirst().orElse(null));

        request.setSubscriptionSearchData((!Objects.equals(subscriptionSearchData, null)) ? subscriptionSearchData : null);
        requestMulti.setRequestList(Collections.singletonList(request) != null ? Collections.singletonList(request) : null);

        // Converting to JSON string
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(requestMulti);

        return jsonRequest;
    }
}

