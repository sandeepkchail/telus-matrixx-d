package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.config.DynamicJsonConfig;
import com.telus.serviceactivation.activation.config.JsonRequestConfig;
import com.telus.serviceactivation.activation.constants.JsonConstants;
import com.telus.serviceactivation.activation.dto.ServiceCharacteristicRequestDto;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.model.matrixxPayload.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import static com.telus.serviceactivation.activation.constants.JsonConstants.*;

public interface JsonBuilder {

    String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException;

    /*default String populateValue(String prefix, JsonRequestConfig jsonRequestConfig) {
        MtxRequestMulti requestMulti = jsonRequestConfig.getMtxRequestMulti(prefix);
        if (requestMulti != null) {
            return String.format(
                    "Initiating Application Code: %s, Related Message ID: %s, Tenant ID: %s, External ID: %s",
                    requestMulti.getApiEventData().getInitiatingApplicationCd()
                    *//*requestMulti.getRequestList().getRelatedMsgId(),
                    requestMulti.getRequestList().getTenantId(),
                    requestMulti.getRequestList().getExternalId()*//*);
        }
        return "No data found for the given prefix.";
    }*/

   /* default String populateValue(String activityCd, DynamicJsonConfig dynamicJsonConfig) {
        String initiatingApplicationCd = dynamicJsonConfig.getValue(activityCd, "MtxRequestMulti.ApiEventData.InitiatingApplicationCd");
        String relatedMsgId = dynamicJsonConfig.getValue(activityCd, "MtxRequestMulti.RequestList.RelatedMsgId");
        String tenantId = dynamicJsonConfig.getValue(activityCd, "MtxRequestMulti.RequestList.TenantId");
        String externalId = dynamicJsonConfig.getValue(activityCd, "MtxRequestMulti.RequestList.ExternalId");

        return String.format(
                "Initiating Application Code: %s, Related Message ID: %s, Tenant ID: %s, External ID: %s",
                initiatingApplicationCd, relatedMsgId, tenantId, externalId);
    }*/


    default MtxRequestMulti populateMtxRequestMulti(ApiEventData apiEventData, List<IRequestManager> requestListItem) throws JsonProcessingException {

        MtxRequestMulti requestMulti = new MtxRequestMulti();
        requestMulti.setDollarSign(JsonConstants.MTX_REQUEST_MULTI);
        requestMulti.setApiEventData((!Objects.equals(apiEventData, null)) ? apiEventData : null);
        requestMulti.setRequestList(requestListItem);
        return requestMulti;
    }

    default String getInitiatingApplicationCd(String activityCd) {
        String response;
        switch (activityCd) {
            case "RCL":
                response = "NC";
                break;
            case "RSP":
                response = "RSP";
                break;
            case "NAC":
                response = "NC";
                break;
            default:
                response = null;
                break;
        }
        return response;
    }

    default MtxRequestGroupCreate populateMtxRequestGroupCreate() throws JsonProcessingException {
        MtxRequestGroupCreate groupCreate = new MtxRequestGroupCreate();
        groupCreate.setDollarSign(MTX_REQUEST_GROUP_CREATE);
        groupCreate.setRelatedMsgId("MSG: Create a group");
        groupCreate.setTenantId(TELUS);
        groupCreate.setExternalId("TMF_98765");
        return groupCreate;
    }

    default MtxRequestUserCreate populateMtxRequestUserCreate() throws JsonProcessingException {
        MtxRequestUserCreate userCreate = new MtxRequestUserCreate();
        userCreate.setDollarSign(MTX_REQUEST_USER_CREATE);
        userCreate.setRelatedMsgId("MSG: Create User");
        userCreate.setTenantId(TELUS);
        userCreate.setContactPhoneNumber("404567891");
        userCreate.setLanguage("EN");
        userCreate.setNotificationPreference("1");
        userCreate.setExternalId("UTMF_98765");
        return userCreate;
    }

    default MtxRequestSubscriptionCreate populateMtxRequestSubscriptionCreate() throws JsonProcessingException {
        MtxRequestSubscriptionCreate subscriptionCreate = new MtxRequestSubscriptionCreate();
        subscriptionCreate.setDollarSign(MTX_REQUEST_SUBSCRIPTION_CREATE);
        subscriptionCreate.setRelatedMsgId("MSG: Create a Subscription");
        subscriptionCreate.setTenantId(TELUS);
        subscriptionCreate.setExternalId("TMF_98767");
        subscriptionCreate.setTimeZone("America/Edmonton");

        TelusSubscriberExtension subscriberExtension = new TelusSubscriberExtension();
        subscriberExtension.setDollarSign(TELUS_SUBSCRIBER_EXTENSION);
        subscriberExtension.setAccountSubTypeCd("R");
        subscriberExtension.setAccountTypeCd("I");
        subscriberExtension.setBillingAccountNumber("1001604710000");
        subscriberExtension.setBillingProvinceCd("BC");
        subscriberExtension.setBillingCycleCd("11");
        subscriberExtension.setBrandId("1");
        subscriberExtension.setGeoTypeCd("GEOFENCE");
        subscriberExtension.setPricePlanCd("9159602850913498849");
        subscriberExtension.setPricePlanEffectiveDate("2021-06-23T20:47:47.732Z");
        subscriberExtension.setExceedAllowanceTypeCd("null");
        subscriberExtension.setTelusTimeZone("ESTNDLS");
        subscriberExtension.setMonthlyCapValue(45.0);
        subscriberExtension.setGeoFenceStatus("UNREGISTERED");
        subscriptionCreate.setAttr(subscriberExtension);

        MtxBillingCycleData billingCycle = new MtxBillingCycleData();
        billingCycle.setDollarSign(MTX_BILLING_CYCLE_DATA);
        billingCycle.setBillingCycleId("300");
        billingCycle.setDateOffset("{{dateOffset}}");
        subscriptionCreate.setBillingCycle(billingCycle);

        return subscriptionCreate;
    }


    default MtxRequestUserAddSubscription populateMtxRequestUserAddSubscription() throws JsonProcessingException {
        MtxRequestUserAddSubscription userAddSubscription = new MtxRequestUserAddSubscription();
        userAddSubscription.setDollarSign(MTX_REQUEST_USER_ADD_SUBSCRIPTION);
        userAddSubscription.setRelatedMsgId("Associate subscription to the user");

        MtxRoleData roleData = new MtxRoleData();
        roleData.setDollarSign(MTX_ROLE_DATA);
        roleData.setPricingId("1");

        userAddSubscription.setRoleArray(Arrays.asList(roleData));

        MtxUserSearchData userSearchData = new MtxUserSearchData();
        userSearchData.setDollarSign(MTX_USER_SEARCH_DATA);
        userSearchData.setMultiRequestIndex("1");
        userAddSubscription.setUserSearchData(userSearchData);

        MtxSubscriptionSearchData mtxSubscriptionSearchData = new MtxSubscriptionSearchData();
        mtxSubscriptionSearchData.setDollarSign(MTX_SUBSCRIPTION_SEARCH_DATA);
        mtxSubscriptionSearchData.setMultiRequestIndex("2");
        userAddSubscription.setMtxSubscriptionSearchData(mtxSubscriptionSearchData);
        return userAddSubscription;
    }

    default MtxRequestDeviceCreate populateMtxRequestDeviceCreate() throws JsonProcessingException {
        MtxRequestDeviceCreate deviceCreate = new MtxRequestDeviceCreate();
        deviceCreate.setDollarSign(MTX_REQUEST_DEVICE_CREATE);
        deviceCreate.setTenantId(TELUS);

        MtxMobileDeviceExtension deviceExtension = new MtxMobileDeviceExtension();
        deviceExtension.setDollarSign(MTX_MOBILE_DEVICE_EXTENSION);
        deviceExtension.setAccessNumberArray(List.of("404567891"));
        deviceExtension.setImsi("70089090999");

        deviceCreate.setAttr(deviceExtension);
        deviceCreate.setRelatedMsgId("New-Device");

        return deviceCreate;
    }

    default MtxRequestSubscriberAddDevice populateMtxRequestSubscriberAddDevice() throws JsonProcessingException {
        MtxRequestSubscriberAddDevice subscriberAddDevice = new MtxRequestSubscriberAddDevice();
        subscriberAddDevice.setDollarSign(MTX_REQUEST_SUBSCRIBER_ADD_DEVICE);
        subscriberAddDevice.setRelatedMsgId("Add-Device-Subscription");

        MtxSubscriberSearchData subscriberSearchData = new MtxSubscriberSearchData();
        subscriberSearchData.setDollarSign(MTX_SUBSCRIBER_SEARCH_DATA);
        subscriberSearchData.setMultiRequestIndex("2");
        subscriberAddDevice.setSubscriberSearchData(subscriberSearchData);

        MtxDeviceSearchData deviceSearchData = new MtxDeviceSearchData();
        deviceSearchData.setDollarSign(MTX_DEVICE_SEARCH_DATA);
        deviceSearchData.setMultiRequestIndex("4");
        subscriberAddDevice.setDeviceSearchData(deviceSearchData);

        return subscriberAddDevice;
    }

    default MtxRequestGroupAddMembership populateMtxRequestGroupAddMembership() throws JsonProcessingException {
        MtxRequestGroupAddMembership groupAddMembership = new MtxRequestGroupAddMembership();
        groupAddMembership.setDollarSign(MTX_REQUEST_GROUP_ADD_MEMBERSHIP);

        MtxGroupSearchData groupSearchData = new MtxGroupSearchData();
        groupSearchData.setDollarSign(MTX_GROUP_SEARCH_DATA);
        groupSearchData.setMultiRequestIndex("0");
        groupAddMembership.setGroupSearchData(groupSearchData);

        groupAddMembership.setRelatedMsgId("MSG: Add member to group");

        MtxSubscriberSearchData subscriberSearchData2 = new MtxSubscriberSearchData();
        subscriberSearchData2.setDollarSign(MTX_SUBSCRIBER_SEARCH_DATA);
        subscriberSearchData2.setMultiRequestIndex("2");

        groupAddMembership.setSubscriberArray(Arrays.asList(subscriberSearchData2));
        return groupAddMembership;

    }

    default MtxRequestSubscriberPurchaseOffer populateMtxRequestSubscriberPurchaseOfferFirstList() throws JsonProcessingException {
        MtxRequestSubscriberPurchaseOffer subscriberPurchaseOffer = new MtxRequestSubscriberPurchaseOffer();
        subscriberPurchaseOffer.setDollarSign(MTX_REQUEST_SUBSCRIBER_PURCHASE_OFFER);
        subscriberPurchaseOffer.setSubscriberSearchData(populateMtxSubscriberSearchData());

        MtxPurchasedOfferData offerData = new MtxPurchasedOfferData();
        offerData.setDollarSign(MTX_PURCHASED_OFFER_DATA);
        offerData.setExternalId("wHSIA: Setup Services");

        subscriberPurchaseOffer.setOfferRequestArray(Arrays.asList(offerData));
        subscriberPurchaseOffer.setRelatedMsgId("Subscription Purchase Setup Services");
        return subscriberPurchaseOffer;
    }

    default MtxSubscriberSearchData populateMtxSubscriberSearchData() throws JsonProcessingException {
        MtxSubscriberSearchData subscriberSearchData = new MtxSubscriberSearchData();
        subscriberSearchData.setDollarSign(MTX_SUBSCRIBER_SEARCH_DATA);
        subscriberSearchData.setMultiRequestIndex("2");
        return subscriberSearchData;
    }

    default MtxRequestSubscriberPurchaseOffer populateMtxRequestSubscriberPurchaseOfferSecondList() throws JsonProcessingException {
        MtxRequestSubscriberPurchaseOffer subscriberPurchaseOffer = new MtxRequestSubscriberPurchaseOffer();
        subscriberPurchaseOffer.setDollarSign(MTX_REQUEST_SUBSCRIBER_PURCHASE_OFFER);
        subscriberPurchaseOffer.setSubscriberSearchData(populateMtxSubscriberSearchData());

        MtxPurchasedOfferData offerData = new MtxPurchasedOfferData();
        offerData.setDollarSign(MTX_PURCHASED_OFFER_DATA);
        offerData.setExternalId("PO_WHSIA_Data_PLAN_MONTHLY_ALLOWANCE_Stackable_Recurring");

        TelusPurchasedOfferExtension attr = new TelusPurchasedOfferExtension();
        attr.setDollarSign(TELUS_PURCHASED_OFFER_EXTENSION);
        attr.setRatingSpecInstanceId("123123123125");
        attr.setRatingSpecType("ALLOWANCE");
        attr.setRateSpecSubType("DATA");
        attr.setPriority(10000);
        attr.setAllowanceGrant(100.0);
        attr.setGrantUOM("GB");
        attr.setIsRollOver(0);
        attr.setServiceFilterGroup(List.of("WISP1", "WISP6", "WISP7", "WISP8", "WISP11"));
        attr.setZoneFilterGroup(List.of("CAN"));
        attr.setNotificationStatus("Stackable");
        offerData.setAttr(attr);

        subscriberPurchaseOffer.setOfferRequestArray(Arrays.asList(offerData));

        MtxPurchasePackageData purchasePackageData = new MtxPurchasePackageData();
        purchasePackageData.setDollarSign(MTX_PURCHASED_PACKAGE_DATA);

        TelusPurchasePackage packageAttr = new TelusPurchasePackage();
        packageAttr.setDollarSign("TelusPurchasePackage");
        packageAttr.setOfferId("9159602850913490000");
        packageAttr.setOfferInstanceId("12332222");
        packageAttr.setRatingSpecRecurrenceCd("Monthly");
        packageAttr.setOfferTypeCd("PLAN");
        purchasePackageData.setAttr(packageAttr);

        purchasePackageData.setCycleOffsetType(1);
        purchasePackageData.setName("Base Plan");
        purchasePackageData.setPeriodInterval(1);
        purchasePackageData.setPeriodType(4);

        subscriberPurchaseOffer.setPurchasePackageData(purchasePackageData);
        subscriberPurchaseOffer.setRelatedMsgId("Subscription Purchase Offer");

        return subscriberPurchaseOffer;
    }

    default MtxRequestSubscriberPurchaseOffer populateMtxRequestSubscriberPurchaseOfferThirdList() throws JsonProcessingException {
        MtxRequestSubscriberPurchaseOffer subscriberPurchaseOffer = new MtxRequestSubscriberPurchaseOffer();
        subscriberPurchaseOffer.setDollarSign(MTX_REQUEST_SUBSCRIBER_PURCHASE_OFFER);
        subscriberPurchaseOffer.setSubscriberSearchData(populateMtxSubscriberSearchData());

        MtxPurchasedOfferData offerData1 = new MtxPurchasedOfferData();
        offerData1.setDollarSign(MTX_PURCHASED_OFFER_DATA);
        offerData1.setExternalId("PO_WHSIA_Data_PLAN_MONTHLY_ALLOWANCE_Stackable_Recurring");

        TelusPurchasedOfferExtension attr = new TelusPurchasedOfferExtension();
        attr.setDollarSign(TELUS_PURCHASED_OFFER_EXTENSION);
        attr.setRatingSpecInstanceId("123123123125");
        attr.setRatingSpecType("ALLOWANCE");
        attr.setRateSpecSubType("DATA");
        attr.setPriority(10000);
        attr.setAllowanceGrant(100.0);
        attr.setGrantUOM("GB");
        attr.setIsRollOver(0);
        attr.setServiceFilterGroup(List.of("WISP1", "WISP6", "WISP7", "WISP8", "WISP11"));
        attr.setZoneFilterGroup(List.of("CAN"));
        attr.setNotificationStatus("Stackable");
        offerData1.setAttr(attr);

        subscriberPurchaseOffer.setOfferRequestArray(Arrays.asList(offerData1));

        MtxPurchasePackageData purchasePackageData = new MtxPurchasePackageData();
        purchasePackageData.setDollarSign(MTX_PURCHASED_PACKAGE_DATA);

        TelusPurchasePackage packageAttr = new TelusPurchasePackage();
        packageAttr.setDollarSign(TELUS_PURCHASE_PACKAGE);
        packageAttr.setOfferId("9159602850913490000");
        packageAttr.setOfferInstanceId("12332222");
        packageAttr.setRatingSpecRecurrenceCd("BCIC");
        packageAttr.setOfferTypeCd("TOPUP");
        packageAttr.setOfferEffectiveDate("2021-06-23T20:47:47Z");
        purchasePackageData.setAttr(packageAttr);

        purchasePackageData.setCycleOffsetType(2);
        purchasePackageData.setName("BCIC Offer");
        purchasePackageData.setPeriodInterval(30);
        purchasePackageData.setPeriodType(2);

        subscriberPurchaseOffer.setPurchasePackageData(purchasePackageData);
        subscriberPurchaseOffer.setRelatedMsgId("Subscription Purchase TOPUP Offer");

        return subscriberPurchaseOffer;
    }


    default ApiEventData populateAPIEventData(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {
        ApiEventData apiEventData;
        apiEventData = ApiEventData.builder()
                .dollarSign(TELUS_API_EVENT_DATA_EXTENSION)
                .transactionSequenceNumber(serviceRequestDto.getServiceCharacteristic().stream()
                        .filter(sc -> TRANSACTION_SEQUENCE_NUMBER.equals(sc.getName()))
                        .map(ServiceCharacteristicRequestDto::getValue)
                        .findFirst().orElse(null))
                .transactionEffectiveDate(serviceRequestDto.getServiceCharacteristic().stream()
                        .filter(sc -> TRANSACTION_EFFECTIVE_DATE.equals(sc.getName()))
                        .map(ServiceCharacteristicRequestDto::getValue)
                        .findFirst().orElse(null))
                .activityCd(activityCd)
                .initiatingApplicationCd(getInitiatingApplicationCd(activityCd))
                .build();

        return apiEventData;
    }

    default Attr populateAttr(ServiceRequestDto serviceRequestDto) throws JsonProcessingException {
        Attr attr = new Attr();
        attr.setDollarSign(TELUS_SUBSCRIBER_EXTENSION);
        attr.setBillingCycleCd(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> BILLING_CYCLE_CODE.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        attr.setProviderID(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> PROVIDER_ID.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        // Assuming that Account Segment and Sub Segment will be stored at attribute level in Matrixx
        // This needs to be updated in case mapping with Matrix is changing
        attr.setAccountSegmentCd(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> ACCOUNT_SEGMENT.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        attr.setAccountSubSegmentCd(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> ACCOUNT_SUB_SEGMENT.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        return attr;
    }

    default MtxSubscriberSearchData populateMtxSubscriberSearchData(ServiceRequestDto serviceRequestDto) throws JsonProcessingException {
        MtxSubscriberSearchData subscriberSearchData = new MtxSubscriberSearchData();
        subscriberSearchData.setDollarSign(MTX_SUBSCRIBER_SEARCH_DATA);
        subscriberSearchData.setExternalId(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> EXTERNAL_ID.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));
        return subscriberSearchData;
    }

    default MtxBillingCycleData populateMtxBillingCycleData(ServiceRequestDto serviceRequestDto) throws JsonProcessingException {
        MtxBillingCycleData billingCycleData = new MtxBillingCycleData();
        billingCycleData.setDollarSign(MTX_BILLING_CYCLE_DATA);
        billingCycleData.setBillingCycleId(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> BILLING_CYCLE_CODE.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        billingCycleData.setNextBillingCycleCd(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> NEXT_BILLING_CYCLE_CD.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        billingCycleData.setNextBillingCycleEffectiveDate(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> NEXT_BILLING_CYCLE_EFF_DATE.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        return billingCycleData;
    }

    default MtxSubscriptionSearchData populateSubscriptioSeachData(ServiceRequestDto serviceRequestDto) throws JsonProcessingException {
        MtxSubscriptionSearchData mtxSubscriptionSearchData = new MtxSubscriptionSearchData();
        mtxSubscriptionSearchData.setDollarSign(JsonConstants.MTX_SUBSCRIPTION_SEARCH_DATA);
        mtxSubscriptionSearchData.setExternalId(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> EXTERNAL_ID.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));
        return mtxSubscriptionSearchData;
    }

    default String returnJsonString(MtxRequestMulti mtxRequestMulti) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(mtxRequestMulti);
        return jsonRequest;
    }

    default MtxDeviceSearchData populateDeviceSeachData(ServiceRequestDto serviceRequestDto) throws JsonProcessingException {
        MtxDeviceSearchData deviceSearchData = new MtxDeviceSearchData();
        deviceSearchData.setDollarSign(MTX_DEVICE_SEARCH_DATA);
        deviceSearchData.setAccessNumber(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> PHONE_NUMBER.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));
        return deviceSearchData;
    }
}

