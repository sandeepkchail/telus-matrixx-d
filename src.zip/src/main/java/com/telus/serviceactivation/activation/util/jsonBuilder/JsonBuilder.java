package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.constants.JsonConstants;
import com.telus.serviceactivation.activation.dto.ServiceCharacteristicRequestDto;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.model.matrixxPayload.*;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

import static com.telus.serviceactivation.activation.constants.JsonConstants.*;

public interface JsonBuilder {

    public abstract String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException;

    default MtxRequestMulti populateMtxRequestMulti(ApiEventData apiEventData, List<RequestListItem> requestListItem) throws JsonProcessingException {

        MtxRequestMulti requestMulti = new MtxRequestMulti();
        requestMulti.setDollarSign(JsonConstants.MTX_REQUEST_MULTI);
        requestMulti.setApiEventData((!Objects.equals(apiEventData, null)) ? apiEventData : null);
        //requestMulti.setRequestList(Collections.singletonList(requestListItem) != null ? Collections.singletonList(requestListItem) : null);
        requestMulti.setRequestList(requestListItem != null ? requestListItem : null);
        return requestMulti;
    }

    default ApiEventData populateAPIEventData(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {
        ApiEventData apiEventData;

        apiEventData = ApiEventData.builder()
                .dollarSign(JsonConstants.TELUS_API_EVENT_DATA_EXTENSION)
                .transactionSequenceNumber(serviceRequestDto.getServiceCharacteristic().stream()
                        .filter(sc -> TRANSACTION_SEQUENCE_NUMBER.equals(sc.getName()))
                        .map(ServiceCharacteristicRequestDto::getValueContent)
                        .findFirst().orElse(null))
                .transactionEffectiveDate(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> TRANSACTION_EFFECTIVE_DATE.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValueContent)
                .findFirst().orElse(null))
                .activityCd(activityCd)
                .build();

        return apiEventData;
    }

    default Attr populateAttr(ServiceRequestDto serviceRequestDto) throws JsonProcessingException {
        Attr attr = new Attr();
        attr.setDollarSign(JsonConstants.TELUS_SUBSCRIBER_EXTENSION);
        attr.setBillingCycleCd(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> BILLING_CYCLE_CODE.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValueContent)
                .findFirst().orElse(null));

        attr.setProviderID(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> PROVIDER_ID.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValueContent)
                .findFirst().orElse(null));

        //request.setAttr(!StringUtils.isNull(attr));
        return attr;
    }

    default SubscriptionSearchData populateSubscriptioSeachData(ServiceRequestDto serviceRequestDto) throws JsonProcessingException {
        SubscriptionSearchData subscriptionSearchData = new SubscriptionSearchData();
        subscriptionSearchData.setDollarSign(JsonConstants.MTX_SUBSCRIPTION_SEARCH_DATA);
        subscriptionSearchData.setExternalId(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> EXTERNAL_ID.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValueContent)
                .findFirst().orElse(null));
        return subscriptionSearchData;
    }
    default String returnJsonString(MtxRequestMulti mtxRequestMulti) throws JsonProcessingException
    {
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(mtxRequestMulti);
        return jsonRequest;
    }

    default MtxDeviceSearchData populateDeviceSeachData(ServiceRequestDto serviceRequestDto) throws JsonProcessingException {
        MtxDeviceSearchData deviceSearchData = new MtxDeviceSearchData();
        deviceSearchData.setDollarSign(MTX_DEVICE_SEARCH_DATA);
        deviceSearchData.setAccessNumber(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> PHONE_NUMBER.equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValueContent)
                .findFirst().orElse(null));
        return deviceSearchData;
    }

}

