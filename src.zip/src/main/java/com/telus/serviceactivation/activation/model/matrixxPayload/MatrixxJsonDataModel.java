package com.telus.serviceactivation.activation.model.matrixxPayload;


import lombok.Data;

@Data

public class MatrixxJsonDataModel {
    private String transactionSequenceNumber;
    private String transactionEffectiveDate;
    private String activityCd;
    private String externalId;

    public static MatrixxJsonDataModel getInstance(String transactionSequenceNumber,
                                                   String transactionEffectiveDate,
                                                   String activityCd,
                                                   String externalId) {
        MatrixxJsonDataModel instance = new MatrixxJsonDataModel();
        instance.setTransactionSequenceNumber(transactionSequenceNumber);
        instance.setTransactionEffectiveDate(transactionEffectiveDate);
        instance.setActivityCd(activityCd);
        instance.setExternalId(externalId);
        return instance;
    }
}



