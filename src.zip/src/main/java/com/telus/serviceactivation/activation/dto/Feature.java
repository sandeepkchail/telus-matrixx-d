package com.telus.serviceactivation.activation.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.telus.serviceactivation.activation.entity.ServiceActivation;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Feature {

   // private Long id;

    private String name;
    private List<FeatureCharacteristic> featureCharacteristic;
   // private ServiceActivation serviceActivation;
    @JsonProperty("@type")
    private String type;
}
