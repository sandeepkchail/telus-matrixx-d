package com.telus.serviceactivation.activation.controller.subscriber;

import com.telus.serviceactivation.activation.dto.request.subscriberInfo.MtxRequestMulti;
import com.telus.serviceactivation.activation.dto.request.subscriberInfo.MtxRequestSubscriberQuery;
import com.telus.serviceactivation.activation.dto.request.subscriberInfo.MtxSubscriberSearchData;
import com.telus.serviceactivation.activation.dto.response.BaseMtxResponseMulti;
import com.telus.serviceactivation.activation.service.MatrixxService;
import com.telus.serviceactivation.activation.service.SubscriberService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;



@Slf4j
@RestController
@RequestMapping("/subscriber")
@Validated
public class SubscriberController {
    @Autowired
    private SubscriberService subscriberService;


    @GetMapping("/info/externalId/{externalId}")
    @Operation(summary = "GET Subscriber information",
            description = "GET Subscriber information based on external ID")
    public ResponseEntity<BaseMtxResponseMulti> getSubscriberByExternalId(@PathVariable String externalId) throws Exception {
        // Creating an instance of MtxSubscriberSearchData and set the externalId
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(externalId);

        // Creating an instance of MtxRequestSubscriberQuery and set the search data
        MtxRequestSubscriberQuery subscriberQuery = new MtxRequestSubscriberQuery();
        subscriberQuery.setDollarSign("$");
        subscriberQuery.setSubscriberSearchData(searchData);

        // Creating an instance of MtxRequestMulti and add the request query to the list
        MtxRequestMulti mtxRequestMulti = new MtxRequestMulti();
        mtxRequestMulti.setDollarSign("$");
        mtxRequestMulti.setRequestList(Collections.singletonList(subscriberQuery));

        // Calling the service with the populated request object
        BaseMtxResponseMulti mtxResponseMulti = subscriberService.getSubscriber(mtxRequestMulti);

        return ResponseEntity.ok(mtxResponseMulti);
    }
}
