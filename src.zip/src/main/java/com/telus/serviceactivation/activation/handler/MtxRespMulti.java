package com.telus.serviceactivation.activation.handler;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
/*
@Data
public class MtxResponseMulti {

    @JsonProperty("$")
    private String dollarSign;

    private List<MtxResponse> ResponseList;

}*/
/*
@Data
public class MtxResponseMulti {

    @JsonProperty("$")
    private String dollarSign;

    private List<Response> responseList;

    private int result;

    private int routeId;

    @JsonProperty("_resultCode")
    private int resultCode;

    @JsonProperty("_resultText")
    private String resultText;

    @JsonProperty("_resultType")
    private String resultType;

    @Data
    public static class Response {

        @JsonProperty("$")
        private String dollarSign;

        private int result;

        private String resultText;

    }
}*/
/*

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Component
public class MtxRespMulti {

    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("Result")
    private int result;

    @JsonProperty("ResultText")
    private String resultText;

    @JsonProperty("ResponseList")
    private List<MtxResponse> responseList;

    @JsonProperty("RouteId")
    private int routeId;

    @JsonProperty("_resultCode")
    private int resultCode;

    @JsonProperty("_resultText")
    private String resultTextStatus;

    @JsonProperty("_resultType")
    private String resultType;
}

*/

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MtxRespMulti {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("ResponseList")
    private List<MtxResponse> responseList;

    @JsonProperty("Result")
    private int result;

    @JsonProperty("ResultText")
    private String resultText;

    @JsonProperty("RouteId")
    private int routeId;

    @JsonProperty("_resultCode")
    private int resultCode;

    @JsonProperty("_resultText")
    private String resultTextStatus;

    @JsonProperty("_resultType")
    private String resultType;
}
