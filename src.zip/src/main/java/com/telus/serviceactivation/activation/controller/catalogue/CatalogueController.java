package com.telus.serviceactivation.activation.controller.catalogue;

import com.telus.serviceactivation.activation.dto.request.catalogueItem.MtxPricingCatalogItemSearchData;
import com.telus.serviceactivation.activation.dto.request.catalogueItem.MtxRequestMulti;
import com.telus.serviceactivation.activation.dto.request.catalogueItem.MtxRequestPricingQueryCatalogItem;
import com.telus.serviceactivation.activation.dto.response.BaseMtxResponseMulti;
import com.telus.serviceactivation.activation.service.CatalogueService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.List;


@Slf4j
@RestController
@RequestMapping("/catalogue")
@Validated
public class CatalogueController {
    @Autowired
    private CatalogueService catalogueService;


    @GetMapping("/info/externalId/{externalId}")
    @Operation(summary = "GET Catalogue information",
            description = "GET Catalogue information based on external ID")
    public ResponseEntity<BaseMtxResponseMulti> getCatalogueByExternalId(@PathVariable String externalId) throws Exception {

        // Creating an instance of MtxPricingCatalogItemSearchData and set the externalId
        MtxPricingCatalogItemSearchData searchData = new MtxPricingCatalogItemSearchData();
        searchData.setExternalId("TPRE_Data_Immediat_UnBlock");

        MtxRequestPricingQueryCatalogItem queryCatalogItem = new MtxRequestPricingQueryCatalogItem();
        queryCatalogItem.setCatalogItemSearchData(searchData);

        MtxRequestMulti requestMulti = new MtxRequestMulti();
        requestMulti.setRequestList(List.of(queryCatalogItem));

        // Calling the service with the populated request object
        BaseMtxResponseMulti mtxResponseMulti = catalogueService.getCatalogueItem(requestMulti);

        return ResponseEntity.ok(mtxResponseMulti);
    }


}
