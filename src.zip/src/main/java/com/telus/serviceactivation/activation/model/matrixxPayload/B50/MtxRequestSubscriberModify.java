package com.telus.serviceactivation.activation.model.matrixxPayload.B50;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MtxRequestSubscriberModify implements Request {
    @JsonProperty("$")
    private String type;

    @JsonProperty("SubscriberSearchData")
    private MtxSubscriberSearchData subscriberSearchData;

    @JsonProperty("Attr")
    private TelusSubscriberExtension attr;
}

