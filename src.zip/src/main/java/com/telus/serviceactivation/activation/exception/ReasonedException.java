package com.telus.serviceactivation.activation.exception;

import lombok.Getter;
import com.telus.serviceactivation.activation.util.ReasonCode;

@SuppressWarnings("serial")
public class ReasonedException extends RuntimeException {
	
	@Getter
	private final ReasonCode reasonCode;
	
	public ReasonedException(ReasonCode reasonCode) {
		super(reasonCode.name());
		this.reasonCode = reasonCode;
	}
	
	public ReasonedException(ReasonCode reasonCode, String message) {
		super(message);
		this.reasonCode = reasonCode;
	}

	public ReasonedException(ReasonCode reasonCode, String message, Throwable t) {
		super(message, t);
		this.reasonCode = reasonCode;
	}
	
	public ReasonedException(ReasonCode reasonCode, Throwable t) {
		super(t);
		this.reasonCode = reasonCode;
	}
}
