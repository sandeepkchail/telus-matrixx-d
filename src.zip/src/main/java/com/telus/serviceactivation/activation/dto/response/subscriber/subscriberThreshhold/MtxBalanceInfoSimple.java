package com.telus.serviceactivation.activation.dto.response.subscriber.subscriberThreshhold;

import java.util.List;

public class MtxBalanceInfoSimple {
    private double amount;
    private double availableAmount;
    private int category;
    private int classId;
    private String className;
    private double creditLimit;
    private boolean isAggregate;
    private boolean isCreateExternalPaymentRequest;
    private boolean isCycleHolding;
    private boolean isMainBalance;
    private boolean isPeriodic;
    private boolean isPrepaid;
    private boolean isPrivate;
    private boolean isVirtual;
    private String name;
    private String quantityUnit;
    private double reservedAmount;
    private int resourceId;
    private String simpleBalanceGrantCreditFloorAdjust;
    private String startTime;
    private int templateId;
    private List<MtxThresholdInfo> thresholdArray;
    private double thresholdLimit;
}

