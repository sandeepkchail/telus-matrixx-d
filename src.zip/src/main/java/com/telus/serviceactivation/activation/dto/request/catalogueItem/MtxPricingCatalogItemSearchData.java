package com.telus.serviceactivation.activation.dto.request.catalogueItem;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.telus.serviceactivation.activation.dto.request.BaseMtxRequestMulti;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class MtxPricingCatalogItemSearchData extends BaseMtxRequestMulti {
    @JsonProperty("ExternalId")
    private String externalId;
}
