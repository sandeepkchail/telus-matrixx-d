package com.telus.serviceactivation.activation.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiceCharacteristicRequestDto {
    private Long id;
    private String name;
    private String value;
    private String valueType;
    //private ServiceActivation serviceActivation;

}
