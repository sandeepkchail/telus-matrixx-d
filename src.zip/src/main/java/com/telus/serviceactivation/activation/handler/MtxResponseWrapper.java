package com.telus.serviceactivation.activation.handler;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;
import lombok.ToString;

@ToString
@Data
@Component
@AllArgsConstructor
@NoArgsConstructor
public class MtxResponseWrapper {

    private MtxRespMulti mtxResponseMulti;
    private String errorMessage;

    /*public Boolean evaluateErrorResponse() {
        if (mtxResponseMulti != null && !mtxResponseMulti.getResultTextStatus().equals("OK")) {
            this.errorResponse = true;
        }

        return errorResponse;
    }*/
}
