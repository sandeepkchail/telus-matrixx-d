package com.telus.serviceactivation.activation.dto.request.catalogueItem;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.telus.serviceactivation.activation.dto.request.BaseMtxRequestMulti;
import com.telus.serviceactivation.activation.dto.response.BaseDollarSignDto;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@RequiredArgsConstructor
public class MtxRequestMulti extends BaseMtxRequestMulti {
    @JsonProperty("RequestList")
    private List<MtxRequestPricingQueryCatalogItem> requestList;
}
