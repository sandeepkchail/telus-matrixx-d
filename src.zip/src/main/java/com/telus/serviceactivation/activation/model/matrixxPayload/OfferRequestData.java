package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class OfferRequestData {
    @JsonProperty("$")
    private String type;
    private String externalId;
    private Attr attr;
}