package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.telus.serviceactivation.activation.constants.JsonConstants;
import com.telus.serviceactivation.activation.dto.ServiceCharacteristicRequestDto;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.model.matrixxPayload.*;
import org.springframework.stereotype.Component;

import java.util.Collections;

@Component("S10")
public class S10JsonBuilder implements JsonBuilder{
    @Override
    public String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {
        ApiEventData apiEventData=populateAPIEventData(serviceRequestDto,activityCd);
        RequestListItem request = new RequestListItem();
        request.setDollarSign(JsonConstants.MTX_REQUEST_USER_MODIFY);

        MtxSubscriptionSearchData mtxSubscriptionSearchData = populateSubscriptioSeachData(serviceRequestDto);
        MtxUserSearchData userSearchData = new MtxUserSearchData();
        userSearchData.setDollarSign(JsonConstants.MTX_USER_SEARCH_DATA);
        userSearchData.setMtxSubscriptionSearchData(mtxSubscriptionSearchData);

        request.setUserSearchData(userSearchData);

        request.setLanguage(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> "subscriberLanguageCd".equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        MtxRequestMulti requestMulti=populateMtxRequestMulti(apiEventData,Collections.singletonList(request));
        return returnJsonString(requestMulti);

    }
}
