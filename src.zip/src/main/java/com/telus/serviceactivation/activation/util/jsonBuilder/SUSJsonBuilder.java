package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.telus.serviceactivation.activation.constants.JsonConstants;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.model.matrixxPayload.ApiEventData;
import com.telus.serviceactivation.activation.model.matrixxPayload.MtxRequestMulti;
import com.telus.serviceactivation.activation.model.matrixxPayload.RequestListItem;
import com.telus.serviceactivation.activation.model.matrixxPayload.MtxSubscriptionSearchData;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Collections;

@Component("SUS")
public class SUSJsonBuilder implements JsonBuilder{

    public String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {
        ApiEventData apiEventData=populateAPIEventData(serviceRequestDto,activityCd);
        RequestListItem request = new RequestListItem();
        request.setDollarSign(JsonConstants.MTX_REQUEST_SUBSCRIPTION_MODIFY);
        request.setStatus("3");
        MtxSubscriptionSearchData mtxSubscriptionSearchData = populateSubscriptioSeachData(serviceRequestDto);
        request.setMtxSubscriptionSearchData((!Objects.equals(mtxSubscriptionSearchData, null)) ? mtxSubscriptionSearchData : null);
        MtxRequestMulti requestMulti=populateMtxRequestMulti(apiEventData,Collections.singletonList(request));
        return returnJsonString(requestMulti);
    }

}
