package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.constants.JsonConstants;
import com.telus.serviceactivation.activation.dto.ServiceCharacteristicRequestDto;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.enums.ActivityCode;
import com.telus.serviceactivation.activation.model.matrixxPayload.ApiEventData;
import com.telus.serviceactivation.activation.model.matrixxPayload.MtxRequestMulti;
import com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation.Attr;
import com.telus.serviceactivation.activation.model.matrixxPayload.suspend.RequestListItem;
import com.telus.serviceactivation.activation.model.matrixxPayload.suspend.SubscriptionSearchData;
import org.springframework.stereotype.Component;

import java.util.Collections;

@Component("NCH")
public class NetworkTypeChange implements JsonBuilder{
}
