package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import org.springframework.stereotype.Component;

//@Component("NCH")
public class NetworkTypeChange implements JsonBuilder{
    @Override
    public String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {
        return "";
    }
}
