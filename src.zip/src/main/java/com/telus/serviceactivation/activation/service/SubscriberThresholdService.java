package com.telus.serviceactivation.activation.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.dto.request.subscriberInfo.MtxRequestMulti;
import com.telus.serviceactivation.activation.dto.response.BaseMtxResponseMulti;
import com.telus.serviceactivation.activation.dto.response.subscriber.subscriberInfo.MtxResponseMulti;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
import java.io.InputStream;


@Slf4j
@Service
public class SubscriberThresholdService {


    public BaseMtxResponseMulti getSubscriberThreshold(MtxRequestMulti mtxRequestMulti) throws Exception {
        log.info("Inside getSubscriberThreshold() method 1 ::::");

        String externalId = mtxRequestMulti.getRequestList().get(0).getSubscriberSearchData().getExternalId();
        log.info("Inside getSubscriberThreshold() method 2 ::::");

        log.info("externalId::::" + externalId);

     /*   MtxRequestMulti request = new MtxRequestMulti();
        log.info("Inside getSubscriber() method 3 ::::");*/

      /*  MtxRequestSubscriberQuery subscriberQuery = new MtxRequestSubscriberQuery();
        MtxSubscriberSearchData searchData = new MtxSubscriberSearchData();
        searchData.setExternalId(externalId);
        subscriberQuery.setSubscriberSearchData(searchData);

        request.setRequestList(List.of(subscriberQuery));*/

        //restTemplate.postForObject(url, request, String.class);
        String fileName = "getSubscriberThreshold";
        MtxResponseMulti mtxResponseMulti = getMtxResponseMulti(fileName);
        log.info("mtxResponseMulti.getResponseList();::::" + mtxResponseMulti.getResponseList());

        return mtxResponseMulti;
    }

    public MtxResponseMulti getMtxResponseMulti(String fileName) {
        String jsonFilePath = "matrixx/json/response/" + fileName + ".json";

        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(jsonFilePath)) {
            log.info("inputStream::::" + inputStream);

            if (inputStream == null) {
                throw new FileNotFoundException("File not found: " + jsonFilePath);
            }
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.readValue(inputStream, MtxResponseMulti.class);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

}
