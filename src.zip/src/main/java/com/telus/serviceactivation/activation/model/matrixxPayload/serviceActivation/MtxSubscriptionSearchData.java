package com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MtxSubscriptionSearchData {
    @JsonProperty("$")
    private String type;

    @JsonProperty("MultiRequestIndex")
    private String multiRequestIndex;
}

