package com.telus.serviceactivation.activation.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@RequiredArgsConstructor
public class MtxResponseMulti {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("ResponseList")
    private List<MtxResponseSubscriber> responseList;

    @JsonProperty("Result")
    private int result;

    @JsonProperty("ResultText")
    private String resultText;

    @JsonProperty("RouteId")
    private int routeId;

    @JsonProperty("_resultCode")
    private int resultCode;

    @JsonProperty("_resultText")
    private String resultTextUpdate;

    @JsonProperty("_resultType")
    private String resultType;
}

