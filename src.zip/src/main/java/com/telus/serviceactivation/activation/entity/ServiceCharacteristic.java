package com.telus.serviceactivation.activation.entity;

import jakarta.persistence.Table;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ServiceCharacteristic {

    private Long id;

    private String name;

    private String valueContent;

    private String valueType;

    private ServiceActivation serviceActivation;
}

