package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MtxPurchasedOfferData {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("ExternalId")
    private String externalId;

    @JsonProperty("EndTimeRelativeOffset")
    private Integer endTimeRelativeOffset;

    @JsonProperty("EndTimeRelativeOffsetUnit")
    private Integer endTimeRelativeOffsetUnit;

    @JsonProperty("Attr")
    private TelusPurchasedOfferExtension attr;
}
