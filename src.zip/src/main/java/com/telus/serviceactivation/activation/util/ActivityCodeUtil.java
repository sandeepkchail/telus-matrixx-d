package com.telus.serviceactivation.activation.util;

import com.telus.serviceactivation.activation.enums.ActivityCode;

public class ActivityCodeUtil {

    public static String getActivityCodeMessage(ActivityCode code) {
        String jsonType;
        switch (code) {
            case ActivityCode.SUS:
                jsonType = ActivityCode.SUS.getValue();
                break;
            case ActivityCode.B65:
                jsonType = ActivityCode.B65.getValue();
                break;
            case ActivityCode.NCH:
                jsonType = ActivityCode.NCH.getValue();
                break;
            default:
                jsonType = null;
                break;
        }
        return jsonType;
    }
}
