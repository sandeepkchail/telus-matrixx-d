package com.telus.serviceactivation.activation.service;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.dto.request.catalogueItem.MtxPricingCatalogItemSearchData;
import com.telus.serviceactivation.activation.dto.request.catalogueItem.MtxRequestMulti;
import com.telus.serviceactivation.activation.dto.request.catalogueItem.MtxRequestPricingQueryCatalogItem;
import com.telus.serviceactivation.activation.dto.response.BaseMtxResponseMulti;
import com.telus.serviceactivation.activation.dto.response.catalogueItem.MtxResponseMulti;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;

@Slf4j
@Service
public class CatalogueService {

    public BaseMtxResponseMulti getCatalogueItem(MtxRequestMulti mtxRequestMulti) throws Exception {
        log.info("Inside getSubscriber() method 1 ::::");

        String externalId = mtxRequestMulti.getRequestList().get(0).getCatalogItemSearchData().getExternalId();
        log.info("Inside getSubscriber() method 2 ::::");

        log.info("externalId::::" + externalId);

       /* MtxRequestMulti request = new MtxRequestMulti();
        log.info("Inside getSubscriber() method 3 ::::");*/

        /*MtxRequestPricingQueryCatalogItem mtxRequestPricingQueryCatalogItem = new MtxRequestPricingQueryCatalogItem();
        MtxPricingCatalogItemSearchData searchData = new MtxPricingCatalogItemSearchData();
        searchData.setExternalId(externalId);
        mtxRequestPricingQueryCatalogItem.setCatalogItemSearchData(searchData);

        request.setRequestList(List.of(mtxRequestPricingQueryCatalogItem));*/

        //restTemplate.postForObject(url, request, String.class);
        String fileName = "getCatalogue";
        MtxResponseMulti mtxResponseMulti = getMtxResponseMulti(fileName);
        log.info("mtxResponseMulti.getResponseList():::::" + mtxResponseMulti.getResponseList());

        return mtxResponseMulti;
    }

    public MtxResponseMulti getMtxResponseMulti(String fileName) {
        String jsonFilePath = "matrixx/json/response/" + fileName + ".json";

        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(jsonFilePath)) {
            log.info("inputStream::::" + inputStream);

            if (inputStream == null) {
                throw new FileNotFoundException("File not found: " + jsonFilePath);
            }
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.readValue(inputStream, MtxResponseMulti.class);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
