package com.telus.serviceactivation.activation.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class MtxRequestSubscriberQuery {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("MtxSubscriberSearchData")
    private MtxSubscriberSearchData subscriberSearchData;
}
