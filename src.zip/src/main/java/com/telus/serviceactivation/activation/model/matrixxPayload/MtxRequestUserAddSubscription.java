package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.util.List;

@Data
public class MtxRequestUserAddSubscription extends RequestItem implements IRequestManager {
    @JsonProperty("RoleArray")
    private List<MtxRoleData> roleArray;

    @JsonProperty("UserSearchData")
    private MtxUserSearchData userSearchData;

    @JsonProperty("SubscriptionSearchData")
    private MtxSubscriptionSearchData subscriptionSearchData;
}

