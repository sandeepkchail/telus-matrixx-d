package com.telus.serviceactivation.activation.config;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class JsonRequestConfig {
    private boolean includeActivityCd;
    private String activityCd;

}
