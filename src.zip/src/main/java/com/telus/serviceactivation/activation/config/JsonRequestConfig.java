package com.telus.serviceactivation.activation.config;


import com.telus.serviceactivation.activation.config.data.MtxRequestMulti;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Component
@ConfigurationProperties(prefix = "")
public class JsonRequestConfig {
  /*  private MtxRequestMulti mtxRequestMulti;

    @Value("${NAC.MtxRequestMulti.ApiEventData.InitiatingApplicationCd}")
    private String initiatingApplicationCd;

    @Value("${NAC.MtxRequestMulti.RequestList.RelatedMsgId}")
    private String relatedMsgId;

    @Value("${NAC.MtxRequestMulti.RequestList.TenantId}")
    private String tenantId;

    @Value("${NAC.MtxRequestMulti.RequestList.ExternalId}")
    private String externalId;*/

    private Map<String, MtxRequestMulti> mtxRequestMulti;

    public MtxRequestMulti getMtxRequestMulti(String prefix) {
        return mtxRequestMulti.get(prefix);
    }
}
