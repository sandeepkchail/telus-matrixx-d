package com.telus.serviceactivation.activation.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class TelusPurchasePackage {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("OfferId")
    private String offerId;

    @JsonProperty("OfferInstanceId")
    private String offerInstanceId;

    @JsonProperty("OfferTypeCd")
    private String offerTypeCd;

    @JsonProperty("RatingSpecRecurrenceCd")
    private String ratingSpecRecurrenceCd;

}

