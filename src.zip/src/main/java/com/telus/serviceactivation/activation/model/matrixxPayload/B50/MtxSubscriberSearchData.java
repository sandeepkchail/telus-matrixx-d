package com.telus.serviceactivation.activation.model.matrixxPayload.B50;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MtxSubscriberSearchData {
    @JsonProperty("$")
    private String type;

    @JsonProperty("ExternalId")
    private String externalId;
}
