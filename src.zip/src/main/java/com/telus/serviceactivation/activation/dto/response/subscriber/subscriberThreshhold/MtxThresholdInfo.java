package com.telus.serviceactivation.activation.dto.response.subscriber.subscriberThreshhold;

public class MtxThresholdInfo {
    private double amount;
    private boolean eventEnabled;
    private String groupNotificationPreference;
    private boolean isCreditLimit;
    private boolean isCustom;
    private boolean isPct;
    private boolean isRecurring;
    private String name;
    private boolean notificationState;
    private int thresholdId;
    private String thresholdType;
    private String type;
}

