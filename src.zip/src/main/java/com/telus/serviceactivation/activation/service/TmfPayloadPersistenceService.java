package com.telus.serviceactivation.activation.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.dto.CommonRequestDto;
import com.telus.serviceactivation.activation.dto.ServiceCharacteristicRequestDto;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.entity.RetryTransaction;
import com.telus.serviceactivation.activation.entity.TMFTransaction;
import com.telus.serviceactivation.activation.enums.ActivityCode;
import com.telus.serviceactivation.activation.repository.TransactionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.telus.serviceactivation.activation.constants.JsonConstants.*;

@Slf4j
@Service
public class TmfPayloadPersistenceService {

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    TransactionRepository transactionRepository;

    @Autowired
    private CommonRequestDto commonRequestDto;

    public String saveDataInTmfTransaction(String matrixxJsonRequest, String tmfJsonPayload) throws JsonProcessingException {
        TMFTransaction transaction = new TMFTransaction();
        transaction.setExternalId(commonRequestDto.getExtId());
        transaction.setActivityCode(commonRequestDto.getActivityCode());
        transaction.setBan(commonRequestDto.getBan());
        transaction.setMtxRequest(matrixxJsonRequest);
        transaction.setTmfRequestPayload(tmfJsonPayload);
        transaction.setPhoneNumber(commonRequestDto.getPhoneNumber());// Saving the request payload as a string

        // Creating RetryTransaction
      /*  RetryTransaction retryTransaction = new RetryTransaction();
        retryTransaction.setTransaction(transaction);
        retryTransaction.setExternalId(extId);
        retryTransaction.setActivityCode(activityCode);
        retryTransaction.setBan(ban);*/

        //transaction.setRetryTransaction(retryTransaction);

        try {

            transactionRepository.save(transaction);
            log.info("TMFtransaction saved: {}", transaction);
        } catch (Exception e) {
            log.error("Error saving transaction: ", e);
        }
        return transaction.toString();
    }

    public boolean deleteDataInTmfTransaction(String matrixxJsonRequest, String tmfJsonPayload, String externalId) throws JsonProcessingException {
        saveDataInTmfTransaction(matrixxJsonRequest, tmfJsonPayload);

        Integer extId = Integer.valueOf(externalId);
        if (transactionRepository.existsByExternalId(extId)) {
            transactionRepository.deleteByExternalId(extId);
            return true;
        }
        return false;
    }

}
