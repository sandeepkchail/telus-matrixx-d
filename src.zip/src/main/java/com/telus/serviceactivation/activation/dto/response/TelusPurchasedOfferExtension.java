package com.telus.serviceactivation.activation.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;


@Data@RequiredArgsConstructor
public class TelusPurchasedOfferExtension {

    @JsonProperty("AllowanceGrant")
    private double allowanceGrant;

    @JsonProperty("GrantUOM")
    private String grantUOM;

    @JsonProperty("IsRollOver")
    private int isRollOver;

    @JsonProperty("NotificationStatus")
    private String notificationStatus;

    @JsonProperty("Priority")
    private int priority;

    @JsonProperty("RateSpecSubType")
    private String rateSpecSubType;

    @JsonProperty("RatingSpecInstanceId")
    private String ratingSpecInstanceId;

    @JsonProperty("RatingSpecType")
    private String ratingSpecType;

    @JsonProperty("ServiceFilterGroup")
    private List<String> serviceFilterGroup;

    @JsonProperty("ZoneFilterGroup")
    private List<String> zoneFilterGroup;
}
