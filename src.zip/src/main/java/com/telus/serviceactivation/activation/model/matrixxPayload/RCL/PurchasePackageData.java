package com.telus.serviceactivation.activation.model.matrixxPayload.RCL;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation.TelusPurchasePackage;
import lombok.Builder;
import lombok.Data;


@Data
@Builder
class PurchasePackageData {
    @JsonProperty("$")
    private String dollarSign;
    private TelusPurchasePackage attr;
    private int cycleOffsetType;
    private String name;
    private int periodInterval;
    private int periodType;
}