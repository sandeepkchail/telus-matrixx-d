package com.telus.serviceactivation.activation.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.gson.Gson;
import com.telus.serviceactivation.activation.dto.CommonRequestDto;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.enums.ActivityCode;
import com.telus.serviceactivation.activation.exception.ValidationException;
import com.telus.serviceactivation.activation.util.JsonConverter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
public class ProvisionService {


    @Autowired
    private TmfPayloadPersistenceService saveDataInTmfTransaction;

    @Autowired
    private JsonService jsonService;

    @Autowired
    private CommonRequestDto commonRequestDto;

    @Transactional
    public String savingTransaction(ServiceRequestDto serviceActivationDto) throws JsonProcessingException {

        System.out.println("Inside createServiceActivation method : ");

        // Validating the input DTO
        if (serviceActivationDto == null) {
            throw new ValidationException("Service activation request cannot be null");
        }

       /* TMFTransaction transaction = new TMFTransaction();

        // Mapping fields from the request to the transaction entity
        transaction.setExternalId(serviceActivationDto.getServiceCharacteristic().stream()
                .filter(sc -> "externalId".equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        transaction.setTxnSeqNo(serviceActivationDto.getServiceCharacteristic().stream()
                .filter(sc -> "transactionSequenceNumber".equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        transaction.setBillingAccountNum(serviceActivationDto.getServiceCharacteristic().stream()
                .filter(sc -> "billingAccountNumber".equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        transaction.setActivityCode(ActivityCode.valueOf(serviceActivationDto.getServiceCharacteristic().stream()
                .filter(sc -> "activityCd".equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse("NAC"))); // Default to NAC if not found

        transaction.setServiceType(serviceActivationDto.getServiceType());

        transaction.setRequestTime(LocalDate.now()); // Setting the request time
        transaction.setApiRequest(objectMapper.writeValueAsString(serviceActivationDto.toString())); // Saving the request payload as a string
*/
        // ApiJobs apiJobs = new ApiJobs();
        //apiJobs.getJobId();
        // apiJobs.setExternalId(serviceActivationDto.getServiceCharacteristic().stream().filter(sc -> "externalId".equals(sc.getName())).map(ServiceCharacteristicRequestDto::getValue).findFirst().orElse(null));

        //apiJobs.setUpdatedAt(LocalDate.now());
        //apiJobs.setTransaction(transaction);
        //transaction.setJobs(apiJobs);
        JsonConverter jsonConverter = new JsonConverter();
        //String responseStr = jsonConverter.convertToJson(responseDTO);
        String requestStr = jsonConverter.convertToJson(serviceActivationDto);
        //transaction.setApiRequest(requestStr);
        //transactionRepository.save(transaction);


        //ASync
       /* String matrixxJsonRequest = matrixxJsonConverter.convertToMatrixxJson(transaction, transaction.getActivityCode());
        transaction.setMatrixxJsonRequest(matrixxJsonRequest);
        transactionRepository.save(transaction);
        return matrixxService.processRequest(matrixxJsonRequest);*/

        return null;
    }


    @Transactional
    public String commonTransaction(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {
        log.info("Inside suspendAndSaveTransaction method : ");
        Gson gson = new Gson();

        // Convert the object to JSON string
        String tmfJsonPayload = gson.toJson(serviceRequestDto);

        // Print the JSON string
        System.out.println(tmfJsonPayload);

        String matrixxJsonRequest = "";
        matrixxJsonRequest = jsonService.createJson(activityCd, serviceRequestDto);
        return saveDataInTmfTransaction.saveDataInTmfTransaction(matrixxJsonRequest, tmfJsonPayload);
    }

    @Transactional
    public boolean deleteTransaction(ServiceRequestDto serviceRequestDto, String externalId) throws JsonProcessingException {
        log.info("Inside suspendAndSaveTransaction method : ");
        Gson gson = new Gson();

        // Convert the object to JSON string
        String tmfJsonPayload = gson.toJson(serviceRequestDto);

        // Print the JSON string
        System.out.println(tmfJsonPayload);

        String matrixxJsonRequest = "";
        matrixxJsonRequest = jsonService.createJson(commonRequestDto.getActivityCode(), serviceRequestDto);
        return saveDataInTmfTransaction.deleteDataInTmfTransaction(matrixxJsonRequest, tmfJsonPayload, externalId);
    }
}
