package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;


@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Attr {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("BillingCycleCd")
    private String billingCycleCd;

    @JsonProperty("ProviderID")
    private String providerID;
}
