package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;


@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Attr {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("BillingCycleCd")
    private String billingCycleCd;

    @JsonProperty("ProviderID")
    private String providerID;

    @JsonProperty("GeoTypeCd")
    private String geoTypeCd;

    @JsonProperty("PricePlanCd")
    private String pricePlanCd;

    @JsonProperty("PricePlanEffectiveDate")
    private String pricePlanEffectiveDate;

    @JsonProperty("ExceedAllowanceTypeCd")
    private String exceedAllowanceTypeCd;

    @JsonProperty("GeoFenceStatus")
    private String geoFenceStatus;

    @JsonProperty("AccountTypeCd")
    private String accountTypeCd;

    @JsonProperty("AccountSubTypeCd")
    private String accountSubTypeCd;

    @JsonProperty("BillingProvinceCd")
    private String billingProvinceCd;

    // Assuming that Account Segment and Sub Segment will be stored at attribute level in Matrixx
    // This needs to be updated in case mapping with Matrix is changing
    @JsonProperty("AccountSegmentCd")
    private String accountSegmentCd;

    @JsonProperty("AccountSubSegmentCd")
    private String accountSubSegmentCd;
    // Comment ends here

    @JsonProperty("Imsi")
    private String Imsi;

    @JsonProperty("AccessNumberArray")
    private List<String> AccessNumberArray;


}
