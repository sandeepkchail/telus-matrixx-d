package com.telus.serviceactivation.activation.repository;

import com.telus.serviceactivation.activation.entity.TMFTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransactionRepository extends JpaRepository<TMFTransaction, Long> {
    // Method to find TMFTransaction by externalId
    void deleteByExternalId(Integer externalId);

    // Optional: You can add a method to check if a transaction exists by externalId
    boolean existsByExternalId(Integer externalId);
}