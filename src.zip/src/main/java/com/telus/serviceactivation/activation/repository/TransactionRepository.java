package com.telus.serviceactivation.activation.repository;

import com.telus.serviceactivation.activation.entity.TMFTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<TMFTransaction, Long> {
    void deleteByExternalId(String externalId);

    boolean existsByExternalId(String externalId);

    List<TMFTransaction> findFirstByStatusOrderByTransactionIdAsc(String status);
}