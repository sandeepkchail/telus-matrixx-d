package com.telus.serviceactivation.activation.repository;

import com.telus.serviceactivation.activation.entity.TMFTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransactionRepository extends JpaRepository<TMFTransaction, Long> {

    /*Optional<ServiceActivation> findByExternalIdAndTransactionSequenceNumberAndBillingAccountNumberAndActivityCd(
            String externalId, String transactionSequenceNumber, String billingAccountNumber, String activityCd);*/
}