package com.telus.serviceactivation.activation.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class ServiceRequestDto {
    private String category;

    // @Size(min = 5, max = 30, message = "Description must be between 5 and 30 characters long")
    //@NotNull(message = "Category is required")
    private String description;

    // @NotNull(message = "Service type is required")
    // @Size(min = 1, max = 100, message = "Service type must be between 1 and 100 characters")
    private String serviceType;

   // private List<ResumeCancelFeature> feature;
   private List<Feature> feature;
    // @JsonProperty("relatedParties")
    private List<RelatedPartyRequestDto> relatedParties;

    //@NotNull(message = "Service characteristics are required")
    private List<ServiceCharacteristicRequestDto> serviceCharacteristic;

    private String state;

}
