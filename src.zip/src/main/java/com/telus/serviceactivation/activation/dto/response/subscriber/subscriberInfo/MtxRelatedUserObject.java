package com.telus.serviceactivation.activation.dto.response.subscriber.subscriberInfo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.telus.serviceactivation.activation.dto.response.subscriber.MtxPricingRoleInfo;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Data
@RequiredArgsConstructor
public class MtxRelatedUserObject {

    @JsonProperty("ExternalId")
    private String externalId;

    @JsonProperty("ObjectId")
    private String objectId;

    @JsonProperty("RoleInfoArray")
    private List<MtxPricingRoleInfo> roleInfoArray;
}

