package com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MtxRoleData {
    @JsonProperty("$")
    private String type;

    @JsonProperty("PricingId")
    private String pricingId;
}

