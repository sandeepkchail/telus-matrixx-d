package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MtxRequestDeviceCreate extends RequestItem implements IRequestManager {
    @JsonProperty("TenantId")
    private String tenantId;

    @JsonProperty("Attr")
    private MtxMobileDeviceExtension attr;
}

