package com.telus.serviceactivation.activation.dto.response.catalogueItem;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;


@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@RequiredArgsConstructor
public class MtxPricingCatalogItemDetailInfo {

    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("CatalogItemId")
    private int catalogItemId;

    @JsonProperty("Correction")
    private int correction;

    @JsonProperty("DeferredSettlementPurchaseAllowed")
    private boolean deferredSettlementPurchaseAllowed;

    @JsonProperty("Description")
    private String description;

    @JsonProperty("EffectiveTime")
    private String effectiveTime;

    @JsonProperty("ExternalId")
    private String externalId;

    @JsonProperty("HasPurchasedItemCycle")
    private boolean hasPurchasedItemCycle;

    @JsonProperty("IsOneTime")
    private boolean isOneTime;

    @JsonProperty("Name")
    private String name;

    @JsonProperty("OfferLifecycleProfileId")
    private int offerLifecycleProfileId;

    @JsonProperty("OfferLifecycleProfileName")
    private String offerLifecycleProfileName;

    @JsonProperty("PendingActivationPurchaseAllowed")
    private boolean pendingActivationPurchaseAllowed;

    @JsonProperty("PurchasePreActiveAllowed")
    private boolean purchasePreActiveAllowed;

    @JsonProperty("PurgeProfileId")
    private int purgeProfileId;

    @JsonProperty("Rev")
    private int rev;

    @JsonProperty("TemplateAttr")
    private TelusTemplate templateAttr;

    @JsonProperty("TemplateCorrection")
    private int templateCorrection;

    @JsonProperty("TemplateDescription")
    private String templateDescription;

    @JsonProperty("TemplateEffectiveTime")
    private String templateEffectiveTime;

    @JsonProperty("TemplateExternalId")
    private String templateExternalId;

    @JsonProperty("TemplateId")
    private int templateId;

    @JsonProperty("TemplateName")
    private String templateName;

    @JsonProperty("TemplateRev")
    private int templateRev;

    @JsonProperty("TemplateType")
    private String templateType;

    @JsonProperty("TemplateVersion")
    private int templateVersion;

    @JsonProperty("TemplateVersionDescription")
    private String templateVersionDescription;

    @JsonProperty("TemplateVersionName")
    private String templateVersionName;
}

