package com.telus.serviceactivation.activation.constants;

public class JsonConstants {
    public static final String MTX_REQUEST_MULTI = "MtxRequestMulti";
    public static final String TELUS_API_EVENT_DATA_EXTENSION = "TelusApiEventDataExtension";
    public static final String MTX_REQUEST_SUBSCRIPTION_MODIFY = "MtxRequestSubscriptionModify";
    public static final String MTX_SUBSCRIPTION_SEARCH_DATA = "MtxSubscriptionSearchData";
    public static final String MTX_REQUEST_USER_MODIFY = "MtxRequestUserModify";
    public static final String MTX_REQUEST_SUBSCRIBER_MODIFY = "MtxRequestSubscriptionModify";
    public static final String TELUS_SUBSCRIBER_EXTENSION = "TelusSubscriberExtension";

    public static final String TRANSACTION_SEQUENCE_NUMBER = "transactionSequenceNumber";

    public static final String BILLING_CYCLE_CODE = "billingCycleCd";
    public static final String EXTERNAL_ID = "externalId";
    public static final String ACITVITY_CODE = "activityCd";
    public static final String BILLING_ACCOUNT_NUMBER = "billingAccountNumber";
    public static final String TRANSACTION_EFFECTIVE_DATE = "transactionEffectiveDate";
    public static final String PHONE_NUMBER =   "phoneNumber";
}
