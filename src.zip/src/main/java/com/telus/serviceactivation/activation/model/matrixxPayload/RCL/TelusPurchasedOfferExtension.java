package com.telus.serviceactivation.activation.model.matrixxPayload.RCL;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.List;


@Data
@Builder
class TelusPurchasedOfferExtension {
    @JsonProperty("$")
    private String dollarSign;
    private String ratingSpecType;
    private int priority;
    private String allowanceGrant;
    private String grantUOM;
    private int isRollOver;
    private String exceedAllowanceTreatment;
    private List<String> serviceFilterGroup;
    private List<String> zoneFilterGroup;
    private String notificationStatus;
}