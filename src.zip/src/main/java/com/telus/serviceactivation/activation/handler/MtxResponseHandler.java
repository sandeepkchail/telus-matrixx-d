package com.telus.serviceactivation.activation.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class MtxResponseHandler {

   public String processMtxResponseResultText(String jsonResponse) throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();

        // Deserializing JSON to MtxRespMulti
        MtxRespMulti responseMulti = objectMapper.readValue(jsonResponse, MtxRespMulti.class);

        // Extracting ResultText values
       List<MtxResponse> responses = responseMulti.getResponseList();
        StringBuilder resultTextBuilder = new StringBuilder();

        for (MtxResponse response : responses) {
            if (resultTextBuilder.length() > 0) {
                resultTextBuilder.append(" || ");
            }
            resultTextBuilder.append(response.getResultText());
        }

      /* List<MtxResponseMulti.Response> responses = responseMulti.getResponseList();
        StringBuilder resultTextBuilder = new StringBuilder();

        for (MtxResponseMulti.Response response : responses) {
            if (resultTextBuilder.length() > 0) {
                resultTextBuilder.append(" || ");
            }
            resultTextBuilder.append(response.getResultText());
        }*/

        return resultTextBuilder.toString();
    }

   /* public String processMtxResponseResultText(String jsonResponse) throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();

        // Deserialize JSON to a list of MtxResponseMulti
        List<MtxRespMulti> responseMultiList = objectMapper.readValue(jsonResponse,
                objectMapper.getTypeFactory().constructCollectionType(List.class, MtxRespMulti.class));


        String resultText = responseMultiList.stream()
                .flatMap(mtxResponseMulti -> mtxResponseMulti.getResponseList().stream())
                .map(MtxResponse::getResultText)
                .collect(Collectors.joining(" || "));

        return resultText;
    }*/
}

