package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
class SubscriberSearchData extends MatrixxPayloadDataModel {
    @JsonProperty("$")
    private String dollarSign;
    private String externalId;
}