package com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MtxRequestDeviceCreate extends RequestItem {
    @JsonProperty("TenantId")
    private String tenantId;

    @JsonProperty("Attr")
    private MtxMobileDeviceExtension attr;
}

