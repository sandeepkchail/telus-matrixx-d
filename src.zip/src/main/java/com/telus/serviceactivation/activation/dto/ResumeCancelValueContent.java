package com.telus.serviceactivation.activation.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResumeCancelValueContent {

    private String offerId;
    //private LocalDateTime effectiveDate;
    //private LocalDateTime expiryDate;
    private String effectiveDate;
    private String expiryDate;
    private String offerCd;
    private String offerSequenceNumber;
    private String offerTypeCd;
    private String name;
    private String valueType;
    private List<OfferParameter> offerParameterList;
}
