package com.telus.serviceactivation.activation.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class BaseMtxRequestMulti {

    @JsonProperty("$")
    private String dollarSign;
}
