package com.telus.serviceactivation.activation.model.matrixxPayload;

public interface IRequestManager {
}
