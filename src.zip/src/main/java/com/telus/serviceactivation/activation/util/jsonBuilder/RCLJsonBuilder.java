package com.telus.serviceactivation.activation.util.jsonBuilder;

import org.springframework.stereotype.Component;

@Component("RCL")
public class RCLJsonBuilder implements JsonBuilder {
}
