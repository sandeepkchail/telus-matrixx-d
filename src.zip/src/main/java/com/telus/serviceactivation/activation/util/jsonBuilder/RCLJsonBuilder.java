package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import org.springframework.stereotype.Component;

@Component("RCL")
public class RCLJsonBuilder implements JsonBuilder {

    public String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {
//        ApiEventData apiEventData=populateAPIEventData(serviceRequestDto,activityCd);
//        //List<RequestListItem> request;//= new RequestListItem()[];
//        RequestListItem request = new RequestListItem();
//        request.setDollarSign(JsonConstants.MTX_REQUEST_SUBSCRIPTION_MODIFY);
//        request.setStatus("2");
//        SubscriptionSearchData subscriptionSearchData = populateSubscriptioSeachData(serviceRequestDto);
//        request.setSubscriptionSearchData((!Objects.equals(subscriptionSearchData, null)) ? subscriptionSearchData : null);
//        //request.add(requestListItem);
//        request.setDollarSign(JsonConstants.MTX_REQUEST_DEVICE_MODIFY);
//        request.setStatus("2");
//        MtxDeviceSearchData deviceSearchData=populateDeviceSeachData(serviceRequestDto);
//        request.setDeviceSearchData((!Objects.equals(deviceSearchData, null)) ? deviceSearchData : null);
//        MtxRequestMulti requestMulti=populateMtxRequestMulti(apiEventData,request);
//        return returnJsonString(requestMulti);
        return "";
    }

}
