package com.telus.serviceactivation.activation.util.jsonBuilder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.model.matrixxPayload.*;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.telus.serviceactivation.activation.constants.JsonConstants.*;

@Component("RCL")
public class RCLJsonBuilder implements JsonBuilder {

    @Override
    public String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {
        ApiEventData apiEventData = populateAPIEventData(serviceRequestDto, activityCd);
        List<IRequestManager> requestListItems = new ArrayList<>();

        RequestListItem userModifyRequest = createUserModifyRequest(serviceRequestDto);
        requestListItems.add(userModifyRequest);

        RequestListItem subscriptionModifyRequest = createSubscriptionModifyRequest(serviceRequestDto);
        requestListItems.add(subscriptionModifyRequest);

        RequestListItem deviceCreateRequest = createDeviceCreateRequest(serviceRequestDto);
        requestListItems.add(deviceCreateRequest);

        MtxRequestMulti requestMulti = populateMtxRequestMulti(apiEventData, requestListItems);

        return returnJsonString(requestMulti);
    }

    private RequestListItem createUserModifyRequest(ServiceRequestDto serviceRequestDto) {
        RequestListItem request = new RequestListItem();
        request.setDollarSign(MTX_REQUEST_USER_MODIFY);
        request.setStatus("1");

        MtxUserSearchData userSearchData = new MtxUserSearchData();
        userSearchData.setDollarSign(MTX_USER_SEARCH_DATA);
        userSearchData.setExternalId("UTMF_11112");

        request.setUserSearchData(userSearchData);
        request.setRelatedMsgId("Activating the User");

        return request;
    }

    private RequestListItem createSubscriptionModifyRequest(ServiceRequestDto serviceRequestDto) {
        RequestListItem request = new RequestListItem();
        request.setDollarSign(MTX_REQUEST_SUBSCRIPTION_MODIFY);
        request.setStatus("1");

        Attr attr = new Attr();
        attr.setDollarSign(TELUS_SUBSCRIBER_EXTENSION);
        attr.setGeoTypeCd(GEOFENCE);
        attr.setPricePlanCd("9159602850913498849");
        attr.setPricePlanEffectiveDate("2022-06-23T20:47:47.732Z");
        attr.setExceedAllowanceTypeCd("null");
        attr.setGeoFenceStatus("UNREGISTERED");

        request.setAttr(attr);

        MtxSubscriptionSearchData mtxSubscriptionSearchData = new MtxSubscriptionSearchData();
        mtxSubscriptionSearchData.setDollarSign(MTX_SUBSCRIPTION_SEARCH_DATA);
        mtxSubscriptionSearchData.setExternalId("TMF_11114");

        request.setMtxSubscriptionSearchData(mtxSubscriptionSearchData);
        request.setRelatedMsgId("Resuming the Subscription");

        return request;
    }

    private RequestListItem createDeviceCreateRequest(ServiceRequestDto serviceRequestDto) {
        RequestListItem request = new RequestListItem();
        request.setDollarSign(MTX_REQUEST_DEVICE_CREATE);
        request.setTenantId(TELUS);

        MtxMobileDeviceExtension mtxMobileDeviceExtension = new MtxMobileDeviceExtension();
        mtxMobileDeviceExtension.setDollarSign(MTX_MOBILE_DEVICE_EXTENSION);
        mtxMobileDeviceExtension.setAccessNumberArray(Arrays.asList("4045611111"));
        mtxMobileDeviceExtension.setImsi("70089011111");

        request.setMtxMobileDeviceExtension(mtxMobileDeviceExtension);
        request.setRelatedMsgId("New-Device");

        return request;
    }
}

