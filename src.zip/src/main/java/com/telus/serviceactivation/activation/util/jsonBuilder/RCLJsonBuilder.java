package com.telus.serviceactivation.activation.util.jsonBuilder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.dto.ServiceCharacteristicRequestDto;
import com.telus.serviceactivation.activation.model.matrixxPayload.*;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.telus.serviceactivation.activation.constants.JsonConstants.*;

@Component("RCL")
public class RCLJsonBuilder implements JsonBuilder {

    @Override
    public String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {
        ApiEventData apiEventData = populateAPIEventData(serviceRequestDto, activityCd);
        List<IRequestManager> requestListItems = new ArrayList<>();

        RequestListItem userModifyRequest = createUserModifyRequest(serviceRequestDto);
        requestListItems.add(userModifyRequest);

        RequestListItem subscriptionModifyRequest = createSubscriptionModifyRequest(serviceRequestDto);
        requestListItems.add(subscriptionModifyRequest);

        RequestListItem deviceCreateRequest = createDeviceCreateRequest(serviceRequestDto);
        requestListItems.add(deviceCreateRequest);

        requestListItems.add(populateMtxRequestSubscriberAddDevice(serviceRequestDto,"RCL"));

        // Offer needs to be revisited once everything is finalized
        requestListItems.add(populateMtxRequestSubscriberPurchaseOfferFirstList(serviceRequestDto,"RCL"));
        requestListItems.add(populateMtxRequestSubscriberPurchaseOffer(serviceRequestDto));
        requestListItems.add(populateMtxRequestSubscriberPurchaseOfferThirdList(serviceRequestDto,"RCL"));

        MtxRequestMulti requestMulti = populateMtxRequestMulti(apiEventData, requestListItems);
        return returnJsonString(requestMulti);
    }

}

