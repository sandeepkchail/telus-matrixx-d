package com.telus.serviceactivation.activation.dto.response;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@RequiredArgsConstructor
public class MtxBalanceInfo {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("Amount")
    private double amount;

    @JsonProperty("AvailableAmount")
    private String availableAmount;

    @JsonProperty("Category")
    private int category;

    @JsonProperty("ClassId")
    private int classId;

    @JsonProperty("ClassName")
    private String className;

    @JsonProperty("CreditLimit")
    private String creditLimit;

    @JsonProperty("IsAggregate")
    private boolean isAggregate;

    @JsonProperty("IsCreateExternalPaymentRequest")
    private boolean isCreateExternalPaymentRequest;

    @JsonProperty("IsPeriodic")
    private boolean isPeriodic;

    @JsonProperty("IsPrepaid")
    private boolean isPrepaid;

    @JsonProperty("IsPrivate")
    private boolean isPrivate;

    @JsonProperty("IsVirtual")
    private boolean isVirtual;

    @JsonProperty("Name")
    private String name;

    @JsonProperty("QuantityUnit")
    private String quantityUnit;

    @JsonProperty("ReservedAmount")
    private double reservedAmount;

    @JsonProperty("ResourceId")
    private int resourceId;

    @JsonProperty("StartTime")
    private String startTime;

    @JsonProperty("TemplateId")
    private int templateId;

    @JsonProperty("ThresholdLimit")
    private String thresholdLimit;

}
