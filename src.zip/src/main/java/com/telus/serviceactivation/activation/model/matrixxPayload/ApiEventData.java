package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApiEventData extends MatrixxPayloadDataModel{
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("TransactionSequenceNumber")
    private String transactionSequenceNumber;

    @JsonProperty("TransactionEffectiveDate")
    private String transactionEffectiveDate;

    @JsonProperty("ActivityCd")
    private String activityCd;

    @JsonProperty("InitiatingApplicationCd")
    private String initiatingApplicationCd;
}
