package com.telus.serviceactivation.activation.model.matrixxPayload.RCL;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;


@Data
@Builder
class TelusPurchasePackage {
    @JsonProperty("$")
    private String dollarSign;
    private String ratingSpecSubType;
    private String offerId;
    private String offerInstanceId;
    private String ratingSpecRecurrenceCd;
    private String offerTypeCd;
}