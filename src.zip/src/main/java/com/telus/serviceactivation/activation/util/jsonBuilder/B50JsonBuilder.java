package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.constants.JsonConstants;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.entity.TMFTransaction;
import com.telus.serviceactivation.activation.enums.ActivityCode;
import com.telus.serviceactivation.activation.model.matrixxPayload.ApiEventData;
import com.telus.serviceactivation.activation.model.matrixxPayload.B50.*;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("SUS")
public class B50JsonBuilder implements JsonBuilder{
}
