package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.telus.serviceactivation.activation.constants.JsonConstants;
import com.telus.serviceactivation.activation.dto.ServiceCharacteristicRequestDto;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.model.matrixxPayload.*;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("B50")
public class B50JsonBuilder implements JsonBuilder{

    public String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {
        ApiEventData apiEventData = populateAPIEventData(serviceRequestDto, activityCd);
        List<IRequestManager> requestList = new java.util.ArrayList<>(List.of());
        RequestListItem userRequest = new RequestListItem();
        userRequest.setDollarSign(JsonConstants.MTX_REQUEST_USER_MODIFY);

        MtxUserSearchData userSearchData = new MtxUserSearchData();
        userSearchData.setDollarSign(JsonConstants.MTX_USER_SEARCH_DATA);
        userSearchData.setExternalId(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> "externalId".equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        userRequest.setUserSearchData(userSearchData);

        userRequest.setCustomerEmailAddress(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> "customerEmailAddress".equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));
        userRequest.setAccountLanguageCd(serviceRequestDto.getServiceCharacteristic().stream()
                .filter(sc -> "accountLanguageCd".equals(sc.getName()))
                .map(ServiceCharacteristicRequestDto::getValue)
                .findFirst().orElse(null));

        requestList.add(userRequest);

        RequestListItem subscriberRequest = new RequestListItem();

        subscriberRequest.setDollarSign(JsonConstants.MTX_REQUEST_SUBSCRIBER_MODIFY);
        MtxSubscriberSearchData subscriberSearchData = populateMtxSubscriberSearchData(serviceRequestDto);
        subscriberRequest.setSubscriberSearchData(subscriberSearchData);

        Attr attr = populateAttr(serviceRequestDto);
        subscriberRequest.setAttr(attr);

        requestList.add(subscriberRequest);

        MtxRequestMulti requestMulti = populateMtxRequestMulti(apiEventData, requestList);
        return returnJsonString(requestMulti);
    }
}
