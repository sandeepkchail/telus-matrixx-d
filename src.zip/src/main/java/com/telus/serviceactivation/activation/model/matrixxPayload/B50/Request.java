package com.telus.serviceactivation.activation.model.matrixxPayload.B50;

public interface Request {
}
