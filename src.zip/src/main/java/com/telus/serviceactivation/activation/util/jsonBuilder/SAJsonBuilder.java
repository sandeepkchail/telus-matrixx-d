package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.constants.JsonConstants;
import com.telus.serviceactivation.activation.dto.CommonRequestDto;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.model.matrixxPayload.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

import static com.telus.serviceactivation.activation.constants.JsonConstants.*;

//@Component("NAC")
public class SAJsonBuilder implements JsonBuilder {

    @Autowired
    private CommonRequestDto commonRequestDto;


    public String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {

        MtxSARequestMulti requestMulti = new MtxSARequestMulti();
        requestMulti.setDollarSign(JsonConstants.MTX_REQUEST_MULTI);

        ApiEventData apiEventData = ApiEventData.builder()
                .dollarSign(JsonConstants.TELUS_API_EVENT_DATA_EXTENSION)
                .transactionSequenceNumber(commonRequestDto.getTransactionSequenceNumber())
                .transactionEffectiveDate(commonRequestDto.getTransactionEffectiveDate())
                .activityCd(commonRequestDto.getActivityCode())
                .initiatingApplicationCd(NC)
                .build();

        requestMulti.setApiEventData(apiEventData);

        List<IRequestManager> requestList = new ArrayList<>();

        // Creating MtxRequestGroupCreate
        MtxRequestGroupCreate groupCreate = new MtxRequestGroupCreate();
        groupCreate.setRelatedMsgId("MSG: Create a group");
        groupCreate.setTenantId("Telus");
        groupCreate.setExternalId("TMF_98765");
        requestList.add(groupCreate);

        // Creating MtxRequestUserCreate
        MtxRequestUserCreate userCreate = new MtxRequestUserCreate();
        userCreate.setRelatedMsgId("MSG: Create User");
        userCreate.setTenantId("Telus");
        userCreate.setContactPhoneNumber("404567891");
        userCreate.setLanguage("EN");
        userCreate.setNotificationPreference("1");
        userCreate.setExternalId("UTMF_98765");
        requestList.add(userCreate);


        // Creating an instance of MtxRequestSubscriptionCreate
        MtxRequestSubscriptionCreate subscriptionCreate = new MtxRequestSubscriptionCreate();
        subscriptionCreate.setDollarSign("MtxRequestSubscriptionCreate");
        subscriptionCreate.setRelatedMsgId("MSG: Create a Subscription");
        subscriptionCreate.setTenantId("Telus");
        subscriptionCreate.setExternalId("TMF_98767");
        subscriptionCreate.setTimeZone("America/Edmonton");

        // Creating the TelusSubscriberExtension
        TelusSubscriberExtension subscriberExtension = new TelusSubscriberExtension();
        subscriberExtension.setDollarSign("TelusSubscriberExtension");
        subscriberExtension.setAccountSubTypeCd("R");
        subscriberExtension.setAccountTypeCd("I");
        subscriberExtension.setBillingAccountNumber("1001604710000");
        subscriberExtension.setBillingProvinceCd("BC");
        subscriberExtension.setBillingCycleCd("11");
        subscriberExtension.setBrandId("1");
        subscriberExtension.setGeoTypeCd("GEOFENCE");
        subscriberExtension.setPricePlanCd("9159602850913498849");
        subscriberExtension.setPricePlanEffectiveDate("2021-06-23T20:47:47.732Z");
        subscriberExtension.setExceedAllowanceTypeCd("null");
        subscriberExtension.setTelusTimeZone("ESTNDLS");
        subscriberExtension.setMonthlyCapValue(45.0);
        subscriberExtension.setGeoFenceStatus("UNREGISTERED");

        // Setting the Attr in subscriptionCreate
        subscriptionCreate.setAttr(subscriberExtension);


        // Creating the BillingCycle
        MtxBillingCycleData billingCycle = new MtxBillingCycleData();
        billingCycle.setDollarSign("MtxBillingCycleData");
        billingCycle.setBillingCycleId("300");
        billingCycle.setDateOffset("{{dateOffset}}");

        // Set the BillingCycle in subscriptionCreate
        subscriptionCreate.setBillingCycle(billingCycle);
        requestList.add(subscriptionCreate);

        // Creating an instance of MtxRequestUserAddSubscription
        MtxRequestUserAddSubscription userAddSubscription = new MtxRequestUserAddSubscription();
        userAddSubscription.setDollarSign("MtxRequestUserAddSubscription");
        userAddSubscription.setRelatedMsgId("Associate subscription to the user");

        // Creating RoleArray
        MtxRoleData roleData = new MtxRoleData();
        roleData.setDollarSign("MtxRoleData");
        roleData.setPricingId("1");

        userAddSubscription.setRoleArray(Arrays.asList(roleData));

        // Creating UserSearchData
        MtxUserSearchData userSearchData = new MtxUserSearchData();
        userSearchData.setDollarSign("MtxUserSearchData");
        userSearchData.setMultiRequestIndex("1");
        userAddSubscription.setUserSearchData(userSearchData);


        // Creating MtxSubscriptionSearchData
        MtxSubscriptionSearchData mtxSubscriptionSearchData = new MtxSubscriptionSearchData();
        mtxSubscriptionSearchData.setDollarSign("MtxSubscriptionSearchData");
        mtxSubscriptionSearchData.setMultiRequestIndex("2");
        userAddSubscription.setMtxSubscriptionSearchData(mtxSubscriptionSearchData);

        requestList.add(userAddSubscription);

        // Creating an instance of MtxRequestDeviceCreate
        MtxRequestDeviceCreate deviceCreate = new MtxRequestDeviceCreate();
        deviceCreate.setDollarSign("MtxRequestDeviceCreate");
        deviceCreate.setTenantId("Telus");

        MtxMobileDeviceExtension deviceExtension = new MtxMobileDeviceExtension();
        deviceExtension.setDollarSign("MtxMobileDeviceExtension");
        deviceExtension.setAccessNumberArray(List.of("404567891"));
        deviceExtension.setImsi("70089090999");

        deviceCreate.setAttr(deviceExtension);
        deviceCreate.setRelatedMsgId("New-Device");

        requestList.add(deviceCreate);


        // Creating an instance of MtxRequestSubscriberAddDevice
        MtxRequestSubscriberAddDevice subscriberAddDevice = new MtxRequestSubscriberAddDevice();
        subscriberAddDevice.setDollarSign("MtxRequestSubscriberAddDevice");
        subscriberAddDevice.setRelatedMsgId("Add-Device-Subscription");

        MtxSubscriberSearchData subscriberSearchData = new MtxSubscriberSearchData();
        subscriberSearchData.setDollarSign("MtxSubscriberSearchData");
        subscriberSearchData.setMultiRequestIndex("2");
        subscriberAddDevice.setSubscriberSearchData(subscriberSearchData);

        MtxDeviceSearchData deviceSearchData = new MtxDeviceSearchData();
        deviceSearchData.setDollarSign("MtxDeviceSearchData");
        deviceSearchData.setMultiRequestIndex("4");
        subscriberAddDevice.setDeviceSearchData(deviceSearchData);

        requestList.add(subscriberAddDevice);

        // Creating an instance of MtxRequestGroupAddMembership
        MtxRequestGroupAddMembership groupAddMembership = new MtxRequestGroupAddMembership();
        groupAddMembership.setDollarSign("MtxRequestGroupAddMembership");

        MtxGroupSearchData groupSearchData = new MtxGroupSearchData();
        groupSearchData.setDollarSign("MtxGroupSearchData");
        groupSearchData.setMultiRequestIndex("0");
        groupAddMembership.setGroupSearchData(groupSearchData);

        groupAddMembership.setRelatedMsgId("MSG: Add member to group");

        MtxSubscriberSearchData subscriberSearchData2 = new MtxSubscriberSearchData();
        subscriberSearchData2.setDollarSign("MtxSubscriberSearchData");
        subscriberSearchData2.setMultiRequestIndex("2");

        groupAddMembership.setSubscriberArray(Arrays.asList(subscriberSearchData2));
        requestList.add(groupAddMembership);


        // Creating an instance of MtxRequestSubscriberPurchaseOffer
        MtxRequestSubscriberPurchaseOffer subscriberPurchaseOffer = new MtxRequestSubscriberPurchaseOffer();
        subscriberPurchaseOffer.setDollarSign("MtxRequestSubscriberPurchaseOffer");

        MtxSubscriberSearchData purchaseSubscriberSearchData = new MtxSubscriberSearchData();
        purchaseSubscriberSearchData.setDollarSign("MtxSubscriberSearchData");
        purchaseSubscriberSearchData.setMultiRequestIndex("2");
        subscriberPurchaseOffer.setSubscriberSearchData(purchaseSubscriberSearchData);

        MtxPurchasedOfferData offerData = new MtxPurchasedOfferData();
        offerData.setDollarSign("MtxPurchasedOfferData");
        offerData.setExternalId("wHSIA: Setup Services");

        subscriberPurchaseOffer.setOfferRequestArray(Arrays.asList(offerData));
        subscriberPurchaseOffer.setRelatedMsgId("Subscription Purchase Setup Services");
        requestList.add(subscriberPurchaseOffer);

        // Creating an instance of MtxRequestSubscriberPurchaseOffer
        MtxRequestSubscriberPurchaseOffer subscriberPurchaseOffer2 = new MtxRequestSubscriberPurchaseOffer();
        subscriberPurchaseOffer2.setDollarSign("MtxRequestSubscriberPurchaseOffer");

        // Setting SubscriberSearchData
        MtxSubscriberSearchData subscriberSearchData3 = new MtxSubscriberSearchData();
        subscriberSearchData3.setDollarSign("MtxSubscriberSearchData");
        subscriberSearchData3.setMultiRequestIndex("2");
        subscriberPurchaseOffer2.setSubscriberSearchData(subscriberSearchData3);

        // Setting OfferRequestArray
        MtxPurchasedOfferData offerData2 = new MtxPurchasedOfferData();
        offerData2.setDollarSign("MtxPurchasedOfferData");
        offerData2.setExternalId("PO_WHSIA_1_I_Data_ML");

        subscriberPurchaseOffer2.setOfferRequestArray(Arrays.asList(offerData2));
        subscriberPurchaseOffer2.setRelatedMsgId("Subscription Purchase ML Overage");
        requestList.add(subscriberPurchaseOffer2);


        // Creating an instance of MtxRequestSubscriberPurchaseOffer
        MtxRequestSubscriberPurchaseOffer subscriberPurchaseOffer3 = new MtxRequestSubscriberPurchaseOffer();
        subscriberPurchaseOffer3.setDollarSign("MtxRequestSubscriberPurchaseOffer");

        // Set SubscriberSearchData
        MtxSubscriberSearchData subscriberSearchData4 = new MtxSubscriberSearchData();
        subscriberSearchData4.setDollarSign("MtxSubscriberSearchData");
        subscriberSearchData4.setMultiRequestIndex("2");
        subscriberPurchaseOffer3.setSubscriberSearchData(subscriberSearchData4);

        // Set OfferRequestArray
        MtxPurchasedOfferData offerData1 = new MtxPurchasedOfferData();
        offerData1.setDollarSign("MtxPurchasedOfferData");
        offerData1.setExternalId("PO_WHSIA_Data_PLAN_MONTHLY_ALLOWANCE_Stackable_Recurring");

        // Set attributes for the purchased offer
        TelusPurchasedOfferExtension attr = new TelusPurchasedOfferExtension();
        attr.setDollarSign("TelusPurchasedOfferExtension");
        attr.setRatingSpecInstanceId("123123123125");
        attr.setRatingSpecType("ALLOWANCE");
        attr.setRateSpecSubType("DATA");
        attr.setPriority(10000);
        attr.setAllowanceGrant(100.0);
        attr.setGrantUOM("GB");
        attr.setIsRollOver(0);
        attr.setServiceFilterGroup(List.of("WISP1", "WISP6", "WISP7", "WISP8", "WISP11"));
        attr.setZoneFilterGroup(List.of("CAN"));
        attr.setNotificationStatus("Stackable");
        offerData1.setAttr(attr);

        subscriberPurchaseOffer3.setOfferRequestArray(Arrays.asList(offerData1));

        // Setting PurchasePackageData
        MtxPurchasePackageData purchasePackageData = new MtxPurchasePackageData();
        purchasePackageData.setDollarSign("MtxPurchasePackageData");

        TelusPurchasePackage packageAttr = new TelusPurchasePackage();
        packageAttr.setDollarSign("TelusPurchasePackage");
        packageAttr.setOfferId("9159602850913490000");
        packageAttr.setOfferInstanceId("12332222");
        packageAttr.setRatingSpecRecurrenceCd("Monthly");
        packageAttr.setOfferTypeCd("PLAN");
        purchasePackageData.setAttr(packageAttr);

        purchasePackageData.setCycleOffsetType(1);
        purchasePackageData.setName("Base Plan");
        purchasePackageData.setPeriodInterval(1);
        purchasePackageData.setPeriodType(4);

        subscriberPurchaseOffer3.setPurchasePackageData(purchasePackageData);
        subscriberPurchaseOffer3.setRelatedMsgId("Subscription Purchase Offer");
        requestList.add(subscriberPurchaseOffer3);

        // Creating an instance of MtxRequestSubscriberPurchaseOffer
        MtxRequestSubscriberPurchaseOffer subscriberPurchaseOffer4 = new MtxRequestSubscriberPurchaseOffer();
        subscriberPurchaseOffer4.setDollarSign("MtxRequestSubscriberPurchaseOffer");

        // Setting SubscriberSearchData
        MtxSubscriberSearchData subscriberSearchData5 = new MtxSubscriberSearchData();
        subscriberSearchData5.setDollarSign("MtxSubscriberSearchData");
        subscriberSearchData5.setMultiRequestIndex("2");
        subscriberPurchaseOffer4.setSubscriberSearchData(subscriberSearchData5);

        // Setting OfferRequestArray
        MtxPurchasedOfferData offerData3 = new MtxPurchasedOfferData();
        offerData3.setDollarSign("MtxPurchasedOfferData");
        offerData3.setEndTimeRelativeOffset(30);
        offerData3.setEndTimeRelativeOffsetUnit(2);
        offerData3.setExternalId("PO_WHSIA_Data_TOPUP_BCIC_ALLOWANCE_NonStackable");

        // Setting attributes for the purchased offer
        TelusPurchasedOfferExtension attr2 = new TelusPurchasedOfferExtension();
        attr2.setDollarSign("TelusPurchasedOfferExtension");
        attr2.setRatingSpecInstanceId("123123123125");
        attr2.setRatingSpecType("ALLOWANCE");
        attr2.setRateSpecSubType("DATA");
        attr2.setRatingSpecTypePeriod(30);
        attr2.setIsRatingSpecRecurred(0);
        attr2.setPriority(5000);
        attr2.setAllowanceGrant(10.0);
        attr2.setGrantUOM("GB");
        attr2.setIsRollOver(0);
        attr2.setServiceFilterGroup(List.of("WISP1", "WISP6", "WISP7", "WISP8", "WISP11"));
        attr2.setZoneFilterGroup(List.of("CAN"));
        attr2.setNotificationStatus("NON-STACKABLE");
        offerData3.setAttr(attr);

        subscriberPurchaseOffer4.setOfferRequestArray(Arrays.asList(offerData3));


        // Creating an instance of MtxRequestSubscriberPurchaseOffer
        MtxRequestSubscriberPurchaseOffer subscriberPurchaseOffer5 = new MtxRequestSubscriberPurchaseOffer();
        subscriberPurchaseOffer5.setDollarSign("MtxRequestSubscriberPurchaseOffer");

        // Setting SubscriberSearchData
        MtxSubscriberSearchData subscriberSearchData6 = new MtxSubscriberSearchData();
        subscriberSearchData6.setDollarSign("MtxSubscriberSearchData");
        subscriberSearchData6.setMultiRequestIndex("2");
        subscriberPurchaseOffer5.setSubscriberSearchData(subscriberSearchData6);

        // Setting OfferRequestArray
        MtxPurchasedOfferData offerData4 = new MtxPurchasedOfferData();
        offerData4.setDollarSign("MtxPurchasedOfferData");
        offerData4.setEndTimeRelativeOffset(30);
        offerData4.setEndTimeRelativeOffsetUnit(2);
        offerData4.setExternalId("PO_WHSIA_Data_TOPUP_BCIC_ALLOWANCE_NonStackable");

        // Set attributes for the purchased offer
        TelusPurchasedOfferExtension attr3 = new TelusPurchasedOfferExtension();
        attr3.setDollarSign("TelusPurchasedOfferExtension");
        attr3.setRatingSpecInstanceId("123123123125");
        attr3.setRatingSpecType("ALLOWANCE");
        attr3.setRateSpecSubType("DATA");
        attr3.setRatingSpecTypePeriod(30);
        attr3.setIsRatingSpecRecurred(0);
        attr3.setPriority(5000);
        attr3.setAllowanceGrant(10.0);
        attr3.setGrantUOM("GB");
        attr3.setIsRollOver(0);
        attr3.setServiceFilterGroup(List.of("WISP1", "WISP6", "WISP7", "WISP8", "WISP11"));
        attr3.setZoneFilterGroup(List.of("CAN"));
        attr3.setNotificationStatus("NON-STACKABLE");
        offerData4.setAttr(attr3);

        subscriberPurchaseOffer.setOfferRequestArray(Arrays.asList(offerData4));

        // Setting PurchasePackageData
        MtxPurchasePackageData purchasePackageData2 = new MtxPurchasePackageData();
        purchasePackageData2.setDollarSign("MtxPurchasePackageData");

        TelusPurchasePackage purchaseAttr = new TelusPurchasePackage();
        purchaseAttr.setDollarSign("TelusPurchasePackage");
        purchaseAttr.setOfferId("915960285091390000");
        purchaseAttr.setOfferInstanceId("923123240");
        purchaseAttr.setRatingSpecRecurrenceCd("BCIC");
        purchaseAttr.setOfferTypeCd("TOPUP");
        purchaseAttr.setOfferEffectiveDate("2021-06-23T20:47:47Z");

        purchasePackageData.setAttr(purchaseAttr);
        purchasePackageData.setCycleOffsetType(2);
        purchasePackageData.setName("BCIC Offer");
        purchasePackageData.setPeriodInterval(30);
        purchasePackageData.setPeriodType(2);

        subscriberPurchaseOffer.setPurchasePackageData(purchasePackageData);
        subscriberPurchaseOffer.setRelatedMsgId("Subscription Purchase TOPUP Offer");

        requestMulti.setRequestManagerList(requestList);

        // Converting to JSON string
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(requestMulti);

        return jsonRequest;
    }
}
