package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.entity.TMFTransaction;
import com.telus.serviceactivation.activation.model.matrixxPayload.ApiEventData;
import com.telus.serviceactivation.activation.model.matrixxPayload.MtxRequestMulti;
import com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation.*;

import java.util.Arrays;
import java.util.List;

public class SAJsonBuilder {
    public String createSAJsonRequest(ServiceRequestDto transaction) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest ="";
        /*// Creating ApiEventData
        ApiEventData apiEventData = new ApiEventData();
        apiEventData.setType("TelusApiEventDataExtension");
        apiEventData.setTransactionSequenceNumber(transaction.getTxnSeqNo());
        apiEventData.setTransactionEffectiveDate(transaction.getTxnEffectiveTs());
        apiEventData.setActivityCd(transaction.getActivityCode().name());
        apiEventData.setInitiatingApplicationCd("NC");

        // Creating RequestList
        List<RequestItem> requestList = new ArrayList<>();

        Request groupCreateRequest = new Request();
        groupCreateRequest.setType("MtxRequestGroupCreate");
        groupCreateRequest.setRelatedMsgId("MSG: Create a group");
        groupCreateRequest.setTenantId("Telus");
        groupCreateRequest.setExternalId(transaction.getExternalId());
        requestList.add(groupCreateRequest);


        MtxRequestMulti requestMulti = new MtxRequestMulti();
        requestMulti.setType("MtxRequestMulti");
        requestMulti.setApiEventData(apiEventData);
        requestMulti.setRequestList(requestList);*/

        try {
            ApiEventData apiEventData = new ApiEventData();
            apiEventData.setDollarSign("TelusApiEventDataExtension");
           // apiEventData.setTransactionSequenceNumber(transaction.getTxnSeqNo());
           // apiEventData.setTransactionEffectiveDate(transaction.getTxnEffectiveTs());
            apiEventData.setActivityCd("NAC");
           // apiEventData.setInitiatingApplicationCd("NC");

            MtxRequestGroupCreate groupCreate = new MtxRequestGroupCreate();
            groupCreate.setDollarSign("MtxRequestGroupCreate");
            groupCreate.setRelatedMsgId("MSG: Create a group");
            groupCreate.setTenantId("Telus");
           // groupCreate.setExternalId(transaction.getExternalId());

            MtxRequestUserCreate userCreate = new MtxRequestUserCreate();
            userCreate.setDollarSign("MtxRequestUserCreate");
            userCreate.setRelatedMsgId("MSG: Create User");
            userCreate.setTenantId("Telus");
            userCreate.setContactPhoneNumber("404567891");
            userCreate.setLanguage("EN");
            userCreate.setNotificationPreference("1");
            userCreate.setExternalId("UTMF_98765");

            MtxRequestSubscriptionCreate subscriptionCreate = new MtxRequestSubscriptionCreate();
            subscriptionCreate.setDollarSign("MtxRequestSubscriptionCreate");
            subscriptionCreate.setRelatedMsgId("MSG: Create a Subscription");
            subscriptionCreate.setTenantId("Telus");
            subscriptionCreate.setExternalId("TMF_98767");
            subscriptionCreate.setTimeZone("America/Edmonton");

            TelusSubscriberExtension attr = new TelusSubscriberExtension();
            attr.setAccountSubTypeCd("R");
            attr.setAccountTypeCd("I");
            attr.setBillingAccountNumber("1001604710000");
            attr.setBillingProvinceCd("BC");
            attr.setBillingCycleCd("11");
            attr.setBrandId("1");
            attr.setGeoTypeCd("GEOFENCE");
            attr.setPricePlanCd("9159602850913498849");
            attr.setPricePlanEffectiveDate("2021-06-23T20:47:47.732Z");
            attr.setExceedAllowanceTypeCd("null");
            attr.setTelusTimeZone("ESTNDLS");
            attr.setMonthlyCapValue(45.0);
            attr.setGeoFenceStatus("UNREGISTERED");
            subscriptionCreate.setAttr(attr);

            MtxBillingCycleData billingCycle = new MtxBillingCycleData();
            billingCycle.setDollarSign("MtxBillingCycleData");
            billingCycle.setBillingCycleId("300");
            billingCycle.setDateOffset("{{dateOffset}}");
            subscriptionCreate.setBillingCycle(billingCycle);

            MtxRequestUserAddSubscription userAddSubscription = new MtxRequestUserAddSubscription();
            userAddSubscription.setDollarSign("MtxRequestUserAddSubscription");
            userAddSubscription.setRelatedMsgId("Associate subscription to the user");
            userAddSubscription.setRoleArray(Arrays.asList(MtxRoleData.builder()
                    .type("MtxRoleData")
                    .pricingId("1")
                    .build()));
            userAddSubscription.setUserSearchData(MtxUserSearchData.builder()
                    .type("MtxUserSearchData")
                    .multiRequestIndex("1")
                    .build());
            userAddSubscription.setSubscriptionSearchData(MtxSubscriptionSearchData.builder()
                            .type("MtxSubscriptionSearchData")
                            .multiRequestIndex("1")
                    .build());

            MtxRequestDeviceCreate deviceCreate = new MtxRequestDeviceCreate();
            deviceCreate.setDollarSign("MtxRequestDeviceCreate");
            deviceCreate.setTenantId("Telus");
            MtxMobileDeviceExtension deviceAttr = new MtxMobileDeviceExtension();
            deviceAttr.setAccessNumberArray(List.of("404567891"));
            deviceAttr.setImsi("70089090999");
            deviceCreate.setAttr(deviceAttr);
            deviceCreate.setRelatedMsgId("New-Device");

            MtxRequestMulti mtxRequestMulti = new MtxRequestMulti();
            mtxRequestMulti.setDollarSign("MtxRequestMulti");
            mtxRequestMulti.setApiEventData(apiEventData);
            /*mtxRequestMulti.setRequestList(Arrays.asList(
                    groupCreate,
                    userCreate,
                    subscriptionCreate,
                    userAddSubscription,
                    deviceCreate
            ));*/

            // Convert to JSON
            jsonRequest = objectMapper.writeValueAsString(mtxRequestMulti);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        // Serializing the object to JSON
        //String jsonOutput = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(requestMulti);

        // Printing the JSON
        System.out.println("Generated JSON: " + jsonRequest);

        return jsonRequest;
    }
}
