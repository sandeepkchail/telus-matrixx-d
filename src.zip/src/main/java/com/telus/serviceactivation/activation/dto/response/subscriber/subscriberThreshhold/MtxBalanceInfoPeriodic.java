package com.telus.serviceactivation.activation.dto.response.subscriber.subscriberThreshhold;

import java.util.List;

public class MtxBalanceInfoPeriodic {
    private double amount;
    private String availableAmount;
    private List<MtxBalancePeriodInfo> balancePeriodArray;
    private String balanceStartTime;
    private int category;
    private int classId;
    private String className;
    private String creditLimit;
    private String endTime;
    private int intervalCount;
    private boolean isAggregate;
    private boolean isBillingCyclePeriodic;
    private boolean isCompositeMeter;
    private boolean isCreateExternalPaymentRequest;
    private boolean isOnDemand;
    private boolean isPeriodic;
    private boolean isPrepaid;
    private boolean isPrivate;
    private boolean isPurchasedItemCyclePeriodic;
    private boolean isRenewable;
    private boolean isVirtual;
    private String name;
    private int period;
    private int periodInterval;
    private String periodicBalanceForfeitureCreditFloorAdjust;
    private String periodicBalanceGrantCreditFloorAdjust;
    private String quantityUnit;
    private double reservedAmount;
    private int resourceId;
    private String startTime;
    private int templateId;
    private List<MtxThresholdInfo> thresholdArray;
    private String thresholdLimit;
}

