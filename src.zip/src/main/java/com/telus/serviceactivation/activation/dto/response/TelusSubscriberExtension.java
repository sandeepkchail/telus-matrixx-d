package com.telus.serviceactivation.activation.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;


@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@RequiredArgsConstructor
public class TelusSubscriberExtension {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("AccountSubTypeCd")
    private String accountSubTypeCd;

    @JsonProperty("AccountTypeCd")
    private String accountTypeCd;

    @JsonProperty("BillingAccountNumber")
    private String billingAccountNumber;

    @JsonProperty("BillingCycleCd")
    private String billingCycleCd;

    @JsonProperty("BillingProvinceCd")
    private String billingProvinceCd;

    @JsonProperty("BrandId")
    private String brandId;

    @JsonProperty("ExceedAllowanceTypeCd")
    private String exceedAllowanceTypeCd;

    @JsonProperty("GeoFenceStatus")
    private String geoFenceStatus;

    @JsonProperty("GeoTypeCd")
    private String geoTypeCd;

    @JsonProperty("MonthlyCapValue")
    private double monthlyCapValue;

    @JsonProperty("PricePlanCd")
    private String pricePlanCd;

    @JsonProperty("PricePlanEffectiveDate")
    private String pricePlanEffectiveDate;

    @JsonProperty("ProviderID")
    private String providerID;

    @JsonProperty("TelusTimeZone")
    private String telusTimeZone;
}


