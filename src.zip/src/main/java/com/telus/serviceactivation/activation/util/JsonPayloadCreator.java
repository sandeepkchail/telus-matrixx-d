package com.telus.serviceactivation.activation.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JsonPayloadCreator {

    public static void main(String[] args) {
        try {
            String jsonPayload = createJsonPayload(
                    "MobileService",
                    "Service Suspend",
                    "POS-WLS",
                    "99999999",
                    "2024-10-15T00:00:00.000-04:00",
                    "SUS",
                    "681459",
                    "36274567",
                    "S",
                    "2024-08-15T02:00:00.000-04:00",
                    "4166845888"
            );
            System.out.println(jsonPayload);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    public static String createJsonPayload(
            String category,
            String description,
            String serviceType,
            String transactionSequenceNumber,
            String transactionEffectiveDate,
            String activityCd,
            String billingAccountNumber,
            String externalId,
            String subscriberStatusCd,
            String subscriberStatusDate,
            String phoneNumber) throws JsonProcessingException {

        ObjectMapper objectMapper = new ObjectMapper();

        // Create the ApiEventData part
        Map<String, Object> apiEventData = new HashMap<>();
        apiEventData.put("$", "TelusApiEventDataExtension");
        apiEventData.put("TransactionSequenceNumber", transactionSequenceNumber);
        apiEventData.put("TransactionEffectiveDate", transactionEffectiveDate);
        apiEventData.put("ActivityCd", activityCd);
        apiEventData.put("InitiatingApplicationCd", "FIFA PORTAL");

        // Create the serviceCharacteristic part
        List<Map<String, Object>> serviceCharacteristics = List.of(
                createServiceCharacteristic("transactionSequenceNumber", "string", transactionSequenceNumber),
                createServiceCharacteristic("transactionEffectiveDate", "string", transactionEffectiveDate),
                createServiceCharacteristic("activityCd", "string", activityCd),
                createServiceCharacteristic("billingAccountNumber", "string", billingAccountNumber),
                createServiceCharacteristic("externalId", "string", externalId),
                createServiceCharacteristic("subscriberStatusCd", "string", subscriberStatusCd),
                createServiceCharacteristic("subscriberStatusDate", "date", subscriberStatusDate),
                createServiceCharacteristic("phoneNumber", "string", phoneNumber)
        );

        // Create the RequestList part
        Map<String, Object> requestListItem = new HashMap<>();
        requestListItem.put("$", "MtxRequestSubscriptionModify");
        requestListItem.put("Status", "3");
        requestListItem.put("SubscriptionSearchData", createSubscriptionSearchData(externalId));
        requestListItem.put("RelatedMsgId", "Suspending the account - Immediate Block");

        // Create the final payload
        Map<String, Object> payload = new HashMap<>();
        payload.put("$", "MtxRequestMulti");
        payload.put("ApiEventData", apiEventData);
        payload.put("RequestList", List.of(requestListItem));

        // Convert the payload map to JSON string
        return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(payload);
    }

    private static Map<String, Object> createServiceCharacteristic(String name, String valueType, String value) {
        Map<String, Object> characteristic = new HashMap<>();
        characteristic.put("name", name);
        characteristic.put("valueType", valueType);
        characteristic.put("value", value);
        return characteristic;
    }

    private static Map<String, Object> createSubscriptionSearchData(String externalId) {
        Map<String, Object> subscriptionSearchData = new HashMap<>();
        subscriptionSearchData.put("$", "MtxSubscriptionSearchData");
        subscriptionSearchData.put("ExternalId", externalId);
        return subscriptionSearchData;
    }
}

