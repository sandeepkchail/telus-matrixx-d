package com.telus.serviceactivation.activation.entity;


import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "tmf640_api_retry_trxn")
@ToString
public class RetryTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "retry_trxn_id")
    private Long retryTransactionId;

    @Column(name = "transaction_id", insertable = false, updatable = false) // Marked as read-only
    private Long transactionId;

    /* @OneToOne
     @JoinColumn(name = "trxn_id")*/
    /*@Column(name = "trxn_id")
    private TMFTransaction transaction;*/

    @Column(name = "external_id")
    private Integer externalId;

    @Column(name = "activity_code", length = 512)
    private String activityCode;

    @Column(name = "billing_account_num", length = 512)
    private String ban;

    @Column(name = "phone_num", length = 512)
    private String phoneNumber;

    @Column(name = "retry_attempt")
    private Integer retryAttempt;

    @Column(name = "retry_status", length = 512)
    private String retryStatus;

    @Column(name = "retry_timestamp")
    private LocalDateTime retryTimestamp;

    @Column(name = "error_message", length = 512)
    private String errorMessage;

    @Override
    public String toString() {
        return "RetryTransaction{" +
                /*"transactionId=" + transactionId +*/
                ", externalId=" + externalId +
                ", activityCode='" + activityCode + '\'' +
                ", ban='" + ban + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", retryAttempt='" + retryAttempt + '\'' +
                ", retryStatus='" + retryStatus + '\'' +
                ", retryTimestamp=" + retryTimestamp +
                ", errorMessage=" + errorMessage +
                '}';
    }
}