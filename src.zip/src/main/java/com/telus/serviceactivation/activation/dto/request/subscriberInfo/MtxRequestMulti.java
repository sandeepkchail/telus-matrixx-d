package com.telus.serviceactivation.activation.dto.request.subscriberInfo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.telus.serviceactivation.activation.dto.request.BaseMtxRequestMulti;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Data
@RequiredArgsConstructor
public class MtxRequestMulti extends BaseMtxRequestMulti {
    private List<MtxRequestSubscriberQuery> requestList;
}
