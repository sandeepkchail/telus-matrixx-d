package com.telus.serviceactivation.activation.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@RequiredArgsConstructor
public class MtxResponseSubscriber {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("AdminGroupCount")
    private int adminGroupCount;

    @JsonProperty("AdminGroupCursor")
    private int adminGroupCursor;

    @JsonProperty("Attr")
    private TelusSubscriberExtension attr;

    @JsonProperty("BalanceArray")
    private List<MtxBalanceInfo> balanceArray;

    @JsonProperty("ContactEmail")
    private String contactEmail;

    @JsonProperty("ContactPhoneNumber")
    private long contactPhoneNumber;

    @JsonProperty("CurrentStatusTransitionTime")
    private String currentStatusTransitionTime;

    @JsonProperty("DeviceIdArray")
    private List<String> deviceIdArray;

    @JsonProperty("ExternalId")
    private String externalId;

    @JsonProperty("Language")
    private String language;

    @JsonProperty("LastActivityTime")
    private String lastActivityTime;

    @JsonProperty("NotificationPreference")
    private int notificationPreference;

    @JsonProperty("ObjectId")
    private String objectId;

    @JsonProperty("OwnerId")
    private String ownerId;

    @JsonProperty("ParentGroupCount")
    private int parentGroupCount;

    @JsonProperty("ParentGroupCursor")
    private int parentGroupCursor;

    @JsonProperty("ParentGroupIdArray")
    private List<String> parentGroupIdArray;

    @JsonProperty("PurchasePackageArray")
    private List<MtxPurchasePackageInfo> purchasePackageArray;

    @JsonProperty("PurchasedOfferArray")
    private List<MtxPurchasedOfferInfo> purchasedOfferArray;
}

