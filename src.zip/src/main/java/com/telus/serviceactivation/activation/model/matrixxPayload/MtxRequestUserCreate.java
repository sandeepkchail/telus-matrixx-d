package com.telus.serviceactivation.activation.model.matrixxPayload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MtxRequestUserCreate extends RequestItem implements IRequestManager {
    @JsonProperty("TenantId")
    private String tenantId;

    @JsonProperty("ContactPhoneNumber")
    private String contactPhoneNumber;

    @JsonProperty("Language")
    private String language;

    @JsonProperty("NotificationPreference")
    private String notificationPreference;

    @JsonProperty("ExternalId")
    private String externalId;
}

