package com.telus.serviceactivation.activation.thread;

import com.telus.serviceactivation.activation.entity.TMFTransaction;
import com.telus.serviceactivation.activation.repository.TransactionRepository;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@AllArgsConstructor
@NoArgsConstructor
@Data
public class TxnProcessingService {

    @Autowired
    private TransactionRepository tmftransactionRepository;

    public void processTxn(TMFTransaction txn) {
        // business logic for processing the transaction here
        System.out.println("Processing transaction: " + txn);
        // After processing, mark as complete
        txn.setStatus("COMPLETE");
        txn.setProcessedAt(LocalDateTime.now());
        tmftransactionRepository.save(txn);
    }
}

