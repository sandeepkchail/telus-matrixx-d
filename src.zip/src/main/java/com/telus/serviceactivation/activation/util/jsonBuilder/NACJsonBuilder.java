package com.telus.serviceactivation.activation.util.jsonBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.config.DynamicJsonConfig;
import com.telus.serviceactivation.activation.config.JsonRequestConfig;
import com.telus.serviceactivation.activation.constants.JsonConstants;
import com.telus.serviceactivation.activation.dto.CommonRequestDto;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.model.matrixxPayload.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.*;

import static com.telus.serviceactivation.activation.constants.JsonConstants.*;

@Slf4j
@Component("NAC")
public class NACJsonBuilder implements JsonBuilder {

    @Autowired
    private CommonRequestDto commonRequestDto;

    @Autowired
    private DynamicJsonConfig dynamicJsonConfig;

    @Autowired
    private JsonRequestConfig jsonRequestConfig;
/*

    public String getInitiatingApplicationCd(String prefix) {
        com.telus.serviceactivation.activation.config.data.MtxRequestMulti requestMulti = jsonRequestConfig.getMtxRequestMulti(prefix);
        if (requestMulti != null && requestMulti.getApiEventData() != null) {
            return requestMulti.getApiEventData().getInitiatingApplicationCd();
        }
        return "No data found for the given prefix.";
    }
*/

    public String createJsonRequest(ServiceRequestDto serviceRequestDto, String activityCd) throws JsonProcessingException {
        // log.info("Common values:::::  ", populateValue(activityCd, dynamicJsonConfig));

        //getInitiatingApplicationCd(activityCd);
      /*  String s1 = jsonRequestConfig.getInitiatingApplicationCd();
        String s2 = jsonRequestConfig.getRelatedMsgId();
        String s3 = jsonRequestConfig.getTenantId();
        String s4 = jsonRequestConfig.getExternalId();*/
       // log.info("Property :: " + s1 + ",  " + s2 + ",  " + s3 + ",  " + s4);
        //log.info("Properties::::::::::"+getInitiatingApplicationCd(activityCd));

        ApiEventData apiEventData = populateAPIEventData(serviceRequestDto, activityCd);
        List<IRequestManager> requestListItems = new ArrayList<>();
        requestListItems.add(populateMtxRequestGroupCreate());
        requestListItems.add(populateMtxRequestUserCreate());
        requestListItems.add(populateMtxRequestSubscriptionCreate());
        requestListItems.add(populateMtxRequestUserAddSubscription());
        requestListItems.add(populateMtxRequestDeviceCreate());
        requestListItems.add(populateMtxRequestSubscriberAddDevice());
        requestListItems.add(populateMtxRequestGroupAddMembership());
        requestListItems.add(populateMtxRequestSubscriberPurchaseOfferFirstList());
        requestListItems.add(populateMtxRequestSubscriberPurchaseOfferSecondList());
        requestListItems.add(populateMtxRequestSubscriberPurchaseOfferThirdList());

        // requestMulti.setRequestManagerList(requestList);
        MtxRequestMulti requestMulti = populateMtxRequestMulti(apiEventData, requestListItems);
        // Converting to JSON string
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(requestMulti);

        return jsonRequest;
    }
}
