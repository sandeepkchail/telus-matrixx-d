package com.telus.serviceactivation.activation.model.matrixxPayload.serviceActivation;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;


@Data
public class RoleData {
    @JsonProperty("$")
    private String type;
    private String pricingId;

}