package com.telus.serviceactivation.activation.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.dto.request.subscriberInfo.MtxRequestMulti;
import com.telus.serviceactivation.activation.dto.response.BaseMtxResponseMulti;
import com.telus.serviceactivation.activation.dto.response.MtxResponseGroup;
import com.telus.serviceactivation.activation.dto.response.subscriber.subscriberInfo.MtxResponseMulti;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
import java.io.InputStream;


@Slf4j
@Service
public class GroupService {


    public MtxResponseGroup getGroupDetails(MtxRequestMulti mtxRequestMulti) throws Exception {
        log.info("Inside getSubscriber() method 1 ::::");

        String externalId = mtxRequestMulti.getRequestList().get(0).getSubscriberSearchData().getExternalId();
        log.info("Inside getSubscriber() method 2 ::::");

        log.info("externalId::::" + externalId);


        //restTemplate.postForObject(url, request, String.class);
        String fileName = "getGroupDetails";
        MtxResponseGroup mtxResponseMulti = getMtxResponseMulti(fileName);
        //log.info("mtxResponseMulti.getResponseList();::::" + mtxResponseMulti.getResponseList());

        return mtxResponseMulti;
    }



    public MtxResponseGroup getMtxResponseMulti(String fileName) {
        String jsonFilePath = "matrixx/json/response/" + fileName + ".json";

        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(jsonFilePath)) {
            log.info("inputStream::::" + inputStream);

            if (inputStream == null) {
                throw new FileNotFoundException("File not found: " + jsonFilePath);
            }
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.readValue(inputStream, MtxResponseGroup.class);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

}
