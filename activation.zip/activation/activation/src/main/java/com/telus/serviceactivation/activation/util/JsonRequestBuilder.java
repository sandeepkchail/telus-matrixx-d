package com.telus.serviceactivation.activation.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.telus.serviceactivation.activation.dto.ServiceRequestDto;
import com.telus.serviceactivation.activation.entity.TMFTransaction;
import com.telus.serviceactivation.activation.model.*;

import java.util.Collections;

public class JsonRequestBuilder {

    /*public static void main(String[] args) throws JsonProcessingException {
        ServiceRequestDto serviceRequest = new ServiceRequestDto();
        serviceRequest.setServiceType("POS-WLS");
        serviceRequest.setCategory("MobileService");
        serviceRequest.setState("active");
        serviceRequest.setDescription("Service Suspend");

        MtxRequestMulti jsonRequest = buildJsonRequest(serviceRequest);

        ObjectMapper objectMapper = new ObjectMapper();
        String jsonString = objectMapper.writeValueAsString(jsonRequest);
        System.out.println(jsonString);
    }*/

    public String buildJsonRequest() throws JsonProcessingException {
        ServiceRequestDto serviceRequest = new ServiceRequestDto();
        serviceRequest.setServiceType("POS-WLS");
        serviceRequest.setCategory("MobileService");
        serviceRequest.setState("active");
        serviceRequest.setDescription("Service Suspend");

        MtxRequestMulti requestMulti = new MtxRequestMulti();
        requestMulti.setDollarSign("MtxRequestMulti");

        ApiEventData apiEventData = new ApiEventData();
        apiEventData.setDollarSign("TelusApiEventDataExtension");
        apiEventData.setTransactionSequenceNumber("78686755");
        apiEventData.setTransactionEffectiveDate("2024-09-12T11:47:47.732Z");
        apiEventData.setActivityCd("SUS");
        apiEventData.setInitiatingApplicationCd("FIFA PORTAL");
        requestMulti.setApiEventData(apiEventData);

        RequestListItem requestListItem = new RequestListItem();
        requestListItem.setDollarSign("MtxRequestSubscriptionModify");
        requestListItem.setStatus("3");

        SubscriptionSearchData subscriptionSearchData = new SubscriptionSearchData();
        subscriptionSearchData.setDollarSign("MtxSubscriptionSearchData");
        subscriptionSearchData.setExternalId("TMF_11116");
        requestListItem.setSubscriptionSearchData(subscriptionSearchData);
        requestListItem.setRelatedMsgId("Suspending the account - Immediate Block");

        requestMulti.setRequestList(Collections.singletonList(requestListItem));

        // return requestMulti;

        // MtxRequestMulti jsonRequest = buildJsonRequest(serviceRequest);

        ObjectMapper objectMapper = new ObjectMapper();
        String jsonString = objectMapper.writeValueAsString(requestMulti);
        System.out.println(jsonString);
        return jsonString;
    }


    public String createJsonRequest(TMFTransaction transaction) throws JsonProcessingException {

        MtxRequestMulti requestMulti = new MtxRequestMulti();
        requestMulti.setDollarSign("MtxRequestMulti");

        ApiEventData apiEventData = new ApiEventData();
        apiEventData.setDollarSign("TelusApiEventDataExtension");
        apiEventData.setTransactionSequenceNumber(transaction.getTxnSeqNo());
        apiEventData.setTransactionEffectiveDate(transaction.getTxnEffectiveTs());
        apiEventData.setActivityCd(transaction.getActivityCode().name());
        apiEventData.setInitiatingApplicationCd("FIFA PORTAL");

        requestMulti.setApiEventData(apiEventData);

        RequestListItem request = new RequestListItem();
        request.setDollarSign("MtxRequestSubscriptionModify");
        request.setStatus("3");

        SubscriptionSearchData subscriptionSearchData = new SubscriptionSearchData();
        subscriptionSearchData.setDollarSign("MtxSubscriptionSearchData");
        subscriptionSearchData.setExternalId(transaction.getExternalId());

        request.setSubscriptionSearchData(subscriptionSearchData);
        request.setRelatedMsgId("Suspending the account - Immediate Block");

        requestMulti.setRequestList(Collections.singletonList(request));

        // Converting to JSON string
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(requestMulti);

        // The JSON string
        System.out.println(jsonRequest);

        return jsonRequest;
    }
}

