package com.telus.serviceactivation.activation.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class SubscriptionSearchData {
    @JsonProperty("$")
    private String dollarSign;

    @JsonProperty("ExternalId")
    private String externalId;
}

