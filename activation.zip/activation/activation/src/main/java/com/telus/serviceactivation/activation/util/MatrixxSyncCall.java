package com.telus.serviceactivation.activation.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.telus.serviceactivation.activation.entity.TMFTransaction;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;


@Slf4j
@Component
public class MatrixxSyncCall {

    @Autowired
    RestTemplate restTemplate;

    public String  callMatrixx(TMFTransaction transaction) throws JsonProcessingException {
        String jsonString = new JsonRequestBuilder().createJsonRequest(transaction);
        log.info("Json String {}", jsonString);

        String url = "http://10.17.174.143:8080/rsgateway/data/json";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> request = new HttpEntity<>(jsonString, headers);
        String response = restTemplate.postForObject(url, request, String.class);
        log.info("Return  {}", response);

        return response;
    }
}
